import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useRef, useState } from "react";
import { motion } from "framer-motion";
import { UploadCloud, FileText, Loader2, X, CheckCircle2 } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Glass } from "@/components/glass";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { extractText } from "@/lib/extract-text";
import { analyzeDocument } from "@/lib/analyze.functions";

export const Route = createFileRoute("/_authenticated/upload")({
  head: () => ({ meta: [{ title: "Upload · LexiClear AI" }] }),
  component: UploadPage,
});

const MAX_BYTES = 15 * 1024 * 1024;
const ACCEPT = ".pdf,.docx,.txt,.png,.jpg,.jpeg";

function UploadPage() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const analyze = useServerFn(analyzeDocument);
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [stage, setStage] = useState<string>("");
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);

  const pick = (f: File | null) => {
    if (!f) return;
    if (f.size > MAX_BYTES) {
      toast.error("File too large. Max 15MB.");
      return;
    }
    setFile(f);
  };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    pick(e.dataTransfer.files?.[0] ?? null);
  }, []);

  const run = async () => {
    if (!file) return;
    setBusy(true);
    try {
      setStage("Uploading…");
      setProgress(5);
      const path = `${user.id}/${crypto.randomUUID()}-${file.name}`;
      const { error: upErr } = await supabase.storage
        .from("documents")
        .upload(path, file, { contentType: file.type || "application/octet-stream" });
      if (upErr) throw upErr;

      const { data: doc, error: docErr } = await supabase
        .from("documents")
        .insert({
          user_id: user.id,
          name: file.name,
          mime_type: file.type,
          size_bytes: file.size,
          storage_path: path,
          status: "pending",
        })
        .select()
        .single();
      if (docErr) throw docErr;

      setProgress(15);
      const text = await extractText(file, (s, p) => {
        setStage(s.charAt(0).toUpperCase() + s.slice(1) + "…");
        if (typeof p === "number") setProgress(15 + Math.round(p * 0.6));
      });

      if (text.length < 30) {
        throw new Error("Couldn't extract enough text from this file. Try a clearer copy.");
      }

      setStage("Analyzing with AI…");
      setProgress(80);
      const { analysisId } = await analyze({
        data: { documentId: doc.id, text, name: file.name },
      });

      setStage("Done");
      setProgress(100);
      toast.success("Analysis ready");
      navigate({ to: "/documents/$id", params: { id: doc.id } });
      void analysisId;
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message ?? "Something went wrong");
      setBusy(false);
      setStage("");
      setProgress(0);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">
          Upload a <span className="text-gradient">document</span>
        </h1>
        <p className="mt-2 text-muted-foreground">
          PDF, DOCX, TXT, or photo. Files stay private to your account.
        </p>
      </div>

      <Glass strong className="p-6 sm:p-8">
        {!file ? (
          <label
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            className={`relative block rounded-2xl border-2 border-dashed transition cursor-pointer ${
              dragOver ? "border-primary bg-primary/5" : "border-white/10 hover:border-white/20 hover:bg-white/[0.03]"
            }`}
          >
            <input
              ref={inputRef}
              type="file"
              accept={ACCEPT}
              className="sr-only"
              onChange={(e) => pick(e.target.files?.[0] ?? null)}
            />
            <div className="px-6 py-16 text-center">
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="mx-auto h-14 w-14 rounded-2xl bg-gradient-to-br from-primary/30 to-iris/20 ring-1 ring-white/10 flex items-center justify-center"
              >
                <UploadCloud className="h-6 w-6 text-primary" />
              </motion.div>
              <div className="mt-5 font-semibold">Drop your file here</div>
              <div className="text-sm text-muted-foreground mt-1">
                or click to browse · PDF, DOCX, TXT, PNG, JPG · max 15MB
              </div>
            </div>
          </label>
        ) : (
          <div className="space-y-5">
            <div className="flex items-center gap-4 rounded-xl bg-white/[0.04] p-4">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-primary/30 to-iris/20 flex items-center justify-center">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-medium truncate">{file.name}</div>
                <div className="text-xs text-muted-foreground">
                  {(file.size / 1024).toFixed(1)} KB
                </div>
              </div>
              {!busy && (
                <Button variant="ghost" size="icon" onClick={() => setFile(null)} aria-label="Remove">
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>

            {busy ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  {progress >= 100 ? (
                    <CheckCircle2 className="h-4 w-4 text-mint" />
                  ) : (
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  )}
                  {stage}
                </div>
                <Progress value={progress} className="h-1.5 bg-white/5" />
              </div>
            ) : (
              <Button
                onClick={run}
                className="w-full h-11 bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90"
              >
                Analyze document
              </Button>
            )}
          </div>
        )}
      </Glass>
    </div>
  );
}
