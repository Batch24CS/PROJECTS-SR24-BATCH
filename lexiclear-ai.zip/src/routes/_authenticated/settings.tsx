import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Glass } from "@/components/glass";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings · LexiClear AI" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const [name, setName] = useState((user.user_metadata?.full_name as string) ?? "");
  const [saving, setSaving] = useState(false);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.auth.updateUser({ data: { full_name: name } });
    if (!error) {
      await supabase.from("profiles").update({ full_name: name }).eq("id", user.id);
      toast.success("Saved");
    } else toast.error(error.message);
    setSaving(false);
  };

  return (
    <div className="space-y-8 max-w-2xl">
      <div>
        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">
          Settings
        </h1>
      </div>
      <Glass strong className="p-6 sm:p-7">
        <h2 className="font-semibold">Profile</h2>
        <p className="text-sm text-muted-foreground">Update your display name.</p>
        <form onSubmit={save} className="mt-5 space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Email</Label>
            <Input value={user.email ?? ""} readOnly className="h-11 bg-white/5 border-white/10 text-muted-foreground" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Full name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} className="h-11 bg-white/5 border-white/10" />
          </div>
          <Button type="submit" disabled={saving} className="bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90">
            {saving ? "Saving…" : "Save"}
          </Button>
        </form>
      </Glass>

      <Glass className="p-6 sm:p-7">
        <h2 className="font-semibold">Account</h2>
        <p className="text-sm text-muted-foreground mt-1">Sign out of LexiClear on this device.</p>
        <Button
          variant="outline"
          className="mt-4 bg-white/5 border-white/10 hover:bg-white/10"
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/", replace: true });
          }}
        >
          Sign out
        </Button>
      </Glass>
    </div>
  );
}
