import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowLeft, Download, FileText, Volume2, VolumeX } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Glass } from "@/components/glass";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrustGauge } from "@/components/analysis/trust-gauge";
import { downloadAnalysisPdf } from "@/lib/pdf-report";

export const Route = createFileRoute("/_authenticated/documents/$id")({
  head: () => ({ meta: [{ title: "Analysis · LexiClear AI" }] }),
  component: DocumentDetail,
  errorComponent: ({ error }) => (
    <div className="p-6"><Glass className="p-6">Couldn't load this analysis: {error.message}</Glass></div>
  ),
});

const docQO = (id: string) =>
  queryOptions({
    queryKey: ["doc", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("id, name, status, created_at, mime_type")
        .eq("id", id)
        .single();
      if (error) throw error;
      const { data: a, error: aErr } = await supabase
        .from("analyses")
        .select("*")
        .eq("document_id", id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (aErr) throw aErr;
      return { doc: data, analysis: a };
    },
  });

const levelColor = (l: string) =>
  l === "high" ? "text-rose" : l === "medium" ? "text-amber" : "text-mint";
const levelBg = (l: string) =>
  l === "high" ? "bg-rose/15" : l === "medium" ? "bg-amber/15" : "bg-mint/15";

function DocumentDetail() {
  const { id } = Route.useParams();
  const { data } = useSuspenseQuery(docQO(id));
  const { doc, analysis } = data as { doc: any; analysis: any };
  const [speaking, setSpeaking] = useState(false);

  const speak = () => {
    if (!analysis || typeof window === "undefined") return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const text = `Summary. ${analysis.summary}. Risk score ${analysis.risk_score} out of 100. Trust score ${analysis.trust_score} out of 100.`;
    const u = new SpeechSynthesisUtterance(text);
    u.onend = () => setSpeaking(false);
    u.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  };

  if (!analysis) {
    return (
      <Glass className="p-10 text-center">
        <p className="text-sm text-muted-foreground">
          {doc.status === "analyzing" ? "Analysis still running…" : "No analysis available."}
        </p>
      </Glass>
    );
  }

  const clauses = (analysis.clauses ?? []) as any[];
  const risks = (analysis.risks ?? []) as any[];
  const recs = (analysis.recommendations ?? []) as any[];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <Link to="/documents" className="inline-flex items-center text-xs text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3 w-3 mr-1" /> All documents
          </Link>
          <h1 className="mt-2 text-3xl sm:text-4xl font-semibold tracking-tight flex items-center gap-3">
            <FileText className="h-7 w-7 text-muted-foreground" />
            <span className="truncate">{doc.name}</span>
          </h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Badge variant="outline" className="border-white/15 text-muted-foreground">
              {analysis.document_type}
            </Badge>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10" onClick={speak}>
            {speaking ? <VolumeX className="h-4 w-4 mr-1.5" /> : <Volume2 className="h-4 w-4 mr-1.5" />}
            {speaking ? "Stop" : "Listen"}
          </Button>
          <Button
            className="bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90"
            onClick={() => downloadAnalysisPdf(doc.name, analysis)}
          >
            <Download className="h-4 w-4 mr-1.5" /> PDF report
          </Button>
        </div>
      </div>

      {/* Scores row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Glass className="p-6 md:col-span-1 flex flex-col items-center justify-center">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Trust score</div>
          <TrustGauge value={analysis.trust_score} className="mt-3" />
          <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-1 text-xs">
            {Object.entries(analysis.trust_breakdown ?? {}).map(([k, v]) => (
              <div key={k} className="flex justify-between gap-2 text-muted-foreground">
                <span className="capitalize">{k.replace("_", " ")}</span>
                <span className="text-foreground font-medium">{v as number}</span>
              </div>
            ))}
          </div>
        </Glass>

        <Glass className="p-6 md:col-span-2">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Risk score</div>
          <div className="mt-3 flex items-end gap-3">
            <div className="text-5xl font-semibold tracking-tight">
              <span className={analysis.risk_score >= 60 ? "text-rose" : analysis.risk_score >= 30 ? "text-amber" : "text-mint"}>
                {analysis.risk_score}
              </span>
              <span className="text-muted-foreground text-2xl"> /100</span>
            </div>
          </div>
          <div className="mt-4 h-2 rounded-full bg-white/5 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${analysis.risk_score}%` }}
              transition={{ duration: 0.8 }}
              className={`h-full rounded-full ${
                analysis.risk_score >= 60
                  ? "bg-gradient-to-r from-amber to-rose"
                  : analysis.risk_score >= 30
                    ? "bg-gradient-to-r from-mint to-amber"
                    : "bg-gradient-to-r from-mint to-primary"
              }`}
            />
          </div>
          <h3 className="mt-6 text-sm uppercase tracking-wider text-muted-foreground">Executive summary</h3>
          <p className="mt-2 leading-relaxed text-foreground/90">{analysis.summary}</p>
        </Glass>
      </div>

      {/* Key points + rights/obligations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <ListCard title="Key points" items={analysis.key_points ?? []} accent="primary" />
        <ListCard title="Your rights" items={analysis.rights ?? []} accent="mint" />
        <ListCard title="Your obligations" items={analysis.obligations ?? []} accent="amber" />
      </div>

      {/* Risks */}
      <div>
        <h2 className="text-lg font-semibold mb-3">Risks detected</h2>
        {risks.length === 0 ? (
          <Glass className="p-6 text-sm text-muted-foreground">No notable risks detected.</Glass>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {risks.map((r, i) => (
              <Glass key={i} className="p-5">
                <div className="flex items-center justify-between">
                  <div className={`text-xs uppercase tracking-wider ${levelColor(r.level)}`}>{r.level} risk</div>
                  <span className={`h-1.5 w-1.5 rounded-full ${
                    r.level === "high" ? "bg-rose" : r.level === "medium" ? "bg-amber" : "bg-mint"
                  }`} />
                </div>
                <div className="mt-2 font-medium">{r.title}</div>
                <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{r.explanation}</p>
              </Glass>
            ))}
          </div>
        )}
      </div>

      {/* Clauses */}
      <div>
        <h2 className="text-lg font-semibold mb-3">Clause breakdown</h2>
        <div className="space-y-3">
          {clauses.map((c, i) => (
            <Glass key={i} className="p-5">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.category}</div>
                  <div className="mt-0.5 font-medium truncate">{c.title}</div>
                </div>
                <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full ${levelBg(c.importance)} ${levelColor(c.importance)}`}>
                  {c.importance}
                </span>
              </div>
              <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <div className="rounded-lg bg-white/[0.03] p-3">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Original</div>
                  <div className="text-foreground/80 italic leading-relaxed">"{c.original}"</div>
                </div>
                <div className="rounded-lg bg-white/[0.03] p-3">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Plain English</div>
                  <div className="text-foreground/90 leading-relaxed">{c.explanation}</div>
                </div>
              </div>
            </Glass>
          ))}
        </div>
      </div>

      {/* Recommendations */}
      {recs.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold mb-3">Recommendations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {recs.map((r, i) => (
              <Glass key={i} className="p-5">
                <div className="text-xs uppercase tracking-wider text-rose">Issue</div>
                <div className="mt-1 font-medium">{r.issue}</div>
                <div className="text-xs uppercase tracking-wider text-mint mt-4">Suggestion</div>
                <div className="mt-1 text-sm text-foreground/90">{r.suggestion}</div>
              </Glass>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ListCard({
  title,
  items,
  accent,
}: {
  title: string;
  items: string[];
  accent: "primary" | "mint" | "amber";
}) {
  const dot =
    accent === "primary" ? "bg-primary" : accent === "mint" ? "bg-mint" : "bg-amber";
  return (
    <Glass className="p-5">
      <h3 className="text-sm uppercase tracking-wider text-muted-foreground">{title}</h3>
      {items.length === 0 ? (
        <p className="mt-3 text-sm text-muted-foreground">None.</p>
      ) : (
        <ul className="mt-3 space-y-2">
          {items.map((it, i) => (
            <li key={i} className="flex items-start gap-2 text-sm">
              <span className={`mt-1.5 h-1.5 w-1.5 rounded-full ${dot} shrink-0`} />
              <span className="text-foreground/90 leading-relaxed">{it}</span>
            </li>
          ))}
        </ul>
      )}
    </Glass>
  );
}
