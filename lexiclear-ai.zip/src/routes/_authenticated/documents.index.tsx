import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { FileText, Trash2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Glass } from "@/components/glass";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { StatusPill } from "./dashboard";

export const Route = createFileRoute("/_authenticated/documents/")({
  head: () => ({ meta: [{ title: "Documents · LexiClear AI" }] }),
  component: DocumentsList,
});

const listQO = queryOptions({
  queryKey: ["all-docs"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("documents")
      .select("id, name, status, created_at, mime_type, analyses(trust_score, risk_score)")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
});

function DocumentsList() {
  const { data: docs } = useSuspenseQuery(listQO);
  const qc = useQueryClient();

  const remove = async (id: string, storagePath?: string | null) => {
    if (!confirm("Delete this document and its analysis?")) return;
    if (storagePath) await supabase.storage.from("documents").remove([storagePath]);
    const { error } = await supabase.from("documents").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Deleted");
      qc.invalidateQueries({ queryKey: ["all-docs"] });
      qc.invalidateQueries({ queryKey: ["dashboard-docs"] });
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">
            Your <span className="text-gradient">documents</span>
          </h1>
          <p className="mt-2 text-muted-foreground">All analyses, ordered by most recent.</p>
        </div>
        <Link to="/upload" className="hidden sm:block">
          <Button className="bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90">
            <UploadCloud className="h-4 w-4 mr-1.5" /> New
          </Button>
        </Link>
      </div>

      {docs.length === 0 ? (
        <Glass className="p-10 text-center">
          <p className="text-sm text-muted-foreground">Nothing here yet.</p>
        </Glass>
      ) : (
        <Glass className="divide-y divide-white/5 overflow-hidden">
          {docs.map((d: any, i: number) => {
            const a = d.analyses?.[0];
            return (
              <motion.div
                key={d.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25, delay: i * 0.02 }}
                className="flex items-center gap-4 px-5 py-4 hover:bg-white/[0.03]"
              >
                <div className="h-10 w-10 rounded-lg bg-white/[0.04] flex items-center justify-center">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </div>
                <Link
                  to="/documents/$id"
                  params={{ id: d.id }}
                  className="flex-1 min-w-0"
                >
                  <div className="font-medium truncate">{d.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(d.created_at), { addSuffix: true })}
                  </div>
                </Link>
                {a && (
                  <div className="hidden sm:flex items-center gap-4 text-xs">
                    <div>
                      <span className="text-muted-foreground">Trust </span>
                      <span className="font-semibold text-mint">{a.trust_score}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Risk </span>
                      <span className="font-semibold text-rose">{a.risk_score}</span>
                    </div>
                  </div>
                )}
                <StatusPill status={d.status} />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => remove(d.id, d.storage_path)}
                  className="text-muted-foreground hover:text-rose"
                  aria-label="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </motion.div>
            );
          })}
        </Glass>
      )}
    </div>
  );
}
