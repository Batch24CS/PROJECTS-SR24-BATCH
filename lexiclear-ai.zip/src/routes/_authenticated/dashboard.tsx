import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  ArrowRight,
  FileText,
  ShieldCheck,
  AlertTriangle,
  UploadCloud,
  Sparkles,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Glass } from "@/components/glass";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard · LexiClear AI" }] }),
  component: Dashboard,
});

const docsQO = queryOptions({
  queryKey: ["dashboard-docs"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("documents")
      .select("id, name, status, created_at, analyses(risk_score, trust_score)")
      .order("created_at", { ascending: false })
      .limit(6);
    if (error) throw error;
    return data ?? [];
  },
});

function Dashboard() {
  const { user } = Route.useRouteContext();
  const { data: docs } = useSuspenseQuery(docsQO);

  const total = docs.length;
  const flat = docs.flatMap((d: any) => d.analyses ?? []);
  const avgTrust = flat.length
    ? Math.round(flat.reduce((s: number, a: any) => s + (a.trust_score ?? 0), 0) / flat.length)
    : 0;
  const highRisk = flat.filter((a: any) => (a.risk_score ?? 0) >= 60).length;

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="text-sm text-muted-foreground">
          Welcome back{user.user_metadata?.full_name ? `, ${user.user_metadata.full_name.split(" ")[0]}` : ""}.
        </div>
        <h1 className="mt-1 text-3xl sm:text-4xl font-semibold tracking-tight">
          Your <span className="text-gradient">legal workspace</span>
        </h1>
      </motion.div>

      {/* Quick action */}
      <Glass strong className="p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="hidden sm:flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary/30 to-iris/20 ring-1 ring-white/10">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Analyze a new document</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Drop a PDF, DOCX, TXT, or photo. Get a plain-English breakdown in seconds.
            </p>
          </div>
        </div>
        <Link to="/upload">
          <Button className="h-11 px-5 bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90">
            <UploadCloud className="h-4 w-4 mr-1.5" /> Upload document
          </Button>
        </Link>
      </Glass>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard icon={FileText} label="Documents" value={String(total)} />
        <StatCard
          icon={ShieldCheck}
          label="Avg trust score"
          value={flat.length ? `${avgTrust}/100` : "—"}
          accent="from-mint/40 to-primary/20"
        />
        <StatCard
          icon={AlertTriangle}
          label="High-risk docs"
          value={String(highRisk)}
          accent="from-rose/40 to-amber/20"
        />
      </div>

      {/* Recent */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Recent analyses</h2>
          <Link to="/documents" className="text-sm text-muted-foreground hover:text-foreground">
            View all <ArrowRight className="inline h-3.5 w-3.5" />
          </Link>
        </div>

        {docs.length === 0 ? (
          <Glass className="p-10 text-center">
            <div className="mx-auto h-12 w-12 rounded-xl bg-white/[0.04] flex items-center justify-center">
              <FileText className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              No documents yet. Upload your first contract to get started.
            </p>
            <Link to="/upload" className="inline-block mt-5">
              <Button className="bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90">
                Upload your first document
              </Button>
            </Link>
          </Glass>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {docs.map((d: any) => {
              const a = d.analyses?.[0];
              return (
                <Link key={d.id} to="/documents/$id" params={{ id: d.id }}>
                  <Glass className="p-5 h-full transition hover:-translate-y-0.5 hover:bg-white/[0.06]">
                    <div className="flex items-center justify-between">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <StatusPill status={d.status} />
                    </div>
                    <div className="mt-3 font-medium truncate" title={d.name}>{d.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(d.created_at), { addSuffix: true })}
                    </div>
                    {a && (
                      <div className="mt-4 flex items-center gap-3">
                        <ScoreChip label="Trust" value={a.trust_score} good />
                        <ScoreChip label="Risk" value={a.risk_score} />
                      </div>
                    )}
                  </Glass>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  accent = "from-primary/30 to-iris/20",
}: {
  icon: any;
  label: string;
  value: string;
  accent?: string;
}) {
  return (
    <Glass className="p-5">
      <div className="flex items-center justify-between">
        <div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div>
        <div className={`h-8 w-8 rounded-lg bg-gradient-to-br ${accent} ring-1 ring-white/10 flex items-center justify-center`}>
          <Icon className="h-4 w-4 text-foreground" />
        </div>
      </div>
      <div className="mt-3 text-3xl font-semibold tracking-tight">{value}</div>
    </Glass>
  );
}

export function StatusPill({ status }: { status: string }) {
  const map: Record<string, { c: string; t: string }> = {
    pending: { c: "bg-white/10 text-muted-foreground", t: "Pending" },
    analyzing: { c: "bg-primary/15 text-primary", t: "Analyzing" },
    ready: { c: "bg-mint/15 text-mint", t: "Ready" },
    error: { c: "bg-rose/15 text-rose", t: "Error" },
  };
  const s = map[status] ?? map.pending;
  return <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full ${s.c}`}>{s.t}</span>;
}

function ScoreChip({ label, value, good }: { label: string; value: number; good?: boolean }) {
  const color = good
    ? value >= 70
      ? "text-mint"
      : value >= 40
        ? "text-amber"
        : "text-rose"
    : value >= 60
      ? "text-rose"
      : value >= 30
        ? "text-amber"
        : "text-mint";
  return (
    <div className="text-xs">
      <span className="text-muted-foreground">{label} </span>
      <span className={`font-semibold ${color}`}>{value}</span>
    </div>
  );
}
