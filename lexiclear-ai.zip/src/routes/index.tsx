import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ShieldCheck,
  Sparkles,
  FileText,
  AlertTriangle,
  MessageSquare,
  Languages,
  Volume2,
  Upload,
  Brain,
  Eye,
  HelpCircle,
  Download,
  Check,
} from "lucide-react";
import { Glass } from "@/components/glass";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LexiClear AI — Understand legal documents without hiring a lawyer" },
      {
        name: "description",
        content:
          "Upload any contract or terms of service. Get plain-English summaries, risk scores, and clause-by-clause analysis in seconds.",
      },
      { property: "og:title", content: "LexiClear AI — Legal documents, decoded." },
      {
        property: "og:description",
        content:
          "Plain-English summaries, risk detection, and trust scores for any contract.",
      },
    ],
  }),
  component: Landing,
});

const features = [
  {
    icon: Sparkles,
    title: "AI Simplification",
    body: "Dense legalese rewritten in plain English you actually understand.",
  },
  {
    icon: AlertTriangle,
    title: "Risk Detection",
    body: "Auto-flag hidden fees, auto-renewals, penalties, and unfair clauses.",
  },
  {
    icon: FileText,
    title: "Clause Analysis",
    body: "Every clause broken down with original text and importance level.",
  },
  {
    icon: MessageSquare,
    title: "Legal Q&A",
    body: "Ask questions about your document and get grounded answers.",
  },
  {
    icon: Volume2,
    title: "Voice Summary",
    body: "Listen to the summary, risks, and recommendations on the go.",
  },
  {
    icon: Languages,
    title: "Multi-Language",
    body: "Explanations in English, Hindi, Telugu, and Tamil — one click.",
  },
];

const steps = [
  { icon: Upload, title: "Upload", body: "PDF, DOCX, TXT, or a photo." },
  { icon: Brain, title: "AI Analysis", body: "Document type, clauses, intent." },
  { icon: Eye, title: "Review Risks", body: "Color-coded, ranked, explained." },
  { icon: HelpCircle, title: "Ask Anything", body: "Grounded chat over your doc." },
  { icon: Download, title: "Download Report", body: "Branded PDF, ready to share." },
];

const testimonials = [
  {
    quote:
      "I was about to sign a rental agreement with an auto-renewal clause buried on page 7. LexiClear caught it in 12 seconds.",
    name: "Anita R.",
    role: "Freelance designer",
  },
  {
    quote:
      "I run a tiny SaaS. This is the closest thing to a $400/hr lawyer I can actually afford.",
    name: "Marcus T.",
    role: "Founder, Plotline",
  },
  {
    quote:
      "Finally, terms of service that make sense. The trust score alone saved me a bad partnership.",
    name: "Priya N.",
    role: "Product manager",
  },
];

const faqs = [
  {
    q: "Is my document private?",
    a: "Yes. Files are stored in your private workspace, encrypted at rest, and only ever visible to you.",
  },
  {
    q: "Does LexiClear replace a lawyer?",
    a: "No. It helps you understand documents and spot risks before you sign — but a licensed lawyer should review anything material.",
  },
  {
    q: "What file types are supported?",
    a: "PDF, DOCX, TXT, and images (PNG/JPG/JPEG) with built-in OCR for scanned documents.",
  },
  {
    q: "How accurate is the risk score?",
    a: "Our models are tuned on common consumer contracts. The score is a signal, not a verdict — always read the highlighted clauses.",
  },
];

function Landing() {
  return (
    <div className="min-h-screen">
      {/* Nav */}
      <header className="fixed inset-x-0 top-0 z-40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mt-4 flex items-center justify-between rounded-2xl glass px-4 py-2.5">
            <BrandMark />
            <nav className="hidden md:flex items-center gap-7 text-sm text-muted-foreground">
              <a href="#features" className="hover:text-foreground transition">Features</a>
              <a href="#how" className="hover:text-foreground transition">How it works</a>
              <a href="#faq" className="hover:text-foreground transition">FAQ</a>
            </nav>
            <div className="flex items-center gap-2">
              <Link to="/auth">
                <Button variant="ghost" size="sm" className="text-foreground/80 hover:text-foreground">
                  Sign in
                </Button>
              </Link>
              <Link to="/auth">
                <Button size="sm" className="bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90">
                  Get started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative pt-40 pb-28 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs text-muted-foreground"
          >
            <ShieldCheck className="h-3.5 w-3.5 text-primary" />
            Private by design · Powered by Lovable AI
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.05 }}
            className="mt-7 font-display text-5xl sm:text-6xl md:text-7xl font-semibold leading-[1.02] tracking-tight"
          >
            Understand legal documents
            <br />
            <span className="text-gradient">without hiring a lawyer.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto"
          >
            Upload any contract or terms of service. LexiClear breaks it down clause
            by clause, flags hidden risks, and gives you a trust score in seconds.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-3"
          >
            <Link to="/auth">
              <Button size="lg" className="h-12 px-6 bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90 ring-glow">
                Upload your first document
                <ArrowRight className="ml-1.5 h-4 w-4" />
              </Button>
            </Link>
            <a href="#how">
              <Button size="lg" variant="outline" className="h-12 px-6 bg-transparent border-white/15 hover:bg-white/5">
                See how it works
              </Button>
            </a>
          </motion.div>

          {/* Floating glass preview */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.35 }}
            className="relative mt-20"
          >
            <div className="absolute inset-x-10 -top-10 -bottom-10 rounded-[3rem] bg-gradient-to-br from-primary/20 via-iris/15 to-mint/10 blur-3xl" />
            <Glass strong className="relative mx-auto max-w-4xl p-6 sm:p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="rounded-xl glass p-4 text-left">
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Trust score</div>
                  <div className="mt-2 flex items-end gap-2">
                    <div className="text-4xl font-semibold text-gradient">72</div>
                    <div className="text-xs text-muted-foreground pb-1.5">/ 100</div>
                  </div>
                  <div className="mt-3 h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full w-[72%] rounded-full bg-gradient-to-r from-primary to-mint" />
                  </div>
                </div>
                <div className="rounded-xl glass p-4 text-left">
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Risks found</div>
                  <div className="mt-2 space-y-1.5 text-sm">
                    <div className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-rose"/> Auto-renewal</div>
                    <div className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-amber"/> Vague refund window</div>
                    <div className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-mint"/> Clear cancellation</div>
                  </div>
                </div>
                <div className="rounded-xl glass p-4 text-left">
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Plain English</div>
                  <p className="mt-2 text-sm leading-relaxed text-foreground/90">
                    "This contract renews automatically every year unless you cancel
                    30 days before the renewal date."
                  </p>
                </div>
              </div>
            </Glass>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="px-4 sm:px-6 lg:px-8 py-24">
        <div className="mx-auto max-w-7xl">
          <div className="max-w-2xl">
            <h2 className="text-4xl sm:text-5xl font-semibold tracking-tight">
              Built for people, <span className="text-gradient">not lawyers.</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              Every feature is designed to turn anxiety into clarity in under a minute.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
              >
                <Glass className="p-6 h-full transition hover:-translate-y-0.5 hover:bg-white/[0.06]">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary/30 to-iris/20 ring-1 ring-white/10">
                    <f.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{f.body}</p>
                </Glass>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="px-4 sm:px-6 lg:px-8 py-24">
        <div className="mx-auto max-w-7xl">
          <div className="max-w-2xl">
            <h2 className="text-4xl sm:text-5xl font-semibold tracking-tight">
              From contract to clarity in <span className="text-gradient">5 steps</span>.
            </h2>
          </div>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-5 gap-4">
            {steps.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.06 }}
              >
                <Glass className="p-5 h-full">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="font-display font-semibold text-primary">0{i + 1}</span>
                  </div>
                  <s.icon className="mt-4 h-5 w-5 text-primary" />
                  <h4 className="mt-3 font-semibold">{s.title}</h4>
                  <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{s.body}</p>
                </Glass>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="px-4 sm:px-6 lg:px-8 py-24">
        <div className="mx-auto max-w-7xl">
          <h2 className="text-4xl sm:text-5xl font-semibold tracking-tight max-w-2xl">
            Loved by people who refuse to <span className="text-gradient">just scroll and accept</span>.
          </h2>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
            {testimonials.map((t) => (
              <Glass key={t.name} className="p-6">
                <p className="text-foreground/90 leading-relaxed">"{t.quote}"</p>
                <div className="mt-5 text-sm">
                  <div className="font-medium">{t.name}</div>
                  <div className="text-muted-foreground">{t.role}</div>
                </div>
              </Glass>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="px-4 sm:px-6 lg:px-8 py-24">
        <div className="mx-auto max-w-3xl">
          <h2 className="text-4xl sm:text-5xl font-semibold tracking-tight text-center">
            Frequently asked <span className="text-gradient">questions</span>
          </h2>
          <Glass className="mt-10 p-2">
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((f, i) => (
                <AccordionItem key={f.q} value={`item-${i}`} className="border-white/5 px-4">
                  <AccordionTrigger className="text-left text-base hover:no-underline">{f.q}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </Glass>
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 sm:px-6 lg:px-8 py-24">
        <div className="mx-auto max-w-5xl">
          <Glass strong className="relative overflow-hidden p-12 text-center">
            <div className="absolute -inset-20 bg-gradient-to-br from-primary/30 via-iris/20 to-mint/10 blur-3xl opacity-60" />
            <div className="relative">
              <h2 className="text-4xl sm:text-5xl font-semibold tracking-tight">
                Stop signing things you <span className="text-gradient">don't understand.</span>
              </h2>
              <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
                Free to try. No card required. Your first document takes about 30 seconds.
              </p>
              <Link to="/auth">
                <Button size="lg" className="mt-8 h-12 px-6 bg-gradient-to-r from-primary to-iris text-primary-foreground hover:opacity-90 ring-glow">
                  Get started free
                  <ArrowRight className="ml-1.5 h-4 w-4" />
                </Button>
              </Link>
              <ul className="mt-7 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
                {["End-to-end private", "Cancel anytime", "Works in 4 languages"].map((x) => (
                  <li key={x} className="flex items-center gap-1.5">
                    <Check className="h-3.5 w-3.5 text-mint" /> {x}
                  </li>
                ))}
              </ul>
            </div>
          </Glass>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 sm:px-6 lg:px-8 py-10 border-t border-white/5">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <BrandMark />
          <div>© {new Date().getFullYear()} LexiClear AI · Not legal advice.</div>
        </div>
      </footer>
    </div>
  );
}
