import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const RiskLevel = z.enum(["low", "medium", "high"]);

const AnalysisSchema = z.object({
  document_type: z.string(),
  summary: z.string(),
  key_points: z.array(z.string()).max(8),
  rights: z.array(z.string()).max(8),
  obligations: z.array(z.string()).max(8),
  responsibilities: z.array(z.string()).max(8),
  clauses: z
    .array(
      z.object({
        title: z.string(),
        category: z.string(),
        original: z.string(),
        explanation: z.string(),
        importance: RiskLevel,
      }),
    )
    .max(20),
  risks: z
    .array(
      z.object({
        title: z.string(),
        level: RiskLevel,
        explanation: z.string(),
      }),
    )
    .max(15),
  recommendations: z
    .array(z.object({ issue: z.string(), suggestion: z.string() }))
    .max(10),
  risk_score: z.number().int().min(0).max(100),
  trust_score: z.number().int().min(0).max(100),
  trust_breakdown: z.object({
    transparency: z.number().int().min(0).max(100),
    privacy: z.number().int().min(0).max(100),
    fairness: z.number().int().min(0).max(100),
    penalties: z.number().int().min(0).max(100),
    user_rights: z.number().int().min(0).max(100),
  }),
});

export type LexiAnalysis = z.infer<typeof AnalysisSchema>;

const SYSTEM_PROMPT = `You are LexiClear, an expert legal analyst who helps regular people understand contracts.
Read the provided document text. Identify document type. Rewrite legalese into clear, plain English.
Be specific. Quote short snippets from the original. Be conservative when uncertain — never invent terms.
Return ONLY the structured tool call output. Scoring rubric:
- risk_score: 0 (very safe) to 100 (very risky for the user).
- trust_score: 0 (opaque/unfair) to 100 (fair, transparent, balanced).`;

const ANALYZE_TOOL = {
  type: "function" as const,
  function: {
    name: "emit_analysis",
    description: "Return a structured legal analysis of the document.",
    parameters: {
      type: "object",
      additionalProperties: false,
      required: [
        "document_type",
        "summary",
        "key_points",
        "rights",
        "obligations",
        "responsibilities",
        "clauses",
        "risks",
        "recommendations",
        "risk_score",
        "trust_score",
        "trust_breakdown",
      ],
      properties: {
        document_type: { type: "string" },
        summary: { type: "string" },
        key_points: { type: "array", items: { type: "string" } },
        rights: { type: "array", items: { type: "string" } },
        obligations: { type: "array", items: { type: "string" } },
        responsibilities: { type: "array", items: { type: "string" } },
        clauses: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["title", "category", "original", "explanation", "importance"],
            properties: {
              title: { type: "string" },
              category: { type: "string", description: "e.g. payment, cancellation, privacy, liability, indemnity, penalty, renewal, responsibility" },
              original: { type: "string", description: "Short snippet from the source." },
              explanation: { type: "string" },
              importance: { type: "string", enum: ["low", "medium", "high"] },
            },
          },
        },
        risks: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["title", "level", "explanation"],
            properties: {
              title: { type: "string" },
              level: { type: "string", enum: ["low", "medium", "high"] },
              explanation: { type: "string" },
            },
          },
        },
        recommendations: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["issue", "suggestion"],
            properties: {
              issue: { type: "string" },
              suggestion: { type: "string" },
            },
          },
        },
        risk_score: { type: "integer", minimum: 0, maximum: 100 },
        trust_score: { type: "integer", minimum: 0, maximum: 100 },
        trust_breakdown: {
          type: "object",
          additionalProperties: false,
          required: ["transparency", "privacy", "fairness", "penalties", "user_rights"],
          properties: {
            transparency: { type: "integer", minimum: 0, maximum: 100 },
            privacy: { type: "integer", minimum: 0, maximum: 100 },
            fairness: { type: "integer", minimum: 0, maximum: 100 },
            penalties: { type: "integer", minimum: 0, maximum: 100 },
            user_rights: { type: "integer", minimum: 0, maximum: 100 },
          },
        },
      },
    },
  },
};

export const analyzeDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { documentId: string; text: string; name: string }) =>
    z
      .object({
        documentId: z.string().uuid(),
        text: z.string().min(20).max(120_000),
        name: z.string().min(1).max(300),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured.");

    // Mark analyzing
    await supabase
      .from("documents")
      .update({ status: "analyzing", extracted_text: data.text.slice(0, 100_000) })
      .eq("id", data.documentId)
      .eq("user_id", userId);

    // Truncate to keep prompt sensible
    const docText = data.text.length > 60_000 ? data.text.slice(0, 60_000) : data.text;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          {
            role: "user",
            content: `Document filename: ${data.name}\n\n--- DOCUMENT START ---\n${docText}\n--- DOCUMENT END ---`,
          },
        ],
        tools: [ANALYZE_TOOL],
        tool_choice: { type: "function", function: { name: "emit_analysis" } },
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error("AI gateway error:", res.status, errText);
      await supabase
        .from("documents")
        .update({ status: "error" })
        .eq("id", data.documentId)
        .eq("user_id", userId);
      if (res.status === 429) throw new Error("Rate limit reached, try again in a minute.");
      if (res.status === 402)
        throw new Error("AI credits exhausted. Add credits in your workspace settings.");
      throw new Error("AI analysis failed.");
    }

    const json = await res.json();
    const toolCall = json?.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("AI did not return a structured analysis.");
    let parsed: LexiAnalysis;
    try {
      parsed = AnalysisSchema.parse(JSON.parse(toolCall.function.arguments));
    } catch (e) {
      console.error("Schema parse failure:", e);
      throw new Error("AI returned an invalid response.");
    }

    const { data: analysis, error: insertErr } = await supabase
      .from("analyses")
      .insert({
        document_id: data.documentId,
        user_id: userId,
        document_type: parsed.document_type,
        summary: parsed.summary,
        key_points: parsed.key_points,
        rights: parsed.rights,
        obligations: parsed.obligations,
        responsibilities: parsed.responsibilities,
        clauses: parsed.clauses,
        risks: parsed.risks,
        recommendations: parsed.recommendations,
        risk_score: parsed.risk_score,
        trust_score: parsed.trust_score,
        trust_breakdown: parsed.trust_breakdown,
      })
      .select()
      .single();

    if (insertErr) {
      await supabase
        .from("documents")
        .update({ status: "error" })
        .eq("id", data.documentId)
        .eq("user_id", userId);
      throw new Error(insertErr.message);
    }

    await supabase
      .from("documents")
      .update({ status: "ready" })
      .eq("id", data.documentId)
      .eq("user_id", userId);

    return { analysisId: analysis.id };
  });
