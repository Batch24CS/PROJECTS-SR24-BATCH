// Client-only PDF report generator
import { jsPDF } from "jspdf";

type Analysis = {
  document_type?: string | null;
  summary?: string | null;
  key_points?: string[] | null;
  rights?: string[] | null;
  obligations?: string[] | null;
  responsibilities?: string[] | null;
  clauses?: any[] | null;
  risks?: any[] | null;
  recommendations?: any[] | null;
  risk_score?: number | null;
  trust_score?: number | null;
  trust_breakdown?: Record<string, number> | null;
};

export function downloadAnalysisPdf(docName: string, a: Analysis) {
  const pdf = new jsPDF({ unit: "pt", format: "a4" });
  const W = pdf.internal.pageSize.getWidth();
  const H = pdf.internal.pageSize.getHeight();
  const M = 48;
  let y = M;

  const ensure = (need: number) => {
    if (y + need > H - M) {
      pdf.addPage();
      y = M;
    }
  };
  const h1 = (t: string) => {
    ensure(36);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(20);
    pdf.setTextColor(20, 20, 30);
    pdf.text(t, M, y);
    y += 24;
  };
  const h2 = (t: string) => {
    ensure(28);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(13);
    pdf.setTextColor(40, 40, 70);
    pdf.text(t, M, y);
    y += 18;
  };
  const p = (t: string, size = 10, color = [60, 60, 70]) => {
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(size);
    pdf.setTextColor(color[0], color[1], color[2]);
    const lines = pdf.splitTextToSize(t, W - M * 2);
    for (const ln of lines) {
      ensure(size + 4);
      pdf.text(ln, M, y);
      y += size + 4;
    }
  };
  const divider = () => {
    ensure(14);
    pdf.setDrawColor(220);
    pdf.line(M, y, W - M, y);
    y += 14;
  };

  // Header
  pdf.setFillColor(30, 30, 60);
  pdf.rect(0, 0, W, 6, "F");

  h1("LexiClear AI — Document Analysis");
  p(docName, 11, [100, 100, 110]);
  p(`Document type: ${a.document_type ?? "—"}`, 10, [120, 120, 130]);
  divider();

  // Scores
  h2("Scores");
  p(`Trust score: ${a.trust_score ?? 0} / 100`);
  p(`Risk score: ${a.risk_score ?? 0} / 100`);
  if (a.trust_breakdown) {
    for (const [k, v] of Object.entries(a.trust_breakdown)) {
      p(`• ${k.replace("_", " ")}: ${v}`);
    }
  }
  divider();

  h2("Executive summary");
  p(a.summary ?? "—");
  divider();

  const list = (title: string, items?: string[] | null) => {
    if (!items || items.length === 0) return;
    h2(title);
    items.forEach((it) => p(`• ${it}`));
    divider();
  };
  list("Key points", a.key_points);
  list("Your rights", a.rights);
  list("Your obligations", a.obligations);
  list("Responsibilities", a.responsibilities);

  if (a.risks?.length) {
    h2("Risks");
    a.risks.forEach((r: any) => {
      p(`[${(r.level ?? "").toUpperCase()}] ${r.title}`, 11, [30, 30, 50]);
      p(r.explanation ?? "");
    });
    divider();
  }

  if (a.clauses?.length) {
    h2("Clause breakdown");
    a.clauses.forEach((c: any) => {
      p(`${c.title} — ${c.category} (${c.importance})`, 11, [30, 30, 50]);
      p(`Original: "${c.original}"`, 9, [120, 120, 130]);
      p(`Plain English: ${c.explanation}`);
      y += 4;
    });
    divider();
  }

  if (a.recommendations?.length) {
    h2("Recommendations");
    a.recommendations.forEach((r: any) => {
      p(`Issue: ${r.issue}`, 11, [30, 30, 50]);
      p(`Suggestion: ${r.suggestion}`);
    });
  }

  // Footer
  const pageCount = (pdf as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    pdf.setPage(i);
    pdf.setFontSize(9);
    pdf.setTextColor(160, 160, 170);
    pdf.text(`LexiClear AI · Not legal advice · ${new Date().toLocaleDateString()}`, M, H - 18);
    pdf.text(`${i} / ${pageCount}`, W - M, H - 18, { align: "right" });
  }

  pdf.save(`${docName.replace(/\.[^.]+$/, "")} — LexiClear analysis.pdf`);
}
