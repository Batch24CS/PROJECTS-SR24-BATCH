// Client-only document text extraction (PDF, DOCX, TXT, image OCR).
// All heavy libs are dynamically imported to keep them out of SSR bundle.

export type ExtractProgress = (stage: string, pct?: number) => void;

export async function extractText(file: File, onProgress?: ExtractProgress): Promise<string> {
  const name = file.name.toLowerCase();
  const type = file.type;

  if (type === "text/plain" || name.endsWith(".txt")) {
    onProgress?.("Reading text…");
    return await file.text();
  }

  if (type === "application/pdf" || name.endsWith(".pdf")) {
    onProgress?.("Parsing PDF…", 10);
    const pdfjs = await import("pdfjs-dist");
    // Worker via CDN to avoid bundler hassle
    // @ts-ignore
    pdfjs.GlobalWorkerOptions.workerSrc = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;
    const buf = await file.arrayBuffer();
    const doc = await pdfjs.getDocument({ data: buf }).promise;
    let text = "";
    for (let i = 1; i <= doc.numPages; i++) {
      const page = await doc.getPage(i);
      const content = await page.getTextContent();
      const pageText = content.items
        .map((it: any) => ("str" in it ? it.str : ""))
        .join(" ");
      text += pageText + "\n\n";
      onProgress?.(`Reading page ${i}/${doc.numPages}…`, 10 + Math.round((i / doc.numPages) * 70));
    }
    return text.trim();
  }

  if (
    type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    name.endsWith(".docx")
  ) {
    onProgress?.("Parsing DOCX…", 20);
    const mammoth = await import("mammoth/mammoth.browser");
    const buf = await file.arrayBuffer();
    const res = await mammoth.extractRawText({ arrayBuffer: buf });
    return res.value.trim();
  }

  if (type.startsWith("image/") || /\.(png|jpe?g)$/i.test(name)) {
    onProgress?.("Running OCR…", 5);
    const { createWorker } = await import("tesseract.js");
    const worker = await createWorker("eng", 1, {
      logger: (m: any) => {
        if (m.status && typeof m.progress === "number") {
          onProgress?.(m.status, Math.round(m.progress * 100));
        }
      },
    });
    const { data } = await worker.recognize(file);
    await worker.terminate();
    return (data.text || "").trim();
  }

  throw new Error("Unsupported file type. Upload a PDF, DOCX, TXT, or image.");
}
