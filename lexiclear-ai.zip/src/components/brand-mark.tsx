import { cn } from "@/lib/utils";

export function BrandMark({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        aria-hidden
        className="relative h-7 w-7 rounded-lg overflow-hidden ring-glow"
        style={{ background: "var(--gradient-accent)" }}
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,_oklch(1_0_0/0.6),_transparent_55%)]" />
      </div>
      <span className="font-display text-[15px] font-semibold tracking-tight">
        LexiClear<span className="text-gradient"> AI</span>
      </span>
    </div>
  );
}
