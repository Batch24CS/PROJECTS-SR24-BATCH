import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Glass({
  className,
  strong,
  ...rest
}: HTMLAttributes<HTMLDivElement> & { strong?: boolean }) {
  return (
    <div
      className={cn(
        strong ? "glass-strong" : "glass",
        "rounded-2xl",
        className,
      )}
      {...rest}
    />
  );
}
