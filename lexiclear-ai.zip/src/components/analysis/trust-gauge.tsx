import { motion } from "framer-motion";

export function TrustGauge({ value, className }: { value: number; className?: string }) {
  const v = Math.max(0, Math.min(100, value));
  const r = 56;
  const c = 2 * Math.PI * r;
  const offset = c - (v / 100) * c;
  const color = v >= 70 ? "var(--mint)" : v >= 40 ? "var(--amber)" : "var(--rose)";

  return (
    <div className={`relative h-36 w-36 ${className ?? ""}`}>
      <svg viewBox="0 0 140 140" className="h-full w-full -rotate-90">
        <circle
          cx="70"
          cy="70"
          r={r}
          stroke="oklch(1 0 0 / 0.08)"
          strokeWidth="10"
          fill="none"
        />
        <motion.circle
          cx="70"
          cy="70"
          r={r}
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-3xl font-semibold tracking-tight">{v}</div>
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">/ 100</div>
      </div>
    </div>
  );
}
