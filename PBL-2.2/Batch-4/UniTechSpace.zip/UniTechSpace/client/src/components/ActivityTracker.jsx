import { useEffect, useState } from "react";

function ActivityTracker() {

  const [activities, setActivities] = useState([]);

  useEffect(() => {

    const storedActivities =
      JSON.parse(localStorage.getItem("activities")) || [];

    setActivities(storedActivities);

  }, []);

  const addActivity = (activity) => {

    const updatedActivities = [...activities, activity];

    setActivities(updatedActivities);

    localStorage.setItem(
      "activities",
      JSON.stringify(updatedActivities)
    );
  };

  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg max-w-3xl mx-auto mt-16">

      <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
        User Activity Tracking
      </h2>

      <div className="flex gap-4 justify-center mb-8">

        <button
          onClick={() => addActivity("Visited Domains Page")}
          className="bg-cyan-500 text-white px-5 py-2 rounded-lg"
        >
          Track Domains
        </button>

        <button
          onClick={() => addActivity("Attempted Quiz")}
          className="bg-black text-white px-5 py-2 rounded-lg"
        >
          Track Quiz
        </button>

      </div>

      <div className="space-y-4">

        {activities.length > 0 ? (
          activities.map((activity, index) => (
            <div
              key={index}
              className="bg-gray-100 p-4 rounded-lg"
            >
              {activity}
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500">
            No activities tracked yet.
          </p>
        )}

      </div>

    </div>
  );
}

export default ActivityTracker;