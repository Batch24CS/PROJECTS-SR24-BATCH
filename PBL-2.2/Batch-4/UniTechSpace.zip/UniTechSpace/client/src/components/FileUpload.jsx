import { useState } from "react";

function FileUpload() {

  const [fileName, setFileName] = useState("");

  const handleFileChange = (e) => {

    const file = e.target.files[0];

    if (file) {
      setFileName(file.name);
    }
  };

  return (

    <div className="bg-[#0f172a] p-3 rounded-xl max-w-sm mx-auto shadow-xl">

      <h2 className="text-xl font-bold text-center mb-6 text-cyan-500">

        Upload Notes / PDFs

      </h2>

      <div className="flex justify-center">

        <label>

          <input
            type="file"
            className="hidden"
            onChange={handleFileChange}
          />

          <div className="bg-cyan-500 hover:bg-cyan-600 px-6 py-3 rounded-xl text-white font-semibold cursor-pointer transition duration-300 hover:scale-105 shadow-lg">

            Upload File

          </div>

        </label>

      </div>

      {fileName && (

        <div className="mt-6 text-center">

          <p className="text-green-400 font-semibold">

            Uploaded Successfully

          </p>

          <p className="text-gray-400 mt-2">

            {fileName}

          </p>

        </div>

      )}

    </div>
  );
}

export default FileUpload;