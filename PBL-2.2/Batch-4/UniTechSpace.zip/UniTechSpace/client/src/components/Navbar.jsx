import { Link, useNavigate } from "react-router-dom";

import { useContext } from "react";

import { AuthContext } from "../context/AuthContext";

function Navbar() {

  const { user, logout } = useContext(AuthContext);

  const navigate = useNavigate();

  const handleLogout = () => {

    logout();

    navigate("/");
  };

  return (

    <nav className="bg-[#020617] border-b border-white/10 px-10 py-5 flex justify-between items-center">

      {/* LOGO */}

      <h1 className="text-3xl font-bold text-white">

        <span className="text-cyan-400">
          UNI
        </span>{" "}

        TECH SPACE

      </h1>

      {/* NAV LINKS */}

      <div className="flex gap-8 text-gray-300 text-[15px] font-medium">

        {user && (

          <>

            <Link
              to="/home"
              className="hover:text-cyan-400 transition"
            >
              Home
            </Link>

            <Link
              to="/domains"
              className="hover:text-cyan-400 transition"
            >
              Domains
            </Link>

            <Link
              to="/quiz"
              className="hover:text-cyan-400 transition"
            >
              Quiz
            </Link>

            <Link
              to="/colleges"
              className="hover:text-cyan-400 transition"
            >
              Predictor
            </Link>

            <Link
              to="/resources"
              className="hover:text-cyan-400 transition"
            >
              Resources
            </Link>

          </>

        )}

      </div>

      {/* LOGIN / LOGOUT */}

      {user ? (

        <button
          onClick={handleLogout}
          className="border border-red-400 text-red-400 px-5 py-2 rounded-xl hover:bg-red-400 hover:text-black transition"
        >
          Logout
        </button>

      ) : (

        <Link
          to="/"
          className="border border-cyan-400 text-cyan-400 px-5 py-2 rounded-xl hover:bg-cyan-400 hover:text-black transition"
        >
          Login
        </Link>

      )}

    </nav>
  );
}

export default Navbar;