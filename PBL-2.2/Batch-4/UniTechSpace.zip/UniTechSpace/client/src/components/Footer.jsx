function Footer() {

  return (

    <footer className="text-center text-gray-500 py-4 border-t border-white/10 bg-[#020617]">

      © 2026 UNI TECH SPACE. All Rights Reserved.

    </footer>

  );
}

export default Footer;