import Navbar from "../components/Navbar";

import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";

function Home() {

  const navigate = useNavigate();

  return (

    <div className="min-h-screen bg-[#020617] text-white flex flex-col">

      <Navbar />

      {/* MAIN CONTENT */}

      <div className="flex flex-col justify-center items-center text-center pt-20 px-6 flex-grow">

        <h1 className="text-4xl font-extrabold leading-tight">

          Welcome to{" "}

          <span className="text-cyan-400">
            UNI TECH SPACE
          </span>

        </h1>

        <p className="text-gray-400 text-xl mt-8 max-w-2xl leading-relaxed">

          Explore technology domains,
          take career assessment quizzes,
          predict colleges based on your rank,
          and access learning resources —
          all in one platform.

        </p>

        {/* BUTTONS */}

        <div className="flex gap-2 mt-10">

          <button
            onClick={() => navigate("/domains")}
            className="bg-cyan-500 hover:bg-cyan-600 px-6 py-4 rounded-2xl text-lg font-semibold transition"
          >

            Explore Domains

          </button>

          <button
            onClick={() => navigate("/quiz")}
            className="border border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-4 rounded-xl text-lg font-semibold transition"
          >

            Take Quiz

          </button>

        </div>

      </div>

      {/* FOOTER */}
        <Footer />

    </div>
  );
}

export default Home;