import Navbar from "../components/Navbar";
import ActivityTracker from "../components/ActivityTracker";

function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-100">

      <Navbar />

      <div className="p-8">

        <h1 className="text-2xl font-bold text-center text-gray-800 mb-10">
          Student Dashboard
        </h1>

        <ActivityTracker />

      </div>

    </div>
  );
}

export default Dashboard;