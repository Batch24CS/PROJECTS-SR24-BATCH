import FileUpload from "../components/FileUpload";
import Navbar from "../components/Navbar";

const resources = [
  {
    subject: "Operating Systems",
    notes: "OS Notes PDF",
    video: "https://www.youtube.com/watch?v=26QPDBe-NB8",
  },
  {
    subject: "Computer Networks",
    notes: "CN Notes PDF",
    video: "https://www.youtube.com/watch?v=IPvYjXCsTg8",
  },
  {
    subject: "DBMS",
    notes: "DBMS Notes PDF",
    video: "https://www.youtube.com/watch?v=dl00fOOYLOM",
  },
  {
    subject: "DSA",
    notes: "DSA Cheat Sheet",
    video: "https://www.youtube.com/watch?v=RBSGKlAvoiM",
  },
  {
    subject: "OOPs",
    notes: "OOPs Notes",
    video: "https://www.youtube.com/watch?v=bSrm9RXwBaI",
  },
];

function Resources() {
  return (
    <div className="min-h-screen bg-[#020617] text-white">

      <Navbar />

      <div className="p-4">

        <h1 className="text-xl font-bold text-center mb-6 text-cyan-400">
          Learning Resources
        </h1>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">

          {resources.map((item, index) => (
            <div
              key={index}
              className="bg-[#0f172a] border border-white/10 p-4 rounded-xl hover:border-cyan-400/40 transition duration-400"
            >
              <h2 className="text-xl font-semibold text-cyan-400 mb-2">
                {item.subject}
              </h2>

              <p className="text-lg text-gray-700 mb-4">
                 {item.notes}
              </p>

              <a
                href={item.video}
                target="_blank"
                rel="noreferrer"
                className="inline-block bg-white text-black px-3 py-2 rounded-lg hover:bg-gray-200 transition font-medium"
              >
                Watch Video
              </a>

            </div>
          ))}

        </div>
        <div className="mt-8">
             <FileUpload />
        </div>

      </div>
    </div>
  );
}

export default Resources;