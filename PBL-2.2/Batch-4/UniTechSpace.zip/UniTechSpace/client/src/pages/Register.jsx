// Register is handled inside Login.jsx via the isRegister toggle.
// This file is kept as a placeholder to avoid breaking any imports.

function Register() {
  return null;
}

export default Register;