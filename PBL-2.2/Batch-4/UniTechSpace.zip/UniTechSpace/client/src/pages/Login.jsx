import { useState } from "react";
import { useNavigate } from "react-router-dom";

import Navbar from "../components/Navbar";

import { toast } from "react-toastify";

function Login() {

  const navigate = useNavigate();

  const [isRegister, setIsRegister] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {

    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      const url = isRegister
        ? "http://localhost:5000/api/auth/register"
        : "http://localhost:5000/api/auth/login";

      const response = await fetch(url, {

        method: "POST",

        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {

        toast.success(data.message);

        if (!isRegister) {

          localStorage.setItem(
            "user",
            JSON.stringify(data.user)
          );

          navigate("/home");
        }

      } else {

        toast.error(data.message);
      }

    } catch (error) {

      toast.error("Server Error");
    }
  };

  return (

    <div className="min-h-screen bg-[#020617] text-white">

      <Navbar />

      <div className="flex justify-center items-center pt-24">

        <div className="bg-[#0f172a] border border-white/10 p-8 rounded-2xl w-[400px] shadow-2xl">

          <h1 className="text-4xl font-bold text-center text-cyan-400 mb-8">

            {isRegister
              ? "Create Account"
              : "Welcome Back"}

          </h1>

          <form
            onSubmit={handleSubmit}
            className="space-y-5"
          >

            {isRegister && (

              <input
                type="text"
                name="name"
                placeholder="Enter Name"
                onChange={handleChange}
                className="w-full p-3 rounded-xl bg-[#020617] border border-white/10 outline-none"
                required
              />

            )}

            <input
              type="email"
              name="email"
              placeholder="Enter Email"
              onChange={handleChange}
              className="w-full p-3 rounded-xl bg-[#020617] border border-white/10 outline-none"
              required
            />

            <input
              type="password"
              name="password"
              placeholder="Enter Password"
              onChange={handleChange}
              className="w-full p-3 rounded-xl bg-[#020617] border border-white/10 outline-none"
              required
            />

            <button
              type="submit"
              className="w-full bg-cyan-400 text-black py-3 rounded-xl font-semibold hover:bg-cyan-300 transition"
            >

              {isRegister ? "Register" : "Login"}

            </button>

          </form>

          <p className="text-center text-gray-400 mt-6">

            {isRegister
              ? "Already have an account?"
              : "Don't have an account?"}

            <button
              onClick={() =>
                setIsRegister(!isRegister)
              }
              className="text-cyan-400 ml-2"
            >

              {isRegister
                ? "Login"
                : "Register"}

            </button>

          </p>

        </div>

      </div>

    </div>
  );
}

export default Login;