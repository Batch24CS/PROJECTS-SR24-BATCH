import { useState } from "react";
import Navbar from "../components/Navbar";

const projects = [
  {
    domain: "Artificial Intelligence",
    title: "AI Chatbot",
    level: "Intermediate",
    description:
      "Build an intelligent chatbot using NLP and machine learning concepts.",
    tech: "Python, NLP, TensorFlow",
  },
  {
    domain: "Web Development",
    title: "E-Commerce Website",
    level: "Beginner",
    description:
      "Create an online shopping platform with authentication and payments.",
    tech: "React, Node.js, MongoDB",
  },
  {
    domain: "Cybersecurity",
    title: "Password Strength Checker",
    level: "Intermediate",
    description:
      "Analyze password security and suggest stronger passwords.",
    tech: "JavaScript, Networking Basics",
  },
  {
    domain: "Cloud Computing",
    title: "Cloud File Storage System",
    level: "Advanced",
    description:
      "Develop a cloud-based file management and storage platform.",
    tech: "AWS, Node.js, MongoDB",
  },
  {
    domain: "Data Science",
    title: "Student Performance Predictor",
    level: "Intermediate",
    description:
      "Predict student performance using data analytics techniques.",
    tech: "Python, Pandas, ML",
  },
  {
    domain: "App Development",
    title: "Expense Tracker App",
    level: "Beginner",
    description:
      "Track daily expenses with charts and reports.",
    tech: "Flutter, Firebase",
  },
];

function Projects() {

  const [selectedProject, setSelectedProject] = useState(null);

  return (
    <div className="min-h-screen bg-gray-100">

      <Navbar />

      <div className="p-8">

        <h1 className="text-5xl font-bold text-center mb-12 text-gray-800">
          Project Recommendations
        </h1>

        <div className="grid md:grid-cols-3 gap-8">

          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-2xl shadow-lg hover:scale-105 transition duration-300"
            >
              <h2 className="text-2xl font-bold text-cyan-600 mb-4">
                {project.title}
              </h2>

              <p className="text-lg text-gray-700 mb-3">
                <span className="font-semibold">Domain:</span>{" "}
                {project.domain}
              </p>

              <p className="text-lg text-gray-700 mb-5">
                <span className="font-semibold">Level:</span>{" "}
                {project.level}
              </p>

              <button
                onClick={() => setSelectedProject(project)}
                className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800"
              >
                View Details
              </button>

            </div>
          ))}

        </div>

        {/* Modal */}

        {selectedProject && (

          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">

            <div className="bg-white p-6 rounded-2xl w-[500px] shadow-2xl">

              <h2 className="text-2xl font-bold text-cyan-600 mb-4">
                {selectedProject.title}
              </h2>

              <p className="text-lg mb-3">
                <span className="font-semibold">Domain:</span>{" "}
                {selectedProject.domain}
              </p>

              <p className="text-lg mb-3">
                <span className="font-semibold">Level:</span>{" "}
                {selectedProject.level}
              </p>

              <p className="text-lg mb-3">
                <span className="font-semibold">Technologies:</span>{" "}
                {selectedProject.tech}
              </p>

              <p className="text-gray-700 mb-6">
                {selectedProject.description}
              </p>

              <button
                onClick={() => setSelectedProject(null)}
                className="bg-red-500 text-white px-5 py-2 rounded-lg hover:bg-red-600"
              >
                Close
              </button>

            </div>

          </div>

        )}

      </div>
    </div>
  );
}

export default Projects;