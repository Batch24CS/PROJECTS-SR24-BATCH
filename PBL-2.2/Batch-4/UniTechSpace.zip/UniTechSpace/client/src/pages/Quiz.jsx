import { useEffect, useState } from "react";

import Navbar from "../components/Navbar";

const questionBank = [

  {
    question: "Which activity interests you the most?",
    options: [
      { text: "Building Websites", domain: "Web Development" },
      { text: "Training AI Models", domain: "Artificial Intelligence" },
      { text: "Securing Systems", domain: "Cybersecurity" },
      { text: "Managing Servers", domain: "Cloud Computing" },
    ],
  },

  {
    question: "Which subject do you enjoy most?",
    options: [
      { text: "Machine Learning", domain: "Artificial Intelligence" },
      { text: "Networking", domain: "Cybersecurity" },
      { text: "UI Design", domain: "Web Development" },
      { text: "Cloud Platforms", domain: "Cloud Computing" },
    ],
  },

  {
    question: "What type of projects excite you?",
    options: [
      { text: "Chatbots", domain: "Artificial Intelligence" },
      { text: "Portfolio Websites", domain: "Web Development" },
      { text: "Security Tools", domain: "Cybersecurity" },
      { text: "Cloud Storage Systems", domain: "Cloud Computing" },
    ],
  },

  {
    question: "Which skill would you like to master?",
    options: [
      { text: "Deep Learning", domain: "Artificial Intelligence" },
      { text: "React Development", domain: "Web Development" },
      { text: "Ethical Hacking", domain: "Cybersecurity" },
      { text: "AWS Services", domain: "Cloud Computing" },
    ],
  },

  {
    question: "Which work environment suits you?",
    options: [
      { text: "Research Labs", domain: "Artificial Intelligence" },
      { text: "Creative Agencies", domain: "Web Development" },
      { text: "Security Operations Center", domain: "Cybersecurity" },
      { text: "Cloud Infrastructure Teams", domain: "Cloud Computing" },
    ],
  },

];

const domainDetails = {

  "Artificial Intelligence": {
    skills: "Python, Machine Learning, Deep Learning",
    salary: "8-25 LPA",
    projects: "Chatbot, Face Detection System",
    roadmap: "Learn Python → ML → Deep Learning",
    platform: "Coursera, Kaggle",
  },

  "Web Development": {
    skills: "HTML, CSS, React, Node.js",
    salary: "5-15 LPA",
    projects: "Portfolio Website, E-Commerce App",
    roadmap: "Frontend → Backend → Full Stack",
    platform: "freeCodeCamp, Udemy",
  },

  "Cybersecurity": {
    skills: "Networking, Linux, Ethical Hacking",
    salary: "6-18 LPA",
    projects: "Password Analyzer, Packet Sniffer",
    roadmap: "Networking → Linux → Security Tools",
    platform: "TryHackMe, HackTheBox",
  },

  "Cloud Computing": {
    skills: "AWS, Docker, Kubernetes",
    salary: "7-22 LPA",
    projects: "Cloud Storage App, CI/CD Pipeline",
    roadmap: "Linux → AWS → DevOps",
    platform: "AWS Academy, Udemy",
  },

};

function Quiz() {

  const [questions, setQuestions] = useState([]);

  const [currentQuestion, setCurrentQuestion] = useState(0);

  const [scores, setScores] = useState({});

  const [showResult, setShowResult] = useState(false);

  useEffect(() => {

    const shuffled = questionBank
      .map((question) => ({
        ...question,

        options: [...question.options].sort(
          () => Math.random() - 0.5
        ),
      }))
      .sort(() => Math.random() - 0.5);

    setQuestions(shuffled);

  }, []);

  const handleAnswer = (domain) => {

    const updatedScores = {
      ...scores,
      [domain]: (scores[domain] || 0) + 1,
    };

    setScores(updatedScores);

    if (currentQuestion + 1 < questions.length) {

      setCurrentQuestion(currentQuestion + 1);

    } else {

      setShowResult(true);
    }
  };

  const getTopDomain = () => {

    return Object.keys(scores).reduce((a, b) =>
      scores[a] > scores[b] ? a : b
    );
  };

  const restartQuiz = () => {

    setCurrentQuestion(0);

    setScores({});

    setShowResult(false);
  };

  return (

    <div className="min-h-screen bg-[#020617] text-white">

      <Navbar />

      {/* PAGE HEADING */}

      <h1 className="text-4xl font-bold text-center text-cyan-400 pt-10">

        QUIZ

      </h1>

      {/* CENTER SECTION */}

      <div className="flex items-center justify-center min-h-[80vh] px-4">

        <div className="bg-white/10 backdrop-blur-lg border border-white/10 p-6 rounded-2xl shadow-xl w-[550px]">

          {!showResult ? (

            <>

              {/* QUESTION */}

              <h2 className="text-2xl font-bold text-center mb-8 text-cyan-400">

                {questions[currentQuestion]?.question}

              </h2>

              {/* OPTIONS */}

              <div className="space-y-4 flex flex-col items-center">

                {questions[currentQuestion]?.options.map(
                  (option, index) => (

                    <button
                      key={index}
                      onClick={() => handleAnswer(option.domain)}
                      className="w-[400px] py-3 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-600 text-lg font-semibold transition duration-300 hover:scale-105"
                    >

                      {option.text}

                    </button>

                  )
                )}

              </div>

            </>

          ) : (

            <div className="flex flex-col items-center text-center">

              <h1 className="text-3xl font-bold text-cyan-400 mb-8">

                Recommended Domain

              </h1>

              {/* RESULT BOX */}

              <div className="bg-white/10 border border-cyan-400 rounded-2xl p-5 w-full max-w-md">

                <h2 className="text-3xl font-bold mb-6">

                  {getTopDomain()}

                </h2>

                <p className="text-lg text-gray-300 mb-4">

                  <span className="font-bold text-cyan-400">
                    Skills:
                  </span>{" "}

                  {domainDetails[getTopDomain()]?.skills}

                </p>

                <p className="text-lg text-gray-300 mb-4">

                  <span className="font-bold text-cyan-400">
                    Salary:
                  </span>{" "}

                  {domainDetails[getTopDomain()]?.salary}

                </p>

                <p className="text-lg text-gray-300 mb-4">

                  <span className="font-bold text-cyan-400">
                    Projects:
                  </span>{" "}

                  {domainDetails[getTopDomain()]?.projects}

                </p>

                <p className="text-lg text-gray-300 mb-4">

                  <span className="font-bold text-cyan-400">
                    Roadmap:
                  </span>{" "}

                  {domainDetails[getTopDomain()]?.roadmap}

                </p>

                <p className="text-lg text-gray-300 mb-6">

                  <span className="font-bold text-cyan-400">
                    Platforms:
                  </span>{" "}

                  {domainDetails[getTopDomain()]?.platform}

                </p>

                <p className="text-gray-300 leading-relaxed">

                  Based on your interests and responses,
                  this domain best matches your skills,
                  mindset, and career preferences.

                </p>

              </div>

              {/* RETAKE BUTTON */}

              <button
                onClick={restartQuiz}
                className="mt-8 bg-cyan-500 hover:bg-cyan-600 px-6 py-3 rounded-xl text-lg font-semibold transition duration-300"
              >

                Retake Quiz

              </button>

            </div>

          )}

        </div>

      </div>

    </div>
  );
}

export default Quiz;