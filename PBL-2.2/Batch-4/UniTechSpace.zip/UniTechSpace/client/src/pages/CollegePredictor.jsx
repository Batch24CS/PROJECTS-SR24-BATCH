import { useState } from "react";
import Navbar from "../components/Navbar";

const colleges = [

  {
    name: "IIT Hyderabad",
    rank: 2000,
    branch: "CSE",
    domain: "Artificial Intelligence",
    placement: "₹28 LPA",
  },

  {
    name: "IIIT Hyderabad",
    rank: 3000,
    branch: "AI & DS",
    domain: "Artificial Intelligence",
    placement: "₹30 LPA",
  },

  {
    name: "NIT Trichy",
    rank: 7000,
    branch: "CSE",
    domain: "Web Development",
    placement: "₹18 LPA",
  },

  {
    name: "NIT Warangal",
    rank: 12000,
    branch: "CSE",
    domain: "Cybersecurity",
    placement: "₹16 LPA",
  },

  {
    name: "VIT Vellore",
    rank: 25000,
    branch: "CSE",
    domain: "Cloud Computing",
    placement: "₹12 LPA",
  },

  {
    name: "Manipal University",
    rank: 35000,
    branch: "Data Science",
    domain: "Data Science",
    placement: "₹14 LPA",
  },

  {
    name: "SRM University",
    rank: 50000,
    branch: "Cybersecurity",
    domain: "Cybersecurity",
    placement: "₹10 LPA",
  },

  {
    name: "KL University",
    rank: 65000,
    branch: "CSE",
    domain: "Web Development",
    placement: "₹8 LPA",
  },

  {
    name: "Amrita University",
    rank: 75000,
    branch: "AI & ML",
    domain: "Artificial Intelligence",
    placement: "₹9 LPA",
  },

  {
    name: "LPU",
    rank: 90000,
    branch: "CSE",
    domain: "Cloud Computing",
    placement: "₹7 LPA",
  },

  {
    name: "Chandigarh University",
    rank: 100000,
    branch: "CSE",
    domain: "Data Science",
    placement: "₹6 LPA",
  },

];

function CollegePredictor() {

  const [rank, setRank] = useState("");

  const [results, setResults] = useState([]);

  const handlePredict = () => {

    const filtered = colleges.filter(
      (college) => rank <= college.rank
    );

    setResults(filtered);
  };

  return (
    <div className="min-h-screen bg-[#020617] text-white">

      <Navbar />

      <div className="p-8">

        <h1 className="text-3xl font-extrabold text-center mb-14 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">

          Smart College Predictor

        </h1>

        {/* Input Section */}

        <div className="bg-white/10 backdrop-blur-lg border border-white/10 p-6 rounded-2xl max-w-md mx-auto shadow-2xl">

          <div className="flex flex-col items-center gap-8">

            <input
              type="number"
              placeholder="Enter Expected Rank"
              value={rank}
              onChange={(e) => setRank(e.target.value)}
              className="max-w-md p-5 rounded-xl bg-[#0f172a] border border-cyan-500 outline-none text-white"
            />

          </div>

          <div className="flex justify-center mt-10">

            <button
              onClick={handlePredict}
              className="bg-cyan-500 hover:bg-cyan-600 px-6 py-3 rounded-xl text-xl font-semibold transition duration-300"
            >
              Predict Colleges
            </button>

          </div>

        </div>

        {/* Results */}

        <div className="grid md:grid-cols-2 gap-10 mt-16">

          {results.map((college, index) => (

            <div
              key={index}
              className="bg-white/10 backdrop-blur-lg border border-white/10 p-4 rounded-2xl shadow-xl hover:scale-105 transition duration-300"
            >

              <h2 className="text-2xl font-bold text-cyan-400 mb-5">
                {college.name}
              </h2>

              <p className="text-lg text-gray-300 mb-3">
                <span className="font-bold text-white">
                  Branch:
                </span>{" "}
                {college.branch}
              </p>

              <p className="text-lg text-gray-300 mb-3">
                <span className="font-bold text-white">
                  Domain:
                </span>{" "}
                {college.domain}
              </p>

              <p className="text-lg text-gray-300 mb-3">
                <span className="font-bold text-white">
                  Expected Rank:
                </span>{" "}
                {college.rank}
              </p>

              <p className="text-lg text-gray-300">
                <span className="font-bold text-white">
                  Avg Placement:
                </span>{" "}
                {college.placement}
              </p>

            </div>

          ))}

        </div>

      </div>

    </div>
  );
}

export default CollegePredictor;