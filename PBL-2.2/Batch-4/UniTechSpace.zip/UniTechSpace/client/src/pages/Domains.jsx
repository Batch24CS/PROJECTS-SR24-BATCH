import { useState } from "react";
import Navbar from "../components/Navbar";
import {
  FaBrain,
  FaLaptopCode,
  FaShieldAlt,
  FaCloud,
  FaChartBar,
  FaMobileAlt,
} from "react-icons/fa";

const domainsList = [
  {
    title: "Artificial Intelligence",
    description: "Build intelligent systems and ML models.",
    skills: "Python, Machine Learning, NLP",
    salary: "8-20 LPA",
    companies: "Google, Microsoft, OpenAI",
    icon: <FaBrain />,
  },

  {
    title: "Web Development",
    description: "Create modern websites and web applications.",
    skills: "React, Node.js, MongoDB",
    salary: "5-15 LPA",
    companies: "Infosys, TCS, Amazon",
    icon: <FaLaptopCode />,
  },

  {
    title: "Cybersecurity",
    description: "Protect systems and networks from attacks.",
    skills: "Networking, Ethical Hacking",
    salary: "6-18 LPA",
    companies: "Cisco, IBM, Palo Alto",
    icon: <FaShieldAlt />,
  },

  {
    title: "Cloud Computing",
    description: "Work with scalable cloud platforms and services.",
    skills: "AWS, Azure, Docker",
    salary: "7-22 LPA",
    companies: "Amazon, Google Cloud",
    icon: <FaCloud />,
  },

  {
    title: "Data Science",
    description: "Analyze and visualize large datasets.",
    skills: "Python, Pandas, ML",
    salary: "8-25 LPA",
    companies: "Netflix, Meta, Google",
    icon: <FaChartBar />,
  },

  {
    title: "App Development",
    description: "Develop Android and iOS applications.",
    skills: "Flutter, Firebase",
    salary: "5-14 LPA",
    companies: "Swiggy, Zomato",
    icon: <FaMobileAlt />,
  },
];

function Domains() {

  const [search, setSearch] = useState("");
  const [selectedDomain, setSelectedDomain] = useState(null);

  const filteredDomains = domainsList.filter((domain) =>
    domain.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#020617] text-white">

      <Navbar />

      <div className="p-4">

        <h1 className="text-xl font-extrabold text-center mb-12 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
          Explore Technology Domains
        </h1>

        {/* Search Bar */}

        <div className="flex justify-center mb-10">

          <input
            type="text"
            placeholder="Search Domains..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-[500px] p-3 rounded-xl bg-[#0f172a] border border-cyan-500/30 outline-none text-white placeholder-gray-500 focus:border-cyan-400 shadow-lg"
          />

        </div>

        {/* Domain Cards */}

        <div className="grid md:grid-cols-3 gap-6">

          {filteredDomains.map((domain, index) => (

            <div
              key={index}
              className="bg-[#0f172a] border border-cyan-500/20 p-4 rounded-xl hover:scale-[1.02] hover:shadow-cyan-500/10 hover:shadow-xl transition duration-300"
            >
                <div className="w-4 h-4 rounded-xl bg-cyan-500/10 border border-cyan-400 flex items-center justify-center text-xl text-cyan-400 mb-5">
                    {domain.icon}
                </div>
              <h2 className="text-xl font-semibold text-cyan-400 mb-5">
                {domain.title}
              </h2>

              <p className="text-gray-300 text-lg leading-relaxed">
                {domain.description}
              </p>

              <button
                onClick={() => setSelectedDomain(domain)}
                className="mt-6 bg-gradient-to-r from-cyan-500 to-blue-500 hover:scale-105 px-3 py-2 rounded-xl transition duration-300 font-semibold shadow-lg shadow-cyan-500/30"
              >
                 Learn More
              </button>

            </div>

          ))}

        </div>
            {selectedDomain && (

  <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center">

    <div className="bg-[#0f172a] text-white p-8 rounded-2xl w-[550px] border border-cyan-500/20 shadow-2xl">

        <h2 className="text-2xl text-2xl font-semibold text-cyan-600 mb-6">
            {selectedDomain.title}
        </h2>

        <div className="space-y-5">

        <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
            <p className="text-cyan-400 text-2xl font-semibold text-lg mb-1">
            Skills Required
            </p>

            <p className="text-gray-300">
            {selectedDomain.skills}
            </p>
        </div>

        <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
            <p className="text-cyan-400 text-2xl font-semibold text-lg mb-1">
            Average Salary
            </p>

            <p className="text-gray-300">
            {selectedDomain.salary}
            </p>
        </div>

        <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
            <p className="text-cyan-400 text-2xl font-semibold text-lg mb-1">
            Top Companies
            </p>

            <p className="text-gray-300">
            {selectedDomain.companies}
            </p>
        </div>

        </div>

        <button
            onClick={() => setSelectedDomain(null)}
            className="mt-8 bg-gradient-to-r from-cyan-500 to-blue-500 hover:scale-105 text-white px-6 py-3 rounded-2xl transition duration-300 shadow-lg shadow-cyan-500/30"
        >
            Close
        </button>

    </div>

  </div>

)}
      </div>

    </div>
  );
}

export default Domains;