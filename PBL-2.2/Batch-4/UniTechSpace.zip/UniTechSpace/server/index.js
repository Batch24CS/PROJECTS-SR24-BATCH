const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());

app.use(express.json());

const PORT = 5000;

app.get("/", (req, res) => {
  res.send("CSE Insight Hub Backend Running");
});

app.get("/api/domains", (req, res) => {

  const domains = [
    "Artificial Intelligence",
    "Web Development",
    "Cybersecurity",
    "Cloud Computing",
    "Data Science",
  ];

  res.json(domains);
});

app.post("/api/login", (req, res) => {

  const { email, password } = req.body;

  if (email && password) {

    res.json({
      success: true,
      message: "Login Successful",
    });

  } else {

    res.json({
      success: false,
      message: "Invalid Credentials",
    });

  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});