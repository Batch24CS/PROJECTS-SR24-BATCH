import { ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "accent" | "gold" | "outline" | "ghost";
type Size = "sm" | "md" | "lg";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const variants: Record<Variant, string> = {
  primary: "bg-primary text-primary-foreground shadow-pop hover:brightness-105 active:translate-y-1 active:shadow-none",
  accent: "bg-accent text-accent-foreground shadow-pop-accent hover:brightness-105 active:translate-y-1 active:shadow-none",
  gold: "bg-gold text-gold-foreground shadow-pop-gold hover:brightness-105 active:translate-y-1 active:shadow-none",
  outline: "bg-card text-foreground border-2 border-border hover:bg-secondary",
  ghost: "bg-transparent text-foreground hover:bg-secondary",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-4 text-sm",
  md: "h-12 px-6 text-base",
  lg: "h-14 px-8 text-lg",
};

export const EcoButton = forwardRef<HTMLButtonElement, Props>(
  ({ className, variant = "primary", size = "md", ...props }, ref) => (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-2xl font-extrabold uppercase tracking-wide transition-all disabled:opacity-50 disabled:pointer-events-none",
        variants[variant],
        sizes[size],
        className,
      )}
      {...props}
    />
  ),
);
EcoButton.displayName = "EcoButton";
