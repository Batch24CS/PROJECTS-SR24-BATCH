import { Link, useNavigate } from "react-router-dom";
import { Leaf, LogOut, Trophy, Gamepad2, LayoutDashboard, GraduationCap, BookOpen, Target, Shield } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { EcoButton } from "./EcoButton";
import { NotificationBell } from "./NotificationBell";

export const Navbar = () => {
  const { user, signOut } = useAuth();
  const { isTeacher, isAdmin } = useUserRole();
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="container flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2 font-extrabold text-xl">
          <span className="w-9 h-9 rounded-2xl bg-primary text-primary-foreground grid place-items-center shadow-pop">
            <Leaf className="w-5 h-5" />
          </span>
          EcoQuest
        </Link>
        <nav className="hidden md:flex items-center gap-1 text-sm font-bold">
          <Link to="/games" className="px-3 py-2 rounded-xl hover:bg-secondary flex items-center gap-2">
            <Gamepad2 className="w-4 h-4" /> Games
          </Link>
          <Link to="/learn" className="px-3 py-2 rounded-xl hover:bg-secondary flex items-center gap-2">
            <BookOpen className="w-4 h-4" /> Learn
          </Link>
          <Link to="/challenges" className="px-3 py-2 rounded-xl hover:bg-secondary flex items-center gap-2">
            <Target className="w-4 h-4" /> Challenges
          </Link>
          <Link to="/leaderboard" className="px-3 py-2 rounded-xl hover:bg-secondary flex items-center gap-2">
            <Trophy className="w-4 h-4" /> Leaderboard
          </Link>
          {user && (
            <Link to="/dashboard" className="px-3 py-2 rounded-xl hover:bg-secondary flex items-center gap-2">
              <LayoutDashboard className="w-4 h-4" /> Dashboard
            </Link>
          )}
          {user && isTeacher && (
            <Link to="/teacher" className="px-3 py-2 rounded-xl hover:bg-secondary flex items-center gap-2">
              <GraduationCap className="w-4 h-4" /> Class
            </Link>
          )}
          {user && isAdmin && (
            <Link to="/admin" className="px-3 py-2 rounded-xl hover:bg-secondary flex items-center gap-2">
              <Shield className="w-4 h-4" /> Admin
            </Link>
          )}
        </nav>
        <div className="flex items-center gap-2">
          {user && <NotificationBell />}
          {user ? (
            <EcoButton variant="outline" size="sm" onClick={async () => { await signOut(); navigate("/"); }}>
              <LogOut className="w-4 h-4" /> Sign out
            </EcoButton>
          ) : (
            <>
              <EcoButton variant="ghost" size="sm" onClick={() => navigate("/auth")}>Log in</EcoButton>
              <EcoButton variant="primary" size="sm" onClick={() => navigate("/auth?mode=signup")}>Get started</EcoButton>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
