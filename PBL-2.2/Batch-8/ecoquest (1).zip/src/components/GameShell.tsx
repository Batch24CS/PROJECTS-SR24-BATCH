import { ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { Trophy, RotateCcw } from "lucide-react";
import { Navbar } from "./Navbar";
import { EcoButton } from "./EcoButton";
import { useAuth } from "@/hooks/useAuth";

interface GameHeaderProps {
  title: string;
  subtitle: string;
  pills: { label: string; value: string | number }[];
  progress: number; // 0-100
}

export const GameHeader = ({ title, subtitle, pills, progress }: GameHeaderProps) => (
  <>
    <div className="flex justify-between items-start mb-4 gap-3 flex-wrap">
      <div>
        <h1 className="text-2xl">{title}</h1>
        <p className="text-sm text-muted-foreground">{subtitle}</p>
      </div>
      <div className="flex gap-2">
        {pills.map((p) => (
          <div key={p.label} className="bg-card border-2 border-border rounded-2xl px-3 py-1.5 text-center min-w-[64px]">
            <p className="text-[10px] uppercase font-bold text-muted-foreground">{p.label}</p>
            <p className="font-extrabold text-sm">{p.value}</p>
          </div>
        ))}
      </div>
    </div>
    <div className="h-3 bg-secondary rounded-full overflow-hidden mb-8">
      <div className="h-full bg-hero transition-all" style={{ width: `${progress}%` }} />
    </div>
  </>
);

interface CompleteScreenProps {
  score: number;
  message?: string;
  detail?: ReactNode;
  onRestart: () => void;
}

export const CompleteScreen = ({ score, message = "Quest complete!", detail, onRestart }: CompleteScreenProps) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-16 max-w-xl">
        <div className="bg-card rounded-3xl p-10 shadow-card border-2 border-border text-center animate-bounce-in">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gold text-gold-foreground grid place-items-center shadow-pop-gold mb-4">
            <Trophy className="w-10 h-10" />
          </div>
          <h1 className="text-3xl mb-2">{message}</h1>
          <p className="text-muted-foreground mb-2">You scored</p>
          <p className="text-6xl font-extrabold text-primary mb-6">{score} pts</p>
          {detail && <div className="mb-6 text-left">{detail}</div>}
          {!user && (
            <p className="text-sm text-muted-foreground mb-4">
              <button className="text-primary font-bold underline" onClick={() => navigate("/auth?mode=signup")}>Sign up</button> to save your score.
            </p>
          )}
          <div className="flex gap-3 justify-center flex-wrap">
            <EcoButton variant="outline" onClick={onRestart}><RotateCcw className="w-4 h-4" /> Play again</EcoButton>
            <EcoButton onClick={() => navigate(user ? "/dashboard" : "/leaderboard")}>
              {user ? "Dashboard" : "Leaderboard"}
            </EcoButton>
          </div>
        </div>
      </main>
    </div>
  );
};
