import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Check, X, Trophy, PlayCircle } from "lucide-react";
import { toast } from "sonner";

interface Topic {
  id: string;
  title: string;
  emoji: string;
  content: string;
  image_url: string | null;
  video_url: string | null;
}
interface Question {
  id: string;
  question: string;
  options: string[];
  correct_index: number;
  explanation: string | null;
  points: number;
}

// Lightweight markdown-ish renderer: supports **bold**, lines starting with "- " or "1. ",
// and blank-line paragraph breaks. Keeps it dependency-free.
const renderContent = (text: string) => {
  const blocks = text.split(/\n\n+/);
  return blocks.map((block, bi) => {
    const lines = block.split("\n");
    const isList = lines.every((l) => /^\s*[-*]\s+/.test(l));
    const isOrdered = lines.every((l) => /^\s*\d+\.\s+/.test(l));

    const formatInline = (s: string) => {
      const parts = s.split(/(\*\*[^*]+\*\*)/g);
      return parts.map((p, i) =>
        p.startsWith("**") && p.endsWith("**") ? (
          <strong key={i} className="font-bold text-foreground">
            {p.slice(2, -2)}
          </strong>
        ) : (
          <span key={i}>{p}</span>
        ),
      );
    };

    if (isList) {
      return (
        <ul key={bi} className="list-disc pl-6 space-y-1 my-3">
          {lines.map((l, i) => (
            <li key={i}>{formatInline(l.replace(/^\s*[-*]\s+/, ""))}</li>
          ))}
        </ul>
      );
    }
    if (isOrdered) {
      return (
        <ol key={bi} className="list-decimal pl-6 space-y-1 my-3">
          {lines.map((l, i) => (
            <li key={i}>{formatInline(l.replace(/^\s*\d+\.\s+/, ""))}</li>
          ))}
        </ol>
      );
    }
    return (
      <p key={bi} className="my-3 leading-relaxed">
        {formatInline(block)}
      </p>
    );
  });
};

const LearnTopic = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [topic, setTopic] = useState<Topic | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [stage, setStage] = useState<"read" | "quiz" | "done">("read");
  const [qIndex, setQIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  useEffect(() => {
    (async () => {
      const [{ data: t }, { data: q }] = await Promise.all([
        supabase.from("learning_topics").select("*").eq("id", id).single(),
        supabase.from("quiz_questions").select("*").eq("topic_id", id).order("order_index"),
      ]);
      setTopic(t as any);
      setQuestions(((q ?? []) as any[]).map((x) => ({ ...x, options: x.options as string[] })));
    })();
  }, [id]);

  const submitAnswer = () => {
    if (picked === null) return;
    const q = questions[qIndex];
    const correct = picked === q.correct_index;
    if (correct) setScore((s) => s + q.points);
    toast(correct ? "Correct! +" + q.points : "Not quite", {
      description: q.explanation ?? "",
      icon: correct ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />,
    });
    setTimeout(() => {
      if (qIndex + 1 >= questions.length) {
        finish(correct ? score + q.points : score);
      } else {
        setQIndex((i) => i + 1);
        setPicked(null);
      }
    }, 1200);
  };

  const finish = async (finalScore: number) => {
    setStage("done");
    if (user && topic) {
      await supabase.from("quiz_attempts").insert({
        user_id: user.id,
        topic_id: topic.id,
        score: finalScore,
        total: questions.reduce((sum, q) => sum + q.points, 0),
      });
    }
  };

  if (!topic)
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="container py-10">Loading…</div>
      </div>
    );

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container py-8 max-w-3xl">
        <Link
          to="/learn"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="w-4 h-4" /> All topics
        </Link>

        {stage === "read" && (
          <div className="animate-fade-in">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-5xl">{topic.emoji}</span>
              <h1 className="text-3xl md:text-4xl font-extrabold">{topic.title}</h1>
            </div>

            {topic.image_url && (
              <div className="rounded-2xl overflow-hidden mb-6 border-2 border-border shadow-pop">
                <img
                  src={topic.image_url}
                  alt={topic.title}
                  className="w-full h-56 md:h-72 object-cover"
                  loading="lazy"
                />
              </div>
            )}

            <Card className="p-6 mb-6 text-foreground/90">{renderContent(topic.content)}</Card>

            {topic.video_url && (
              <Card className="p-4 mb-6">
                <div className="flex items-center gap-2 mb-3 font-bold">
                  <PlayCircle className="w-5 h-5 text-primary" />
                  Watch & learn
                </div>
                <div className="aspect-video w-full rounded-xl overflow-hidden bg-muted">
                  <iframe
                    src={topic.video_url}
                    title={`${topic.title} video`}
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              </Card>
            )}

            <Button
              size="lg"
              className="w-full"
              disabled={questions.length === 0}
              onClick={() => setStage("quiz")}
            >
              {questions.length === 0
                ? "No quiz yet"
                : `Start quiz (${questions.length} questions)`}
            </Button>
          </div>
        )}

        {stage === "quiz" && questions[qIndex] && (
          <div className="animate-fade-in">
            <div className="flex items-center justify-between mb-4 text-sm font-bold">
              <span>
                Question {qIndex + 1} / {questions.length}
              </span>
              <span className="text-primary">Score: {score}</span>
            </div>
            <Card className="p-6 mb-4">
              <h2 className="text-xl font-bold mb-6">{questions[qIndex].question}</h2>
              <div className="space-y-2">
                {questions[qIndex].options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => setPicked(i)}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                      picked === i
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </Card>
            <Button size="lg" className="w-full" disabled={picked === null} onClick={submitAnswer}>
              Submit answer
            </Button>
          </div>
        )}

        {stage === "done" && (
          <Card className="p-8 text-center animate-scale-in">
            <Trophy className="w-16 h-16 mx-auto text-primary mb-4" />
            <h2 className="text-3xl font-extrabold mb-2">Quiz complete!</h2>
            <p className="text-muted-foreground mb-1">You scored</p>
            <p className="text-5xl font-extrabold text-primary mb-6">{score} pts</p>
            <div className="flex gap-2 justify-center">
              <Button variant="outline" onClick={() => navigate("/learn")}>
                More topics
              </Button>
              <Button onClick={() => navigate("/dashboard")}>My dashboard</Button>
            </div>
          </Card>
        )}
      </main>
    </div>
  );
};

export default LearnTopic;
