import { useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Target, Upload, Clock, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

interface Challenge {
  id: string;
  title: string;
  description: string;
  points: number;
  emoji: string;
}

interface Submission {
  id: string;
  challenge_id: string;
  status: string;
  awarded_points: number;
  image_url: string;
  created_at: string;
}

const Challenges = () => {
  const { user } = useAuth();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [subs, setSubs] = useState<Submission[]>([]);
  const [active, setActive] = useState<Challenge | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [note, setNote] = useState("");
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    const { data: ch } = await supabase.from("challenges").select("*").eq("active", true).order("created_at");
    setChallenges((ch ?? []) as Challenge[]);
    if (user) {
      const { data: s } = await supabase
        .from("challenge_submissions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      setSubs((s ?? []) as Submission[]);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const submit = async () => {
    if (!user || !active || !file) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `${user.id}/${active.id}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("challenge-proofs").upload(path, file);
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("challenge-proofs").getPublicUrl(path);
      const { error: insErr } = await supabase.from("challenge_submissions").insert({
        user_id: user.id,
        challenge_id: active.id,
        image_url: pub.publicUrl,
        note,
        awarded_points: active.points,
      });
      if (insErr) throw insErr;
      toast.success("Submitted! Awaiting review.");
      setActive(null);
      setFile(null);
      setNote("");
      load();
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const statusOf = (id: string) => subs.find((s) => s.challenge_id === id)?.status;

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container py-10">
        <div className="flex items-center gap-3 mb-2">
          <Target className="w-8 h-8 text-primary" />
          <h1 className="text-4xl font-extrabold">Real-world Challenges</h1>
        </div>
        <p className="text-muted-foreground mb-8">Do an eco-task in real life. Snap a photo. Earn points.</p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {challenges.map((c, i) => {
            const status = statusOf(c.id);
            return (
              <Card
                key={c.id}
                className="p-5 border-2 hover:border-primary hover:-translate-y-1 transition-all animate-fade-in"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className="text-4xl mb-2">{c.emoji}</div>
                <h3 className="font-extrabold text-lg mb-1">{c.title}</h3>
                <p className="text-sm text-muted-foreground mb-3 min-h-[40px]">{c.description}</p>
                <div className="flex items-center justify-between">
                  <Badge className="bg-primary text-primary-foreground">+{c.points} pts</Badge>
                  {status === "approved" && (
                    <span className="flex items-center gap-1 text-xs font-bold text-primary">
                      <CheckCircle2 className="w-3 h-3" /> Approved
                    </span>
                  )}
                  {status === "pending" && (
                    <span className="flex items-center gap-1 text-xs font-bold text-muted-foreground">
                      <Clock className="w-3 h-3" /> Pending
                    </span>
                  )}
                  {status === "rejected" && (
                    <span className="flex items-center gap-1 text-xs font-bold text-destructive">
                      <XCircle className="w-3 h-3" /> Rejected
                    </span>
                  )}
                </div>
                <Button
                  className="w-full mt-3"
                  size="sm"
                  disabled={!user || status === "pending" || status === "approved"}
                  onClick={() => setActive(c)}
                >
                  <Upload className="w-4 h-4 mr-1" />
                  {status === "approved" ? "Done" : status === "pending" ? "In review" : "Submit proof"}
                </Button>
              </Card>
            );
          })}
        </div>

        {!user && (
          <p className="mt-6 text-center text-sm text-muted-foreground">Sign in to submit challenges.</p>
        )}

        <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{active?.emoji} {active?.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">{active?.description}</p>
              <div>
                <label className="text-sm font-bold block mb-1">Photo proof</label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                />
              </div>
              <div>
                <label className="text-sm font-bold block mb-1">Note (optional)</label>
                <Textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="What did you do?"
                  maxLength={300}
                />
              </div>
              <Button onClick={submit} disabled={!file || uploading} className="w-full">
                {uploading ? "Uploading…" : `Submit for +${active?.points} pts`}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
};

export default Challenges;
