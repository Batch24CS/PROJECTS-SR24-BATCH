import { Link } from "react-router-dom";
import { Recycle, Flame, Droplet, Trees, Zap, Lock } from "lucide-react";
import { Navbar } from "@/components/Navbar";

const games = [
  { slug: "waste-segregation", title: "Waste Segregation", desc: "Sort items into the right bins.", icon: Recycle, available: true, color: "bg-primary text-primary-foreground shadow-pop" },
  { slug: "carbon-footprint", title: "Carbon Footprint", desc: "Choose, simulate, reduce.", icon: Flame, available: true, color: "bg-accent text-accent-foreground shadow-pop-accent" },
  { slug: "water", title: "Water Hero", desc: "Stop the leaks before it overflows.", icon: Droplet, available: true, color: "bg-accent text-accent-foreground shadow-pop-accent" },
  { slug: "trees", title: "Tree Planter", desc: "Grow a thriving forest.", icon: Trees, available: true, color: "bg-primary text-primary-foreground shadow-pop" },
  { slug: "energy", title: "Energy Saver", desc: "Master your appliances.", icon: Zap, available: true, color: "bg-gold text-gold-foreground shadow-pop-gold" },
];

const Games = () => (
  <div className="min-h-screen bg-sky-fade">
    <Navbar />
    <main className="container py-10">
      <h1 className="text-4xl mb-2">Games</h1>
      <p className="text-muted-foreground mb-8">Pick a quest and start learning by playing.</p>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
        {games.map((g) => {
          const card = (
            <div className={`bg-card rounded-3xl p-6 shadow-card border-2 border-border h-full ${g.available ? "hover:-translate-y-1 transition-transform cursor-pointer" : "opacity-60"}`}>
              <div className={`w-14 h-14 rounded-2xl grid place-items-center mb-4 ${g.color}`}>
                {g.available ? <g.icon className="w-7 h-7" /> : <Lock className="w-6 h-6" />}
              </div>
              <h3 className="text-xl mb-1">{g.title}</h3>
              <p className="text-muted-foreground">{g.desc}</p>
              {!g.available && <p className="mt-3 text-sm font-bold text-muted-foreground">Coming soon</p>}
            </div>
          );
          return g.available ? <Link key={g.slug} to={`/games/${g.slug}`}>{card}</Link> : <div key={g.slug}>{card}</div>;
        })}
      </div>
    </main>
  </div>
);

export default Games;
