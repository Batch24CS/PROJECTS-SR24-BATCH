import { useEffect, useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { z } from "zod";
import { Leaf } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { EcoButton } from "@/components/EcoButton";
import { toast } from "sonner";

const signUpSchema = z.object({
  name: z.string().trim().min(2, "Name too short").max(80),
  email: z.string().trim().email("Invalid email").max(255),
  password: z.string().min(6, "Min 6 characters").max(72),
  role: z.enum(["student", "teacher"]),
});
const signInSchema = z.object({
  email: z.string().trim().email("Invalid email"),
  password: z.string().min(1, "Password required"),
});

const Auth = () => {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">(
    params.get("mode") === "signup" ? "signup" : "signin",
  );
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "student" as "student" | "teacher" });

  useEffect(() => { if (user) navigate("/dashboard"); }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const parsed = signUpSchema.safeParse(form);
        if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
        const { error } = await supabase.auth.signUp({
          email: parsed.data.email,
          password: parsed.data.password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { name: parsed.data.name, role: parsed.data.role },
          },
        });
        if (error) {
          if (error.message.includes("already")) toast.error("That email is already registered. Try logging in.");
          else toast.error(error.message);
          return;
        }
        toast.success("Welcome to EcoQuest! 🌱");
        navigate("/dashboard");
      } else {
        const parsed = signInSchema.safeParse(form);
        if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
        const { error } = await supabase.auth.signInWithPassword({
          email: parsed.data.email,
          password: parsed.data.password,
        });
        if (error) { toast.error("Invalid email or password"); return; }
        navigate("/dashboard");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-sky-fade grid place-items-center p-4">
      <div className="w-full max-w-md">
        <Link to="/" className="flex items-center justify-center gap-2 font-extrabold text-2xl mb-6">
          <span className="w-10 h-10 rounded-2xl bg-primary text-primary-foreground grid place-items-center shadow-pop">
            <Leaf className="w-6 h-6" />
          </span>
          EcoQuest
        </Link>
        <div className="bg-card rounded-3xl p-8 shadow-card border-2 border-border">
          <h1 className="text-3xl mb-2">{mode === "signup" ? "Start your quest" : "Welcome back"}</h1>
          <p className="text-muted-foreground mb-6">
            {mode === "signup" ? "Create an account to save your progress." : "Log in to continue learning."}
          </p>
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "signup" && (
              <>
                <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
                <div>
                  <label className="text-sm font-bold mb-1.5 block">I am a…</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["student", "teacher"] as const).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setForm({ ...form, role: r })}
                        className={`h-12 rounded-2xl font-bold capitalize border-2 transition-all ${
                          form.role === r
                            ? "border-primary bg-secondary text-primary"
                            : "border-border bg-card hover:bg-secondary"
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
            <Field label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
            <Field label="Password" type="password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} />
            <EcoButton type="submit" size="lg" className="w-full" disabled={loading}>
              {loading ? "Loading…" : mode === "signup" ? "Create account" : "Log in"}
            </EcoButton>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-6">
            {mode === "signup" ? "Already have an account? " : "New here? "}
            <button
              className="text-primary font-bold hover:underline"
              onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
            >
              {mode === "signup" ? "Log in" : "Sign up"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

const Field = ({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) => (
  <div>
    <label className="text-sm font-bold mb-1.5 block">{label}</label>
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full h-12 px-4 rounded-2xl border-2 border-border bg-card focus:outline-none focus:border-primary transition-colors"
      required
    />
  </div>
);

export default Auth;
