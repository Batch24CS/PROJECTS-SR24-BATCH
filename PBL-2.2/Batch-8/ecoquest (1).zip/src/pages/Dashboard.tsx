import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Recycle, Trophy, Flame, Star, Droplet, Trees, Zap } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

interface Profile { name: string; total_points: number; }
interface Progress { game_slug: string; score: number; level: number; created_at: string; }

const Dashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [progress, setProgress] = useState<Progress[]>([]);

  useEffect(() => {
    if (!authLoading && !user) navigate("/auth");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [{ data: p }, { data: g }] = await Promise.all([
        supabase.from("profiles").select("name, total_points").eq("id", user.id).maybeSingle(),
        supabase.from("game_progress").select("game_slug, score, level, created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(10),
      ]);
      if (p) setProfile(p);
      if (g) setProgress(g);
    })();
  }, [user]);

  const level = Math.floor((profile?.total_points ?? 0) / 100) + 1;
  const progressInLevel = (profile?.total_points ?? 0) % 100;

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-10 space-y-8">
        <div>
          <p className="text-muted-foreground font-bold">Welcome back,</p>
          <h1 className="text-4xl">{profile?.name ?? "Eco Hero"} 🌱</h1>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4">
          <StatCard icon={Star} label="Total points" value={profile?.total_points ?? 0} variant="gold" />
          <StatCard icon={Trophy} label="Level" value={level} variant="primary" />
          <StatCard icon={Flame} label="Games played" value={progress.length} variant="accent" />
        </div>

        {/* Level progress bar */}
        <div className="bg-card rounded-3xl p-6 shadow-card border-2 border-border">
          <div className="flex justify-between items-center mb-3">
            <span className="font-extrabold">Level {level}</span>
            <span className="font-bold text-muted-foreground">{progressInLevel} / 100 XP</span>
          </div>
          <div className="h-4 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-hero transition-all" style={{ width: `${progressInLevel}%` }} />
          </div>
        </div>

        {/* Games */}
        <section>
          <h2 className="text-2xl mb-4">Continue learning</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <GameCard title="Waste Segregation" desc="Sort items into the right bins." icon={Recycle} to="/games/waste-segregation" available />
            <GameCard title="Carbon Footprint" desc="Calculate your annual CO₂." icon={Flame} to="/games/carbon-footprint" available />
            <GameCard title="Water Hero" desc="Stop leaks before the bucket overflows." icon={Droplet} to="/games/water" available />
            <GameCard title="Tree Planter" desc="Grow a thriving forest." icon={Trees} to="/games/trees" available />
            <GameCard title="Energy Saver" desc="Audit a virtual home." icon={Zap} to="/games/energy" available />
          </div>
        </section>

        {/* Recent activity */}
        <section>
          <h2 className="text-2xl mb-4">Recent activity</h2>
          <div className="bg-card rounded-3xl border-2 border-border overflow-hidden">
            {progress.length === 0 ? (
              <p className="p-8 text-center text-muted-foreground">No games played yet. Try one above! 👆</p>
            ) : (
              <ul className="divide-y-2 divide-border">
                {progress.map((p, i) => (
                  <li key={i} className="flex justify-between items-center p-4">
                    <div>
                      <p className="font-bold capitalize">{p.game_slug.replace(/-/g, " ")}</p>
                      <p className="text-sm text-muted-foreground">Level {p.level} • {new Date(p.created_at).toLocaleDateString()}</p>
                    </div>
                    <span className="font-extrabold text-primary">+{p.score}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

const StatCard = ({ icon: I, label, value, variant }: { icon: any; label: string; value: number; variant: "gold" | "primary" | "accent" }) => {
  const styles = {
    gold: "bg-gold text-gold-foreground shadow-pop-gold",
    primary: "bg-primary text-primary-foreground shadow-pop",
    accent: "bg-accent text-accent-foreground shadow-pop-accent",
  }[variant];
  return (
    <div className={`${styles} rounded-3xl p-6`}>
      <I className="w-7 h-7 mb-2" />
      <p className="text-sm font-bold uppercase opacity-90">{label}</p>
      <p className="text-3xl font-extrabold">{value}</p>
    </div>
  );
};

const GameCard = ({ title, desc, icon: I, to, available }: { title: string; desc: string; icon: any; to: string; available?: boolean }) => {
  const inner = (
    <div className={`bg-card rounded-3xl p-6 shadow-card border-2 border-border h-full ${available ? "hover:-translate-y-1 transition-transform cursor-pointer" : "opacity-60"}`}>
      <div className="w-12 h-12 rounded-2xl bg-secondary text-primary grid place-items-center mb-4">
        <I className="w-6 h-6" />
      </div>
      <h3 className="text-lg mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground mb-4">{desc}</p>
      {available && <EcoButton size="sm">Play</EcoButton>}
    </div>
  );
  return available ? <Link to={to}>{inner}</Link> : <div>{inner}</div>;
};

export default Dashboard;
