import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Recycle, Apple, Trash2, Trophy, RotateCcw, Check, X } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Bin = "recyclable" | "organic" | "landfill";
interface Item { id: number; name: string; emoji: string; bin: Bin; explain: string; }

const ITEMS: Item[] = [
  { id: 1, name: "Banana peel", emoji: "🍌", bin: "organic", explain: "Banana peels compost into rich soil within weeks." },
  { id: 2, name: "Plastic bottle", emoji: "🥤", bin: "recyclable", explain: "PET bottles can be recycled into new bottles or fabric." },
  { id: 3, name: "Pizza box (greasy)", emoji: "🍕", bin: "landfill", explain: "Grease contaminates paper recycling — sadly it goes to landfill." },
  { id: 4, name: "Newspaper", emoji: "📰", bin: "recyclable", explain: "Clean paper is recycled up to 7 times before fibers wear out." },
  { id: 5, name: "Apple core", emoji: "🍎", bin: "organic", explain: "Apple cores compost in just a few weeks." },
  { id: 6, name: "Glass jar", emoji: "🫙", bin: "recyclable", explain: "Glass is 100% recyclable — endlessly!" },
  { id: 7, name: "Used tissue", emoji: "🤧", bin: "landfill", explain: "Used tissues can't be recycled due to contamination." },
  { id: 8, name: "Aluminum can", emoji: "🥫", bin: "recyclable", explain: "Recycling aluminum saves 95% of the energy vs. making new." },
  { id: 9, name: "Eggshells", emoji: "🥚", bin: "organic", explain: "Eggshells add calcium to compost." },
  { id: 10, name: "Styrofoam cup", emoji: "☕", bin: "landfill", explain: "Styrofoam takes 500+ years to decompose and isn't widely recyclable." },
];

const BINS: { id: Bin; label: string; icon: any; color: string }[] = [
  { id: "recyclable", label: "Recyclable", icon: Recycle, color: "bg-accent text-accent-foreground shadow-pop-accent" },
  { id: "organic", label: "Organic", icon: Apple, color: "bg-primary text-primary-foreground shadow-pop" },
  { id: "landfill", label: "Landfill", icon: Trash2, color: "bg-muted-foreground/80 text-background shadow-pop" },
];

const shuffle = <T,>(a: T[]) => [...a].sort(() => Math.random() - 0.5);

const WasteSegregation = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [queue, setQueue] = useState<Item[]>(() => shuffle(ITEMS));
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [feedback, setFeedback] = useState<{ correct: boolean; item: Item } | null>(null);
  const [hoveredBin, setHoveredBin] = useState<Bin | null>(null);
  const [done, setDone] = useState(false);
  const [saved, setSaved] = useState(false);

  const current = queue[0];
  const total = ITEMS.length;
  const remaining = queue.length;
  const progress = useMemo(() => ((total - remaining) / total) * 100, [remaining, total]);

  const onDrop = (bin: Bin) => {
    if (!current || feedback) return;
    const correct = current.bin === bin;
    setFeedback({ correct, item: current });
    if (correct) {
      const points = 10 + streak * 2;
      setScore((s) => s + points);
      setStreak((s) => s + 1);
    } else {
      setStreak(0);
    }
  };

  const next = () => {
    setFeedback(null);
    setHoveredBin(null);
    const newQueue = queue.slice(1);
    setQueue(newQueue);
    if (newQueue.length === 0) setDone(true);
  };

  // Save when done
  useEffect(() => {
    if (!done || saved || !user) return;
    (async () => {
      const { error } = await supabase.from("game_progress").insert({
        user_id: user.id,
        game_slug: "waste-segregation",
        score,
        level: 1,
      });
      if (!error) {
        setSaved(true);
        toast.success(`Saved! +${score} points 🎉`);
      }
    })();
  }, [done, saved, user, score]);

  const restart = () => {
    setQueue(shuffle(ITEMS));
    setScore(0); setStreak(0); setDone(false); setSaved(false); setFeedback(null);
  };

  if (done) {
    return (
      <div className="min-h-screen bg-sky-fade">
        <Navbar />
        <main className="container py-16 max-w-xl">
          <div className="bg-card rounded-3xl p-10 shadow-card border-2 border-border text-center animate-bounce-in">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-gold text-gold-foreground grid place-items-center shadow-pop-gold mb-4">
              <Trophy className="w-10 h-10" />
            </div>
            <h1 className="text-3xl mb-2">Quest complete!</h1>
            <p className="text-muted-foreground mb-6">You scored</p>
            <p className="text-6xl font-extrabold text-primary mb-8">{score} pts</p>
            {!user && (
              <p className="text-sm text-muted-foreground mb-4">
                <button className="text-primary font-bold underline" onClick={() => navigate("/auth?mode=signup")}>Sign up</button> to save your score.
              </p>
            )}
            <div className="flex gap-3 justify-center">
              <EcoButton variant="outline" onClick={restart}><RotateCcw className="w-4 h-4" /> Play again</EcoButton>
              <EcoButton onClick={() => navigate(user ? "/dashboard" : "/leaderboard")}>
                {user ? "Dashboard" : "Leaderboard"}
              </EcoButton>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-8 max-w-3xl">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-2xl">Waste Segregation</h1>
            <p className="text-sm text-muted-foreground">Drag the item into the correct bin</p>
          </div>
          <div className="flex gap-3">
            <Pill label="Score" value={score} />
            <Pill label="Streak" value={`🔥${streak}`} />
          </div>
        </div>

        {/* Progress */}
        <div className="h-3 bg-secondary rounded-full overflow-hidden mb-8">
          <div className="h-full bg-hero transition-all" style={{ width: `${progress}%` }} />
        </div>

        {/* Item to drag */}
        <div className="grid place-items-center mb-10">
          {current && !feedback && (
            <div
              draggable
              onDragEnd={() => setHoveredBin(null)}
              className="bg-card rounded-3xl p-8 shadow-card border-2 border-border text-center cursor-grab active:cursor-grabbing animate-bounce-in select-none"
              style={{ minWidth: 220 }}
            >
              <div className="text-7xl mb-3">{current.emoji}</div>
              <p className="font-extrabold text-lg">{current.name}</p>
            </div>
          )}
          {feedback && (
            <div className={`rounded-3xl p-8 border-2 max-w-md text-center animate-bounce-in ${feedback.correct ? "bg-secondary border-primary" : "bg-destructive/10 border-destructive"}`}>
              <div className={`w-14 h-14 mx-auto rounded-2xl grid place-items-center mb-3 ${feedback.correct ? "bg-primary text-primary-foreground" : "bg-destructive text-destructive-foreground"}`}>
                {feedback.correct ? <Check className="w-7 h-7" /> : <X className="w-7 h-7" />}
              </div>
              <p className="font-extrabold text-xl mb-1">{feedback.correct ? "Correct!" : "Not quite"}</p>
              <p className="text-muted-foreground mb-4">{feedback.item.explain}</p>
              <EcoButton onClick={next}>Next →</EcoButton>
            </div>
          )}
        </div>

        {/* Bins */}
        <div className="grid grid-cols-3 gap-3">
          {BINS.map((b) => (
            <div
              key={b.id}
              onDragOver={(e) => { e.preventDefault(); setHoveredBin(b.id); }}
              onDragLeave={() => setHoveredBin(null)}
              onDrop={() => onDrop(b.id)}
              onClick={() => onDrop(b.id)}
              className={`${b.color} rounded-3xl p-6 text-center cursor-pointer transition-transform ${hoveredBin === b.id ? "scale-105" : ""}`}
            >
              <b.icon className="w-8 h-8 mx-auto mb-2" />
              <p className="font-extrabold uppercase text-sm">{b.label}</p>
            </div>
          ))}
        </div>
        <p className="text-center text-xs text-muted-foreground mt-3">Tip: tap a bin if drag-and-drop isn't working.</p>
      </main>
    </div>
  );
};

const Pill = ({ label, value }: { label: string; value: string | number }) => (
  <div className="bg-card border-2 border-border rounded-2xl px-4 py-2 text-center">
    <p className="text-[10px] uppercase font-bold text-muted-foreground">{label}</p>
    <p className="font-extrabold">{value}</p>
  </div>
);

export default WasteSegregation;
