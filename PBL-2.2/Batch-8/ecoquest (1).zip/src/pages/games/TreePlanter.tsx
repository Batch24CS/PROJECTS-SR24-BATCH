import { useEffect, useState } from "react";
import { Trees as TreesIcon, Sprout, Sun, Droplet, Scissors } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";
import { GameHeader, CompleteScreen } from "@/components/GameShell";
import { useAuth } from "@/hooks/useAuth";
import { saveGameProgress } from "@/lib/saveProgress";

/**
 * Tree Planter — grow a forest by making the right care choice each round.
 * 8 saplings. Each round shows a problem; pick the right action to grow it.
 * A wrong action wilts the sapling.
 */

type Action = "water" | "sun" | "prune" | "plant";

interface Round {
  prompt: string;
  hint: string;
  correct: Action;
  fact: string;
}

const ROUNDS: Round[] = [
  { prompt: "A bare patch of soil sits in the morning sun.", hint: "Start something new", correct: "plant", fact: "One mature tree absorbs ~22 kg of CO₂ per year." },
  { prompt: "The sapling's leaves are drooping and soil is dry.", hint: "Quench its thirst", correct: "water", fact: "Young trees need ~10–15 L of water per week." },
  { prompt: "Dense canopy is blocking light from a struggling shoot.", hint: "Open the canopy", correct: "prune", fact: "Pruning improves airflow and reduces disease." },
  { prompt: "The sapling sits in deep shade all day.", hint: "It needs more light", correct: "sun", fact: "Most native trees need 6+ hours of sun." },
  { prompt: "An empty plot near the school playground.", hint: "Add greenery", correct: "plant", fact: "Urban trees can cool streets by up to 8°C." },
  { prompt: "Yellowing leaves after a hot, dry week.", hint: "Hydrate!", correct: "water", fact: "Mulching keeps soil moisture in for longer." },
  { prompt: "Tangled, crossing branches are damaging each other.", hint: "Trim carefully", correct: "prune", fact: "Late winter is the best time to prune most trees." },
  { prompt: "A rainforest clearing is regrowing — find it light.", hint: "Sunlight please", correct: "sun", fact: "Forests produce 28% of Earth's oxygen." },
];

const ACTIONS: { id: Action; label: string; icon: any; color: string }[] = [
  { id: "plant", label: "Plant", icon: Sprout, color: "bg-primary text-primary-foreground shadow-pop" },
  { id: "water", label: "Water", icon: Droplet, color: "bg-accent text-accent-foreground shadow-pop-accent" },
  { id: "prune", label: "Prune", icon: Scissors, color: "bg-gold text-gold-foreground shadow-pop-gold" },
  { id: "sun", label: "Sunlight", icon: Sun, color: "bg-gold text-gold-foreground shadow-pop-gold" },
];

const TreePlanter = () => {
  const { user } = useAuth();
  const [round, setRound] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [forest, setForest] = useState<("alive" | "wilted")[]>([]);
  const [feedback, setFeedback] = useState<{ correct: boolean; fact: string } | null>(null);
  const [done, setDone] = useState(false);
  const [saved, setSaved] = useState(false);

  const current = ROUNDS[round];

  const choose = (a: Action) => {
    if (feedback) return;
    const correct = a === current.correct;
    setFeedback({ correct, fact: current.fact });
    setForest((f) => [...f, correct ? "alive" : "wilted"]);
    if (correct) {
      setScore((s) => s + 15 + streak * 3);
      setStreak((s) => s + 1);
    } else {
      setStreak(0);
    }
  };

  const next = () => {
    setFeedback(null);
    if (round + 1 >= ROUNDS.length) {
      setDone(true);
    } else {
      setRound((r) => r + 1);
    }
  };

  useEffect(() => {
    if (!done || saved || !user) return;
    saveGameProgress(user.id, "trees", score).then(() => setSaved(true));
  }, [done, saved, user, score]);

  const restart = () => {
    setRound(0); setScore(0); setStreak(0); setForest([]);
    setFeedback(null); setDone(false); setSaved(false);
  };

  if (done) {
    const alive = forest.filter((f) => f === "alive").length;
    return (
      <CompleteScreen
        score={score}
        message={`You grew ${alive}/${ROUNDS.length} trees!`}
        detail={
          <div className="bg-secondary rounded-2xl p-4 text-sm">
            <p className="font-bold mb-1">🌳 Your forest</p>
            <div className="flex gap-1 flex-wrap text-2xl">
              {forest.map((f, i) => <span key={i}>{f === "alive" ? "🌳" : "🥀"}</span>)}
            </div>
          </div>
        }
        onRestart={restart}
      />
    );
  }

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-8 max-w-3xl">
        <GameHeader
          title="Tree Planter"
          subtitle="Choose the right action to help each tree thrive."
          pills={[
            { label: "Score", value: score },
            { label: "Streak", value: `🔥${streak}` },
            { label: "Round", value: `${round + 1}/${ROUNDS.length}` },
          ]}
          progress={(round / ROUNDS.length) * 100}
        />

        {/* Forest progress */}
        <div className="bg-card border-2 border-border rounded-2xl p-3 mb-6 flex gap-1 flex-wrap text-2xl min-h-[3rem]">
          {forest.length === 0 && <span className="text-muted-foreground text-sm font-bold">Your forest will grow here…</span>}
          {forest.map((f, i) => <span key={i}>{f === "alive" ? "🌳" : "🥀"}</span>)}
        </div>

        {/* Scenario */}
        {!feedback ? (
          <div className="bg-card rounded-3xl p-8 shadow-card border-2 border-border mb-6 animate-bounce-in">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-secondary text-primary grid place-items-center mb-4">
              <TreesIcon className="w-8 h-8" />
            </div>
            <p className="text-center text-xl font-extrabold mb-2">{current.prompt}</p>
            <p className="text-center text-sm text-muted-foreground">{current.hint}</p>
          </div>
        ) : (
          <div className={`rounded-3xl p-8 mb-6 border-2 text-center animate-bounce-in ${feedback.correct ? "bg-secondary border-primary" : "bg-destructive/10 border-destructive"}`}>
            <p className="font-extrabold text-xl mb-2">{feedback.correct ? "🌱 It's thriving!" : "🥀 It wilted."}</p>
            <p className="text-muted-foreground mb-4">{feedback.fact}</p>
            <EcoButton onClick={next}>{round + 1 >= ROUNDS.length ? "See forest" : "Next round"} →</EcoButton>
          </div>
        )}

        {/* Actions */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {ACTIONS.map((a) => (
            <button
              key={a.id}
              onClick={() => choose(a.id)}
              disabled={!!feedback}
              className={`${a.color} rounded-3xl p-4 transition-transform hover:-translate-y-0.5 active:translate-y-1 active:shadow-none disabled:opacity-50 disabled:pointer-events-none`}
            >
              <a.icon className="w-7 h-7 mx-auto mb-1" />
              <p className="font-extrabold uppercase text-xs">{a.label}</p>
            </button>
          ))}
        </div>
      </main>
    </div>
  );
};

export default TreePlanter;
