import { useEffect, useMemo, useState } from "react";
import { Car, Beef, Plane, Home, Recycle, ArrowLeft, ArrowRight, Sparkles } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";
import { CompleteScreen } from "@/components/GameShell";
import { useAuth } from "@/hooks/useAuth";
import { saveGameProgress } from "@/lib/saveProgress";

/**
 * Carbon Footprint Simulator — multi-question lifestyle quiz.
 * Approximate annual CO2e in kg. Tips generated based on choices.
 * Score = max(0, 1000 - normalizedCO2). Higher score = lower footprint.
 */

interface Option {
  label: string;
  co2: number; // annual kg CO2e impact
  tip?: string;
}
interface Question {
  id: string;
  icon: any;
  title: string;
  subtitle: string;
  options: Option[];
}

const QUESTIONS: Question[] = [
  {
    id: "transport",
    icon: Car,
    title: "How do you commute most days?",
    subtitle: "Daily transport is one of the biggest personal emissions.",
    options: [
      { label: "Walk, bike, or work from home", co2: 0, tip: "Active travel is the gold standard 🚴" },
      { label: "Public transit", co2: 700, tip: "Buses and trains cut emissions per passenger by ~50%." },
      { label: "Small / electric car", co2: 1500 },
      { label: "Large car or SUV alone", co2: 4500, tip: "Try carpooling 1–2 days a week to cut this in half." },
    ],
  },
  {
    id: "diet",
    icon: Beef,
    title: "What's your typical diet?",
    subtitle: "Food production accounts for ~25% of global emissions.",
    options: [
      { label: "Mostly plant-based", co2: 1100, tip: "Plant-forward meals can cut food emissions in half." },
      { label: "Vegetarian", co2: 1400 },
      { label: "Some meat, lots of veg", co2: 2000 },
      { label: "Meat with most meals", co2: 3300, tip: "Try 'Meatless Mondays' to start small." },
    ],
  },
  {
    id: "flights",
    icon: Plane,
    title: "How often do you fly?",
    subtitle: "A single long-haul flight can outweigh a year of careful choices.",
    options: [
      { label: "I don't fly", co2: 0 },
      { label: "1 short flight per year", co2: 250 },
      { label: "A few short flights per year", co2: 900 },
      { label: "1+ long-haul flights per year", co2: 2200, tip: "Choose train for trips under 6 hours when possible." },
    ],
  },
  {
    id: "home",
    icon: Home,
    title: "How energy-efficient is your home?",
    subtitle: "Heating, cooling, and electricity add up year-round.",
    options: [
      { label: "Renewable energy + efficient appliances", co2: 600, tip: "You're crushing it 🌟" },
      { label: "Mostly efficient, mixed energy", co2: 1500 },
      { label: "Average home, no special effort", co2: 2700 },
      { label: "AC/heat always on, old appliances", co2: 4500, tip: "An LED swap and a smart thermostat pay back fast." },
    ],
  },
  {
    id: "shopping",
    icon: Recycle,
    title: "How do you shop for clothes & gadgets?",
    subtitle: "Stuff has a hidden carbon cost from production & shipping.",
    options: [
      { label: "Buy used, repair, rarely upgrade", co2: 200, tip: "Circular consumption FTW ♻️" },
      { label: "Buy new only when needed", co2: 600 },
      { label: "Regular new purchases", co2: 1100 },
      { label: "Frequent fast-fashion / new tech", co2: 2000, tip: "Try a 30-day 'do I really need it?' rule." },
    ],
  },
];

const GLOBAL_AVERAGE = 4800; // global per-capita rough avg used for visual context

const CarbonFootprint = () => {
  const { user } = useAuth();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({}); // question.id -> option index
  const [done, setDone] = useState(false);
  const [saved, setSaved] = useState(false);

  const total = useMemo(
    () => Object.entries(answers).reduce((sum, [qid, idx]) => {
      const q = QUESTIONS.find((q) => q.id === qid)!;
      return sum + q.options[idx].co2;
    }, 0),
    [answers],
  );

  // Score: lower CO2 = higher score. 0 kg => 1000 pts; 12000 kg => 0 pts.
  const score = Math.max(0, Math.round(1000 - (total / 12000) * 1000));
  const allAnswered = Object.keys(answers).length === QUESTIONS.length;

  useEffect(() => {
    if (!done || saved || !user) return;
    saveGameProgress(user.id, "carbon-footprint", score).then(() => setSaved(true));
  }, [done, saved, user, score]);

  const restart = () => {
    setStep(0); setAnswers({}); setDone(false); setSaved(false);
  };

  if (done) {
    const tips = QUESTIONS
      .map((q) => q.options[answers[q.id]]?.tip)
      .filter(Boolean) as string[];
    const vsAvg = total - GLOBAL_AVERAGE;
    return (
      <CompleteScreen
        score={score}
        message="Footprint calculated!"
        detail={
          <div className="space-y-3 text-sm">
            <div className="bg-secondary rounded-2xl p-4">
              <p className="font-bold mb-1">🌍 Estimated annual CO₂e</p>
              <p className="text-3xl font-extrabold text-primary">{total.toLocaleString()} kg</p>
              <p className="text-muted-foreground mt-1">
                {vsAvg < 0
                  ? `That's ${Math.abs(vsAvg).toLocaleString()} kg below the global average. Excellent!`
                  : `That's ${vsAvg.toLocaleString()} kg above the global average — room to grow.`}
              </p>
            </div>
            {tips.length > 0 && (
              <div className="bg-card border-2 border-border rounded-2xl p-4">
                <p className="font-bold mb-2 flex items-center gap-1"><Sparkles className="w-4 h-4 text-gold" /> Personalized tips</p>
                <ul className="space-y-1.5 text-muted-foreground list-disc pl-5">
                  {tips.map((t, i) => <li key={i}>{t}</li>)}
                </ul>
              </div>
            )}
          </div>
        }
        onRestart={restart}
      />
    );
  }

  const q = QUESTIONS[step];
  const selected = answers[q.id];

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-8 max-w-2xl">
        {/* Progress */}
        <div className="flex items-center justify-between mb-3">
          <p className="font-bold text-sm text-muted-foreground">
            Question {step + 1} of {QUESTIONS.length}
          </p>
          <p className="font-extrabold text-sm">~{total.toLocaleString()} kg CO₂e so far</p>
        </div>
        <div className="h-3 bg-secondary rounded-full overflow-hidden mb-8">
          <div className="h-full bg-hero transition-all" style={{ width: `${((step) / QUESTIONS.length) * 100}%` }} />
        </div>

        {/* Question */}
        <div className="bg-card rounded-3xl p-6 sm:p-8 shadow-card border-2 border-border mb-6 animate-bounce-in">
          <div className="w-14 h-14 rounded-2xl bg-secondary text-primary grid place-items-center mb-4">
            <q.icon className="w-7 h-7" />
          </div>
          <h1 className="text-2xl mb-1">{q.title}</h1>
          <p className="text-muted-foreground mb-6">{q.subtitle}</p>

          <div className="space-y-2.5">
            {q.options.map((opt, i) => {
              const active = selected === i;
              return (
                <button
                  key={i}
                  onClick={() => setAnswers((a) => ({ ...a, [q.id]: i }))}
                  className={`w-full text-left p-4 rounded-2xl border-2 font-bold transition-all ${
                    active
                      ? "border-primary bg-secondary"
                      : "border-border bg-card hover:bg-secondary"
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Nav */}
        <div className="flex justify-between gap-3">
          <EcoButton variant="outline" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>
            <ArrowLeft className="w-4 h-4" /> Back
          </EcoButton>
          {step < QUESTIONS.length - 1 ? (
            <EcoButton onClick={() => setStep((s) => s + 1)} disabled={selected === undefined}>
              Next <ArrowRight className="w-4 h-4" />
            </EcoButton>
          ) : (
            <EcoButton onClick={() => setDone(true)} disabled={!allAnswered}>
              See my footprint
            </EcoButton>
          )}
        </div>
      </main>
    </div>
  );
};

export default CarbonFootprint;
