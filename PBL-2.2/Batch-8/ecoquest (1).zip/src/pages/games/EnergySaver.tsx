import { useEffect, useState } from "react";
import { Lightbulb, Tv, Refrigerator, Wind, WashingMachine, Power, Zap } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";
import { GameHeader, CompleteScreen } from "@/components/GameShell";
import { useAuth } from "@/hooks/useAuth";
import { saveGameProgress } from "@/lib/saveProgress";

/**
 * Energy Saver — a virtual home with appliances. Some are wasting energy.
 * Switch off unnecessary ones to lower the meter without turning off essentials.
 * 4 rooms / scenarios with a target wattage to hit.
 */

type ApplianceKey = string;

interface Appliance {
  key: ApplianceKey;
  name: string;
  icon: any;
  watts: number;
  needed: boolean; // true = should stay ON
  on: boolean;
  hint: string;
}

interface Scenario {
  title: string;
  description: string;
  targetMaxWatts: number;
  appliances: Appliance[];
}

const SCENARIOS: Scenario[] = [
  {
    title: "Living room — afternoon",
    description: "Sunlight is streaming in. The family is reading. What can you switch off?",
    targetMaxWatts: 50,
    appliances: [
      { key: "lr-light", name: "Ceiling lights", icon: Lightbulb, watts: 60, needed: false, on: true, hint: "Daylight is plenty." },
      { key: "lr-tv", name: "TV (no one watching)", icon: Tv, watts: 120, needed: false, on: true, hint: "Standby still drains power." },
      { key: "lr-fan", name: "Ceiling fan", icon: Wind, watts: 35, needed: true, on: true, hint: "Cooling helps avoid AC." },
      { key: "lr-router", name: "Wi‑Fi router", icon: Power, watts: 12, needed: true, on: true, hint: "Family is online." },
    ],
  },
  {
    title: "Kitchen — between meals",
    description: "Lunch is over and dinner is hours away.",
    targetMaxWatts: 200,
    appliances: [
      { key: "k-fridge", name: "Refrigerator", icon: Refrigerator, watts: 150, needed: true, on: true, hint: "Food must stay cold!" },
      { key: "k-light", name: "Bright ceiling light", icon: Lightbulb, watts: 80, needed: false, on: true, hint: "No one is cooking." },
      { key: "k-microwave", name: "Microwave (idle clock)", icon: Power, watts: 5, needed: false, on: true, hint: "Phantom load adds up." },
      { key: "k-kettle", name: "Kettle warm-keep", icon: Power, watts: 200, needed: false, on: true, hint: "Boil only when needed." },
    ],
  },
  {
    title: "Bedroom — daytime",
    description: "Everyone is at work and school.",
    targetMaxWatts: 10,
    appliances: [
      { key: "b-ac", name: "Air conditioner", icon: Wind, watts: 1500, needed: false, on: true, hint: "Empty room — turn it off." },
      { key: "b-charger", name: "Phone charger (no phone)", icon: Power, watts: 5, needed: false, on: true, hint: "Unplug to save power." },
      { key: "b-lamp", name: "Bedside lamp", icon: Lightbulb, watts: 40, needed: false, on: true, hint: "Daylight outside." },
      { key: "b-clock", name: "Digital clock", icon: Power, watts: 3, needed: true, on: true, hint: "Tiny but useful." },
    ],
  },
  {
    title: "Laundry — evening",
    description: "You actually need to do a load tonight.",
    targetMaxWatts: 510,
    appliances: [
      { key: "l-washer", name: "Washing machine (cold)", icon: WashingMachine, watts: 500, needed: true, on: true, hint: "Cold cycle saves 90% energy." },
      { key: "l-dryer", name: "Tumble dryer", icon: Wind, watts: 3000, needed: false, on: true, hint: "Hang to dry instead." },
      { key: "l-iron", name: "Iron (preheated, idle)", icon: Power, watts: 1200, needed: false, on: true, hint: "Iron in batches only." },
      { key: "l-light", name: "Laundry light", icon: Lightbulb, watts: 10, needed: true, on: true, hint: "You need to see!" },
    ],
  },
];

const EnergySaver = () => {
  const { user } = useAuth();
  const [stage, setStage] = useState(0);
  const [appliances, setAppliances] = useState<Appliance[]>(SCENARIOS[0].appliances.map((a) => ({ ...a })));
  const [score, setScore] = useState(0);
  const [reviewing, setReviewing] = useState(false);
  const [done, setDone] = useState(false);
  const [saved, setSaved] = useState(false);

  const scenario = SCENARIOS[stage];
  const currentWatts = appliances.filter((a) => a.on).reduce((s, a) => s + a.watts, 0);

  const toggle = (key: string) => {
    if (reviewing) return;
    setAppliances((prev) => prev.map((a) => (a.key === key ? { ...a, on: !a.on } : a)));
  };

  const submit = () => {
    let stageScore = 0;
    appliances.forEach((a) => {
      if (a.needed && a.on) stageScore += 15; // kept essentials on
      if (!a.needed && !a.on) stageScore += 20; // turned off waste
      if (a.needed && !a.on) stageScore -= 25; // turned off essential
      if (!a.needed && a.on) stageScore -= 5; // missed waste
    });
    if (currentWatts <= scenario.targetMaxWatts) stageScore += 25; // bonus
    setScore((s) => s + Math.max(0, stageScore));
    setReviewing(true);
  };

  const next = () => {
    if (stage + 1 >= SCENARIOS.length) {
      setDone(true);
      return;
    }
    const nxt = stage + 1;
    setStage(nxt);
    setAppliances(SCENARIOS[nxt].appliances.map((a) => ({ ...a })));
    setReviewing(false);
  };

  useEffect(() => {
    if (!done || saved || !user) return;
    saveGameProgress(user.id, "energy", score).then(() => setSaved(true));
  }, [done, saved, user, score]);

  const restart = () => {
    setStage(0);
    setAppliances(SCENARIOS[0].appliances.map((a) => ({ ...a })));
    setScore(0); setReviewing(false); setDone(false); setSaved(false);
  };

  if (done) {
    return (
      <CompleteScreen
        score={score}
        message="Home audit complete!"
        detail={
          <div className="bg-secondary rounded-2xl p-4 text-sm">
            <p className="font-bold mb-1">⚡ Did you know?</p>
            <p className="text-muted-foreground">Phantom loads (devices on standby) account for ~10% of household electricity bills.</p>
          </div>
        }
        onRestart={restart}
      />
    );
  }

  const meterPct = Math.min(100, (currentWatts / Math.max(scenario.targetMaxWatts * 4, 1)) * 100);
  const overTarget = currentWatts > scenario.targetMaxWatts;

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-8 max-w-3xl">
        <GameHeader
          title="Energy Saver"
          subtitle="Switch off what's wasting power. Keep essentials on."
          pills={[
            { label: "Score", value: score },
            { label: "Room", value: `${stage + 1}/${SCENARIOS.length}` },
          ]}
          progress={(stage / SCENARIOS.length) * 100}
        />

        {/* Scenario card */}
        <div className="bg-card rounded-3xl p-6 shadow-card border-2 border-border mb-5">
          <h2 className="text-xl mb-1">{scenario.title}</h2>
          <p className="text-sm text-muted-foreground mb-4">{scenario.description}</p>

          {/* Meter */}
          <div className="mb-2 flex justify-between items-center text-sm">
            <span className="font-bold flex items-center gap-1"><Zap className="w-4 h-4" /> {currentWatts} W</span>
            <span className={`font-bold ${overTarget ? "text-destructive" : "text-primary"}`}>
              Target ≤ {scenario.targetMaxWatts} W
            </span>
          </div>
          <div className="h-3 bg-secondary rounded-full overflow-hidden">
            <div
              className={`h-full transition-all ${overTarget ? "bg-destructive" : "bg-hero"}`}
              style={{ width: `${meterPct}%` }}
            />
          </div>
        </div>

        {/* Appliances */}
        <div className="grid sm:grid-cols-2 gap-3 mb-5">
          {appliances.map((a) => {
            const showCorrect = reviewing && (a.needed === a.on);
            const showWrong = reviewing && (a.needed !== a.on);
            return (
              <button
                key={a.key}
                onClick={() => toggle(a.key)}
                disabled={reviewing}
                className={`text-left rounded-3xl p-4 border-2 transition-all flex items-center gap-3 ${
                  a.on
                    ? "bg-card border-primary shadow-card"
                    : "bg-muted border-border opacity-70"
                } ${showCorrect ? "ring-4 ring-primary/40" : ""} ${showWrong ? "ring-4 ring-destructive/40" : ""}`}
              >
                <div className={`w-12 h-12 rounded-2xl grid place-items-center shrink-0 ${a.on ? "bg-gold text-gold-foreground" : "bg-secondary text-muted-foreground"}`}>
                  <a.icon className="w-6 h-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-extrabold truncate">{a.name}</p>
                  <p className="text-xs text-muted-foreground">{a.watts} W • {a.on ? "ON" : "OFF"}</p>
                  {reviewing && <p className="text-xs mt-1">{a.hint}</p>}
                </div>
              </button>
            );
          })}
        </div>

        <div className="flex justify-end gap-3">
          {!reviewing ? (
            <EcoButton onClick={submit}>Submit room</EcoButton>
          ) : (
            <EcoButton onClick={next}>{stage + 1 >= SCENARIOS.length ? "Finish" : "Next room"} →</EcoButton>
          )}
        </div>
      </main>
    </div>
  );
};

export default EnergySaver;
