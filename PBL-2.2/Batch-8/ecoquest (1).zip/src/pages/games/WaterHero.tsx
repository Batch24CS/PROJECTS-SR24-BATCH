import { useEffect, useRef, useState } from "react";
import { Droplet, Pause, Play } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";
import { GameHeader, CompleteScreen } from "@/components/GameShell";
import { useAuth } from "@/hooks/useAuth";
import { saveGameProgress } from "@/lib/saveProgress";

/**
 * Water Hero — turn off leaking taps before the bucket fills.
 * Each tap drips water into a shared bucket; click a tap to close it (+points).
 * Survive 60s without overflow. Faster reactions = bigger score.
 */

interface Tap {
  id: number;
  x: number; // %
  y: number; // %
  open: boolean;
  rate: number; // litres per second contributed while open
}

const GAME_LENGTH = 60; // seconds
const BUCKET_CAPACITY = 100;
const SPAWN_INTERVAL = 1800; // ms between new leaks
const MAX_TAPS = 6;

const rand = (min: number, max: number) => Math.random() * (max - min) + min;

const WaterHero = () => {
  const { user } = useAuth();
  const [taps, setTaps] = useState<Tap[]>([]);
  const [bucket, setBucket] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(GAME_LENGTH);
  const [paused, setPaused] = useState(false);
  const [done, setDone] = useState(false);
  const [saved, setSaved] = useState(false);
  const lastTickRef = useRef<number>(performance.now());
  const spawnAccRef = useRef<number>(0);
  const idRef = useRef<number>(1);

  // Game loop
  useEffect(() => {
    if (done || paused) {
      lastTickRef.current = performance.now();
      return;
    }
    let raf = 0;
    const tick = (now: number) => {
      const dt = (now - lastTickRef.current) / 1000;
      lastTickRef.current = now;

      // Drip from open taps
      setTaps((prev) => prev);
      let added = 0;
      taps.forEach((t) => { if (t.open) added += t.rate * dt; });
      if (added > 0) setBucket((b) => Math.min(BUCKET_CAPACITY + 1, b + added));

      // Spawn new taps
      spawnAccRef.current += dt * 1000;
      if (spawnAccRef.current > SPAWN_INTERVAL) {
        spawnAccRef.current = 0;
        setTaps((prev) => {
          if (prev.length >= MAX_TAPS) return prev;
          return [
            ...prev,
            {
              id: idRef.current++,
              x: rand(8, 88),
              y: rand(10, 78),
              open: true,
              rate: rand(2, 4.5),
            },
          ];
        });
      }

      // Timer
      setTimeLeft((t) => Math.max(0, t - dt));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [done, paused, taps]);

  // End conditions
  useEffect(() => {
    if (bucket >= BUCKET_CAPACITY || timeLeft <= 0) setDone(true);
  }, [bucket, timeLeft]);

  // Save score
  useEffect(() => {
    if (!done || saved || !user) return;
    const overflowPenalty = bucket >= BUCKET_CAPACITY ? 50 : 0;
    const finalScore = Math.max(0, score - overflowPenalty);
    saveGameProgress(user.id, "water", finalScore, 1, GAME_LENGTH - Math.floor(timeLeft))
      .then(() => setSaved(true));
  }, [done, saved, user, score, bucket, timeLeft]);

  const closeTap = (id: number) => {
    setTaps((prev) => {
      const t = prev.find((x) => x.id === id);
      if (!t || !t.open) return prev;
      setScore((s) => s + Math.round(10 + t.rate * 4));
      return prev.map((x) => (x.id === id ? { ...x, open: false } : x));
    });
    // Remove after a short delay for satisfying feedback
    setTimeout(() => {
      setTaps((prev) => prev.filter((x) => x.id !== id));
    }, 250);
  };

  const restart = () => {
    setTaps([]); setBucket(0); setScore(0); setTimeLeft(GAME_LENGTH);
    setPaused(false); setDone(false); setSaved(false);
    spawnAccRef.current = 0;
  };

  if (done) {
    const overflow = bucket >= BUCKET_CAPACITY;
    return (
      <CompleteScreen
        score={Math.max(0, score - (overflow ? 50 : 0))}
        message={overflow ? "Bucket overflowed!" : "Water saved!"}
        detail={
          <div className="bg-secondary rounded-2xl p-4 text-sm">
            <p className="font-bold mb-1">💧 Did you know?</p>
            <p className="text-muted-foreground">A single dripping tap can waste over 5,500 litres of water per year. Fix leaks promptly!</p>
          </div>
        }
        onRestart={restart}
      />
    );
  }

  const bucketPct = Math.min(100, (bucket / BUCKET_CAPACITY) * 100);

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-8 max-w-3xl">
        <GameHeader
          title="Water Hero"
          subtitle="Tap leaking faucets to close them before the bucket overflows."
          pills={[
            { label: "Score", value: score },
            { label: "Time", value: `${Math.ceil(timeLeft)}s` },
          ]}
          progress={((GAME_LENGTH - timeLeft) / GAME_LENGTH) * 100}
        />

        <div className="grid grid-cols-[1fr_auto] gap-4">
          {/* Play field */}
          <div className="relative bg-gradient-to-b from-sky-100 to-blue-50 dark:from-sky-900/40 dark:to-blue-950/40 rounded-3xl border-2 border-border overflow-hidden h-[420px] shadow-card">
            {taps.map((t) => (
              <button
                key={t.id}
                onClick={() => closeTap(t.id)}
                className={`absolute -translate-x-1/2 -translate-y-1/2 transition-transform ${t.open ? "animate-bounce-in" : "scale-50 opacity-0"}`}
                style={{ left: `${t.x}%`, top: `${t.y}%` }}
                aria-label="Close tap"
              >
                <div className="w-14 h-14 rounded-full bg-accent text-accent-foreground shadow-pop-accent grid place-items-center hover:brightness-110 active:translate-y-1 active:shadow-none">
                  <Droplet className="w-7 h-7" />
                </div>
                {t.open && (
                  <div className="absolute left-1/2 top-full -translate-x-1/2 w-1.5 h-10 bg-accent/70 rounded-full animate-pulse" />
                )}
              </button>
            ))}
            {taps.length === 0 && (
              <p className="absolute inset-0 grid place-items-center text-muted-foreground font-bold">Leaks will appear soon…</p>
            )}
            <button
              onClick={() => setPaused((p) => !p)}
              className="absolute top-3 right-3 w-10 h-10 rounded-full bg-card border-2 border-border grid place-items-center"
              aria-label={paused ? "Resume" : "Pause"}
            >
              {paused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
            </button>
          </div>

          {/* Bucket */}
          <div className="w-20 flex flex-col items-center">
            <p className="text-xs font-bold text-muted-foreground mb-1">BUCKET</p>
            <div className="relative w-16 h-[420px] bg-card border-2 border-border rounded-b-3xl rounded-t-xl overflow-hidden shadow-card">
              <div
                className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-500 to-cyan-300 transition-all duration-200"
                style={{ height: `${bucketPct}%` }}
              />
              <div className="absolute inset-0 grid place-items-center font-extrabold text-sm mix-blend-difference text-white">
                {Math.round(bucketPct)}%
              </div>
            </div>
          </div>
        </div>

        {paused && (
          <div className="mt-6 text-center">
            <EcoButton onClick={() => setPaused(false)}>Resume</EcoButton>
          </div>
        )}
      </main>
    </div>
  );
};

export default WaterHero;
