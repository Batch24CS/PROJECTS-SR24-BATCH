import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { BookOpen, ChevronRight } from "lucide-react";

interface Topic {
  id: string;
  title: string;
  description: string;
  emoji: string;
  category: string;
}

const Learn = () => {
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("learning_topics")
        .select("id,title,description,emoji,category")
        .order("order_index");
      setTopics((data ?? []) as Topic[]);
      setLoading(false);
    })();
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container py-10">
        <div className="flex items-center gap-3 mb-2">
          <BookOpen className="w-8 h-8 text-primary" />
          <h1 className="text-4xl font-extrabold">Learn</h1>
        </div>
        <p className="text-muted-foreground mb-8">Read short topics, then ace the quiz to earn points.</p>

        {loading ? (
          <p className="text-muted-foreground">Loading topics…</p>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {topics.map((t, i) => (
              <Link
                key={t.id}
                to={`/learn/${t.id}`}
                className="group animate-fade-in"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <Card className="p-5 hover:shadow-pop hover:-translate-y-1 transition-all border-2 hover:border-primary">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-secondary grid place-items-center text-3xl">
                      {t.emoji}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-extrabold text-lg">{t.title}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">{t.description}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Learn;
