import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { useUserRole } from "@/hooks/useUserRole";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Shield, Check, X, Trash2, Plus } from "lucide-react";
import { toast } from "sonner";

const AdminPanel = () => {
  const { isAdmin, loading } = useUserRole();
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [topics, setTopics] = useState<any[]>([]);
  const [challenges, setChallenges] = useState<any[]>([]);

  // forms
  const [newTopic, setNewTopic] = useState({ title: "", description: "", content: "", emoji: "🌍" });
  const [newCh, setNewCh] = useState({ title: "", description: "", points: 50, emoji: "🌱" });

  const load = async () => {
    const [{ data: subs }, { data: u }, { data: t }, { data: c }] = await Promise.all([
      supabase.from("challenge_submissions").select("*, challenges(title, emoji)").order("created_at", { ascending: false }),
      supabase.from("profiles").select("id, name, total_points").order("total_points", { ascending: false }),
      supabase.from("learning_topics").select("*").order("order_index"),
      supabase.from("challenges").select("*").order("created_at"),
    ]);
    setSubmissions(subs ?? []);
    setUsers(u ?? []);
    setTopics(t ?? []);
    setChallenges(c ?? []);
  };

  useEffect(() => {
    if (isAdmin) load();
  }, [isAdmin]);

  if (loading) return null;
  if (!isAdmin) return <Navigate to="/" replace />;

  const review = async (id: string, status: "approved" | "rejected") => {
    const { error } = await supabase
      .from("challenge_submissions")
      .update({ status, reviewed_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${status}`);
    load();
  };

  const addTopic = async () => {
    if (!newTopic.title || !newTopic.content) return toast.error("Title and content required");
    const { error } = await supabase.from("learning_topics").insert(newTopic);
    if (error) return toast.error(error.message);
    setNewTopic({ title: "", description: "", content: "", emoji: "🌍" });
    toast.success("Topic added");
    load();
  };

  const delTopic = async (id: string) => {
    await supabase.from("learning_topics").delete().eq("id", id);
    load();
  };

  const addChallenge = async () => {
    if (!newCh.title || !newCh.description) return toast.error("Fill all fields");
    const { error } = await supabase.from("challenges").insert(newCh);
    if (error) return toast.error(error.message);
    setNewCh({ title: "", description: "", points: 50, emoji: "🌱" });
    toast.success("Challenge added");
    load();
  };

  const toggleChallenge = async (id: string, active: boolean) => {
    await supabase.from("challenges").update({ active: !active }).eq("id", id);
    load();
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="container py-10">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-8 h-8 text-primary" />
          <h1 className="text-4xl font-extrabold">Admin Panel</h1>
        </div>

        <Tabs defaultValue="submissions">
          <TabsList className="mb-4">
            <TabsTrigger value="submissions">
              Submissions {submissions.filter((s) => s.status === "pending").length > 0 && (
                <Badge className="ml-2 bg-destructive">{submissions.filter((s) => s.status === "pending").length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="topics">Topics</TabsTrigger>
            <TabsTrigger value="challenges">Challenges</TabsTrigger>
          </TabsList>

          <TabsContent value="submissions" className="space-y-3">
            {submissions.map((s) => (
              <Card key={s.id} className="p-4 flex gap-4 items-center">
                <img src={s.image_url} alt="" className="w-20 h-20 rounded-xl object-cover" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold">
                    {s.challenges?.emoji} {s.challenges?.title}
                  </p>
                  {s.note && <p className="text-sm text-muted-foreground truncate">{s.note}</p>}
                  <Badge variant="outline" className="mt-1">{s.status}</Badge>
                </div>
                {s.status === "pending" && (
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => review(s.id, "approved")}>
                      <Check className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => review(s.id, "rejected")}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </Card>
            ))}
            {submissions.length === 0 && <p className="text-muted-foreground">No submissions yet.</p>}
          </TabsContent>

          <TabsContent value="users">
            <Card className="p-0 overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-secondary">
                  <tr>
                    <th className="text-left p-3">Name</th>
                    <th className="text-right p-3">Points</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id} className="border-t">
                      <td className="p-3 font-medium">{u.name}</td>
                      <td className="p-3 text-right font-bold text-primary">{u.total_points}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </TabsContent>

          <TabsContent value="topics" className="space-y-3">
            <Card className="p-4 space-y-2">
              <h3 className="font-bold flex items-center gap-2"><Plus className="w-4 h-4" /> New topic</h3>
              <div className="grid grid-cols-4 gap-2">
                <Input placeholder="Emoji" value={newTopic.emoji} onChange={(e) => setNewTopic({ ...newTopic, emoji: e.target.value })} />
                <Input className="col-span-3" placeholder="Title" value={newTopic.title} onChange={(e) => setNewTopic({ ...newTopic, title: e.target.value })} />
              </div>
              <Input placeholder="Short description" value={newTopic.description} onChange={(e) => setNewTopic({ ...newTopic, description: e.target.value })} />
              <Textarea placeholder="Content" value={newTopic.content} onChange={(e) => setNewTopic({ ...newTopic, content: e.target.value })} />
              <Button onClick={addTopic}>Add topic</Button>
            </Card>
            {topics.map((t) => (
              <Card key={t.id} className="p-3 flex items-center gap-3">
                <span className="text-2xl">{t.emoji}</span>
                <div className="flex-1">
                  <p className="font-bold">{t.title}</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">{t.description}</p>
                </div>
                <Button size="icon" variant="ghost" onClick={() => delTopic(t.id)}>
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="challenges" className="space-y-3">
            <Card className="p-4 space-y-2">
              <h3 className="font-bold flex items-center gap-2"><Plus className="w-4 h-4" /> New challenge</h3>
              <div className="grid grid-cols-6 gap-2">
                <Input placeholder="Emoji" value={newCh.emoji} onChange={(e) => setNewCh({ ...newCh, emoji: e.target.value })} />
                <Input className="col-span-4" placeholder="Title" value={newCh.title} onChange={(e) => setNewCh({ ...newCh, title: e.target.value })} />
                <Input type="number" placeholder="Pts" value={newCh.points} onChange={(e) => setNewCh({ ...newCh, points: Number(e.target.value) })} />
              </div>
              <Textarea placeholder="Description" value={newCh.description} onChange={(e) => setNewCh({ ...newCh, description: e.target.value })} />
              <Button onClick={addChallenge}>Add challenge</Button>
            </Card>
            {challenges.map((c) => (
              <Card key={c.id} className="p-3 flex items-center gap-3">
                <span className="text-2xl">{c.emoji}</span>
                <div className="flex-1">
                  <p className="font-bold">{c.title} <Badge variant="outline" className="ml-1">+{c.points}</Badge></p>
                  <p className="text-xs text-muted-foreground line-clamp-1">{c.description}</p>
                </div>
                <Button size="sm" variant={c.active ? "default" : "outline"} onClick={() => toggleChallenge(c.id, c.active)}>
                  {c.active ? "Active" : "Inactive"}
                </Button>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AdminPanel;
