import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Users, Trophy, Gamepad2, Search, GraduationCap } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { supabase } from "@/integrations/supabase/client";

interface StudentRow {
  id: string;
  name: string;
  total_points: number;
  games_played: number;
  last_played: string | null;
  per_game: Record<string, number>;
}

const GAME_LABELS: Record<string, string> = {
  "waste-segregation": "Waste",
  "carbon-footprint": "Carbon",
  "water": "Water",
  "trees": "Trees",
  "energy": "Energy",
};

const TeacherDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const { isTeacher, loading: roleLoading } = useUserRole();
  const navigate = useNavigate();
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!authLoading && !user) navigate("/auth");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user || !isTeacher) return;
    (async () => {
      setLoading(true);

      // Fetch student-role user ids
      const { data: roleRows } = await supabase
        .from("user_roles")
        .select("user_id, role");
      const studentIds = (roleRows ?? [])
        .filter((r: any) => r.role === "student")
        .map((r: any) => r.user_id as string);

      if (studentIds.length === 0) {
        setStudents([]);
        setLoading(false);
        return;
      }

      const [{ data: profiles }, { data: progress }] = await Promise.all([
        supabase.from("profiles").select("id, name, total_points").in("id", studentIds),
        supabase.from("game_progress").select("user_id, game_slug, score, created_at").in("user_id", studentIds),
      ]);

      const rows: StudentRow[] = (profiles ?? []).map((p: any) => {
        const mine = (progress ?? []).filter((g: any) => g.user_id === p.id);
        const perGame: Record<string, number> = {};
        let last: string | null = null;
        mine.forEach((g: any) => {
          perGame[g.game_slug] = Math.max(perGame[g.game_slug] ?? 0, g.score);
          if (!last || g.created_at > last) last = g.created_at;
        });
        return {
          id: p.id,
          name: p.name,
          total_points: p.total_points ?? 0,
          games_played: mine.length,
          last_played: last,
          per_game: perGame,
        };
      });

      rows.sort((a, b) => b.total_points - a.total_points);
      setStudents(rows);
      setLoading(false);
    })();
  }, [user, isTeacher]);

  const filtered = useMemo(
    () => students.filter((s) => s.name.toLowerCase().includes(search.toLowerCase())),
    [students, search],
  );

  const totals = useMemo(
    () => ({
      students: students.length,
      points: students.reduce((s, x) => s + x.total_points, 0),
      games: students.reduce((s, x) => s + x.games_played, 0),
    }),
    [students],
  );

  if (authLoading || roleLoading) {
    return (
      <div className="min-h-screen bg-sky-fade">
        <Navbar />
        <main className="container py-16 text-center text-muted-foreground">Loading…</main>
      </div>
    );
  }

  if (!isTeacher) {
    return (
      <div className="min-h-screen bg-sky-fade">
        <Navbar />
        <main className="container py-16 max-w-md text-center">
          <div className="bg-card rounded-3xl p-8 shadow-card border-2 border-border">
            <GraduationCap className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <h1 className="text-2xl mb-2">Teachers only</h1>
            <p className="text-muted-foreground mb-6">
              This dashboard is for accounts created with the <strong>Teacher</strong> role.
            </p>
            <EcoButton onClick={() => navigate("/dashboard")}>Go to my dashboard</EcoButton>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-10 space-y-8">
        <div>
          <p className="text-muted-foreground font-bold">Teacher view</p>
          <h1 className="text-4xl">Class progress 🎓</h1>
        </div>

        {/* Summary */}
        <div className="grid sm:grid-cols-3 gap-4">
          <SummaryCard icon={Users} label="Students" value={totals.students} variant="primary" />
          <SummaryCard icon={Trophy} label="Total points" value={totals.points} variant="gold" />
          <SummaryCard icon={Gamepad2} label="Games played" value={totals.games} variant="accent" />
        </div>

        {/* Search */}
        <div className="bg-card rounded-3xl border-2 border-border shadow-card p-4 flex items-center gap-3">
          <Search className="w-5 h-5 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search students…"
            className="flex-1 bg-transparent outline-none font-bold"
          />
        </div>

        {/* Table */}
        <div className="bg-card rounded-3xl border-2 border-border overflow-hidden">
          {loading ? (
            <p className="p-8 text-center text-muted-foreground">Loading students…</p>
          ) : filtered.length === 0 ? (
            <p className="p-8 text-center text-muted-foreground">
              {students.length === 0 ? "No students yet. Share the signup link!" : "No matches."}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary">
                  <tr className="text-left">
                    <th className="p-3 font-extrabold">#</th>
                    <th className="p-3 font-extrabold">Student</th>
                    <th className="p-3 font-extrabold text-right">Points</th>
                    <th className="p-3 font-extrabold text-right">Plays</th>
                    {Object.entries(GAME_LABELS).map(([slug, label]) => (
                      <th key={slug} className="p-3 font-extrabold text-right hidden md:table-cell">{label}</th>
                    ))}
                    <th className="p-3 font-extrabold text-right hidden sm:table-cell">Last active</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((s, i) => (
                    <tr key={s.id} className="border-t-2 border-border">
                      <td className="p-3 font-bold text-muted-foreground">{i + 1}</td>
                      <td className="p-3 font-bold">{s.name}</td>
                      <td className="p-3 text-right font-extrabold text-primary">{s.total_points}</td>
                      <td className="p-3 text-right">{s.games_played}</td>
                      {Object.keys(GAME_LABELS).map((slug) => (
                        <td key={slug} className="p-3 text-right hidden md:table-cell text-muted-foreground">
                          {s.per_game[slug] ?? "—"}
                        </td>
                      ))}
                      <td className="p-3 text-right hidden sm:table-cell text-muted-foreground">
                        {s.last_played ? new Date(s.last_played).toLocaleDateString() : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

const SummaryCard = ({ icon: I, label, value, variant }: { icon: any; label: string; value: number; variant: "gold" | "primary" | "accent" }) => {
  const styles = {
    gold: "bg-gold text-gold-foreground shadow-pop-gold",
    primary: "bg-primary text-primary-foreground shadow-pop",
    accent: "bg-accent text-accent-foreground shadow-pop-accent",
  }[variant];
  return (
    <div className={`${styles} rounded-3xl p-6`}>
      <I className="w-7 h-7 mb-2" />
      <p className="text-sm font-bold uppercase opacity-90">{label}</p>
      <p className="text-3xl font-extrabold">{value}</p>
    </div>
  );
};

export default TeacherDashboard;
