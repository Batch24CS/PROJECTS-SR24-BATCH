import { useEffect, useState } from "react";
import { Trophy, Medal } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

type Range = "daily" | "weekly" | "global";
interface Row { id: string; name: string; total_points: number; }

const Leaderboard = () => {
  const [range, setRange] = useState<Range>("global");
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      if (range === "global") {
        const { data } = await supabase
          .from("profiles")
          .select("id, name, total_points")
          .order("total_points", { ascending: false })
          .limit(50);
        setRows(data ?? []);
      } else {
        const since = new Date();
        if (range === "daily") since.setDate(since.getDate() - 1);
        else since.setDate(since.getDate() - 7);
        const { data: progress } = await supabase
          .from("game_progress")
          .select("user_id, score")
          .gte("created_at", since.toISOString());
        const totals = new Map<string, number>();
        (progress ?? []).forEach((p: any) => {
          totals.set(p.user_id, (totals.get(p.user_id) ?? 0) + (p.score ?? 0));
        });
        const ids = Array.from(totals.keys());
        if (ids.length === 0) {
          setRows([]);
        } else {
          const { data: profs } = await supabase
            .from("profiles")
            .select("id, name")
            .in("id", ids);
          const merged: Row[] = (profs ?? [])
            .map((p: any) => ({ id: p.id, name: p.name, total_points: totals.get(p.id) ?? 0 }))
            .sort((a, b) => b.total_points - a.total_points)
            .slice(0, 50);
          setRows(merged);
        }
      }
      setLoading(false);
    })();
  }, [range]);

  const medalColor = (i: number) =>
    i === 0 ? "bg-gold text-gold-foreground shadow-pop-gold"
    : i === 1 ? "bg-muted-foreground text-background"
    : i === 2 ? "bg-accent text-accent-foreground shadow-pop-accent"
    : "bg-secondary text-foreground";

  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />
      <main className="container py-10 max-w-2xl">
        <div className="flex items-center gap-3 mb-2">
          <span className="w-12 h-12 rounded-2xl bg-gold text-gold-foreground grid place-items-center shadow-pop-gold">
            <Trophy className="w-6 h-6" />
          </span>
          <h1 className="text-4xl">Leaderboard</h1>
        </div>
        <p className="text-muted-foreground mb-6">Top eco-heroes saving the planet, one quest at a time.</p>

        <Tabs value={range} onValueChange={(v) => setRange(v as Range)} className="mb-4">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="daily">Today</TabsTrigger>
            <TabsTrigger value="weekly">This week</TabsTrigger>
            <TabsTrigger value="global">All time</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="bg-card rounded-3xl border-2 border-border overflow-hidden animate-fade-in" key={range}>
          {loading ? (
            <p className="p-8 text-center text-muted-foreground">Loading…</p>
          ) : rows.length === 0 ? (
            <p className="p-8 text-center text-muted-foreground">No scores yet. Be the first!</p>
          ) : (
            <ul className="divide-y-2 divide-border">
              {rows.map((r, i) => (
                <li key={r.id} className="flex items-center gap-4 p-4">
                  <div className={`w-10 h-10 rounded-2xl grid place-items-center font-extrabold ${medalColor(i)}`}>
                    {i < 3 ? <Medal className="w-5 h-5" /> : i + 1}
                  </div>
                  <p className="flex-1 font-bold">{r.name}</p>
                  <p className="font-extrabold text-primary">{r.total_points} pts</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </main>
    </div>
  );
};

export default Leaderboard;
