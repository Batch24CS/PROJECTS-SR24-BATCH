import { Link } from "react-router-dom";
import { Leaf, Recycle, Trophy, Sparkles, Target, Users } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { EcoButton } from "@/components/EcoButton";

const Index = () => {
  return (
    <div className="min-h-screen bg-sky-fade">
      <Navbar />

      {/* HERO */}
      <section className="container pt-16 pb-24 md:pt-24 md:pb-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-secondary text-secondary-foreground font-bold text-sm">
              <Sparkles className="w-4 h-4" /> Learn the planet through play
            </span>
            <h1 className="text-5xl md:text-7xl leading-[1.05]">
              Save the Earth.<br />
              <span className="text-primary">One quest</span> at a time.
            </h1>
            <p className="text-lg text-muted-foreground max-w-md">
              EcoQuest turns environmental education into addictive mini-games. Learn recycling, climate, water and more — and level up your real-world impact.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <Link to="/auth?mode=signup">
                <EcoButton size="lg">Start your quest</EcoButton>
              </Link>
              <Link to="/games">
                <EcoButton variant="outline" size="lg">Try a game</EcoButton>
              </Link>
            </div>
            <div className="flex items-center gap-6 pt-4 text-sm font-bold text-muted-foreground">
              <span className="flex items-center gap-2"><Users className="w-4 h-4" /> Built for schools</span>
              <span className="flex items-center gap-2"><Trophy className="w-4 h-4" /> Live leaderboard</span>
            </div>
          </div>

          {/* Hero illustration card */}
          <div className="relative">
            <div className="absolute -inset-6 bg-hero opacity-10 rounded-[3rem] blur-2xl" />
            <div className="relative bg-card rounded-[2rem] p-8 shadow-card border-2 border-border">
              <div className="aspect-square bg-hero rounded-2xl grid place-items-center text-primary-foreground">
                <Leaf className="w-32 h-32 animate-wiggle" strokeWidth={1.5} />
              </div>
              <div className="mt-6 grid grid-cols-3 gap-3">
                {[
                  { icon: Recycle, label: "Recycle", color: "bg-primary text-primary-foreground" },
                  { icon: Target, label: "Quests", color: "bg-accent text-accent-foreground" },
                  { icon: Trophy, label: "Win", color: "bg-gold text-gold-foreground" },
                ].map(({ icon: I, label, color }) => (
                  <div key={label} className={`${color} rounded-2xl p-4 text-center font-extrabold`}>
                    <I className="w-6 h-6 mx-auto mb-1" />
                    <div className="text-xs uppercase">{label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="container pb-24">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Recycle, title: "Play to learn", desc: "Drag-and-drop, scenarios, simulators — every game teaches a real concept." },
            { icon: Trophy, title: "Earn & compete", desc: "Score points, unlock badges, climb the global leaderboard." },
            { icon: Target, title: "Real impact", desc: "Take your learning offline with daily eco-challenges." },
          ].map(({ icon: I, title, desc }) => (
            <div key={title} className="bg-card rounded-3xl p-6 shadow-card border-2 border-border">
              <div className="w-12 h-12 rounded-2xl bg-secondary text-primary grid place-items-center mb-4">
                <I className="w-6 h-6" />
              </div>
              <h3 className="text-xl mb-2">{title}</h3>
              <p className="text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} EcoQuest — Learn. Play. Protect.
      </footer>
    </div>
  );
};

export default Index;
