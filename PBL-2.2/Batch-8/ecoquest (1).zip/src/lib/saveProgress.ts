import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const saveGameProgress = async (
  userId: string,
  gameSlug: string,
  score: number,
  level = 1,
  durationSeconds?: number,
) => {
  const { error } = await supabase.from("game_progress").insert({
    user_id: userId,
    game_slug: gameSlug,
    score,
    level,
    duration_seconds: durationSeconds ?? null,
  });
  if (error) {
    toast.error("Couldn't save your score");
    return false;
  }
  toast.success(`Saved! +${score} points 🎉`);
  return true;
};
