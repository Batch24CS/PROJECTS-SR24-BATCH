import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";

export type AppRole = "admin" | "teacher" | "student";

export const useUserRole = () => {
  const { user, loading: authLoading } = useAuth();
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setRole(null);
      setLoading(false);
      return;
    }
    (async () => {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);
      const roles = (data ?? []).map((r: any) => r.role as AppRole);
      const resolved: AppRole = roles.includes("admin")
        ? "admin"
        : roles.includes("teacher")
        ? "teacher"
        : "student";
      setRole(resolved);
      setLoading(false);
    })();
  }, [user, authLoading]);

  return {
    role,
    loading,
    isTeacher: role === "teacher" || role === "admin",
    isAdmin: role === "admin",
  };
};
