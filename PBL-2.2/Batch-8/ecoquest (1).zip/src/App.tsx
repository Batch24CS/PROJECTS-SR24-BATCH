import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index.tsx";
import Auth from "./pages/Auth.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import Games from "./pages/Games.tsx";
import WasteSegregation from "./pages/games/WasteSegregation.tsx";
import WaterHero from "./pages/games/WaterHero.tsx";
import TreePlanter from "./pages/games/TreePlanter.tsx";
import EnergySaver from "./pages/games/EnergySaver.tsx";
import CarbonFootprint from "./pages/games/CarbonFootprint.tsx";
import Leaderboard from "./pages/Leaderboard.tsx";
import TeacherDashboard from "./pages/TeacherDashboard.tsx";
import Learn from "./pages/Learn.tsx";
import LearnTopic from "./pages/LearnTopic.tsx";
import Challenges from "./pages/Challenges.tsx";
import AdminPanel from "./pages/AdminPanel.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/games" element={<Games />} />
            <Route path="/games/waste-segregation" element={<WasteSegregation />} />
            <Route path="/games/water" element={<WaterHero />} />
            <Route path="/games/trees" element={<TreePlanter />} />
            <Route path="/games/energy" element={<EnergySaver />} />
            <Route path="/games/carbon-footprint" element={<CarbonFootprint />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/teacher" element={<TeacherDashboard />} />
            <Route path="/learn" element={<Learn />} />
            <Route path="/learn/:id" element={<LearnTopic />} />
            <Route path="/challenges" element={<Challenges />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
