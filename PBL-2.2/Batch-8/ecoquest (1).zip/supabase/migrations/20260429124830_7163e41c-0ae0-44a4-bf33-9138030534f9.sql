
-- 1. LEARNING MODULE: topics + quizzes + quiz attempts
CREATE TABLE public.learning_topics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'general',
  emoji TEXT NOT NULL DEFAULT '🌍',
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.quiz_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  topic_id UUID NOT NULL REFERENCES public.learning_topics(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  options JSONB NOT NULL,
  correct_index INTEGER NOT NULL,
  explanation TEXT,
  points INTEGER NOT NULL DEFAULT 10,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.quiz_attempts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  topic_id UUID NOT NULL REFERENCES public.learning_topics(id) ON DELETE CASCADE,
  score INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. CHALLENGES: tasks + submissions
CREATE TABLE public.challenges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 50,
  emoji TEXT NOT NULL DEFAULT '🌱',
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.challenge_submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  challenge_id UUID NOT NULL REFERENCES public.challenges(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending / approved / rejected
  awarded_points INTEGER NOT NULL DEFAULT 0,
  reviewer_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reviewed_at TIMESTAMPTZ
);

-- 3. NOTIFICATIONS
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  link TEXT,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.learning_topics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenge_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Learning topics: everyone reads, only admins write
CREATE POLICY "Topics readable by all" ON public.learning_topics FOR SELECT USING (true);
CREATE POLICY "Admins manage topics ins" ON public.learning_topics FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage topics upd" ON public.learning_topics FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage topics del" ON public.learning_topics FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Questions readable by all" ON public.quiz_questions FOR SELECT USING (true);
CREATE POLICY "Admins manage questions ins" ON public.quiz_questions FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage questions upd" ON public.quiz_questions FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage questions del" ON public.quiz_questions FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Quiz attempts: users insert/view their own; admins+teachers view all
CREATE POLICY "Users insert own attempts" ON public.quiz_attempts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users view own attempts" ON public.quiz_attempts FOR SELECT USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'teacher') OR public.has_role(auth.uid(), 'admin'));

-- Challenges: everyone reads, admins manage
CREATE POLICY "Challenges readable by all" ON public.challenges FOR SELECT USING (true);
CREATE POLICY "Admins manage challenges ins" ON public.challenges FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage challenges upd" ON public.challenges FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage challenges del" ON public.challenges FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Challenge submissions
CREATE POLICY "Users insert own submission" ON public.challenge_submissions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users view own submission, staff view all" ON public.challenge_submissions FOR SELECT USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'teacher') OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins review submissions" ON public.challenge_submissions FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

-- Notifications: users see own; system/admins insert
CREATE POLICY "Users view own notifications" ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users update own notifications" ON public.notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Admins create notifications" ON public.notifications FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin') OR auth.uid() = user_id);

-- 4. Award points trigger when challenge approved -> insert into game_progress
CREATE OR REPLACE FUNCTION public.award_challenge_points()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'approved' AND (OLD.status IS DISTINCT FROM 'approved') THEN
    INSERT INTO public.game_progress (user_id, game_slug, score)
    VALUES (NEW.user_id, 'challenge:' || NEW.challenge_id::text, NEW.awarded_points);
    INSERT INTO public.notifications (user_id, title, body, link)
    VALUES (NEW.user_id, 'Challenge approved! 🎉', 'You earned ' || NEW.awarded_points || ' points.', '/challenges');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_award_challenge_points
AFTER UPDATE ON public.challenge_submissions
FOR EACH ROW EXECUTE FUNCTION public.award_challenge_points();

-- Award points trigger for quiz attempts -> game_progress
CREATE OR REPLACE FUNCTION public.award_quiz_points()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.game_progress (user_id, game_slug, score)
  VALUES (NEW.user_id, 'quiz:' || NEW.topic_id::text, NEW.score);
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_award_quiz_points
AFTER INSERT ON public.quiz_attempts
FOR EACH ROW EXECUTE FUNCTION public.award_quiz_points();

-- update_total_points trigger already exists on game_progress? check: function exists but needs trigger
CREATE TRIGGER trg_update_total_points
AFTER INSERT ON public.game_progress
FOR EACH ROW EXECUTE FUNCTION public.update_total_points();

-- 5. Storage bucket for challenge proofs
INSERT INTO storage.buckets (id, name, public) VALUES ('challenge-proofs', 'challenge-proofs', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Proofs publicly viewable" ON storage.objects FOR SELECT USING (bucket_id = 'challenge-proofs');
CREATE POLICY "Users upload own proofs" ON storage.objects FOR INSERT WITH CHECK (
  bucket_id = 'challenge-proofs' AND auth.uid()::text = (storage.foldername(name))[1]
);

-- 6. Seed content
INSERT INTO public.learning_topics (title, description, content, category, emoji, order_index) VALUES
('Climate Change Basics', 'Understand the greenhouse effect and global warming.', 'The greenhouse effect traps heat in Earth''s atmosphere. Human activity — burning fossil fuels, deforestation, agriculture — has raised CO₂ from ~280ppm in 1850 to over 420ppm today. Even 1.5°C of warming triggers more heatwaves, stronger storms, melting ice, and rising seas.', 'climate', '🌡️', 1),
('Why Trees Matter', 'The role of forests in our planet''s health.', 'A single mature tree absorbs ~22kg of CO₂ per year and produces enough oxygen for two people. Forests host 80% of land biodiversity, regulate rainfall, and prevent soil erosion. Yet we lose 10 million hectares of forest every year — an area the size of Iceland.', 'nature', '🌳', 2),
('Water: A Precious Resource', 'How to value and save the water we use.', 'Only 0.5% of Earth''s water is freshwater available for use. A 5-minute shower uses ~75 litres. Fixing a single leaky tap saves 20,000 litres/year. Brushing teeth with the tap running wastes 6 litres per minute.', 'water', '💧', 3),
('Renewable Energy', 'Clean energy sources powering the future.', 'Solar, wind, hydro, and geothermal energy now produce ~30% of global electricity. Solar prices fell 90% in the last decade. Switching one household to renewables prevents ~2.5 tonnes of CO₂ per year.', 'energy', '⚡', 4);

INSERT INTO public.challenges (title, description, points, emoji) VALUES
('Plant a sapling', 'Plant any tree or shrub and upload a photo with you next to it.', 100, '🌱'),
('Zero-waste lunch', 'Pack and eat a lunch with no single-use plastic. Photo of your setup.', 40, '🥗'),
('Cycle / walk to school', 'Travel to school without a motor vehicle for one day. Photo proof.', 50, '🚴'),
('Clean a public space', 'Collect at least one bag of litter from a park, beach, or street.', 80, '🧹'),
('Save energy night', 'Spend 1 hour with all non-essential devices off. Photo of the setup.', 30, '🕯️');

-- Quiz questions for first topic
INSERT INTO public.quiz_questions (topic_id, question, options, correct_index, explanation, order_index)
SELECT id, 'What gas is most responsible for human-caused warming?', '["Oxygen","Carbon dioxide","Nitrogen","Helium"]'::jsonb, 1, 'CO₂ from burning fossil fuels is the dominant driver.', 1 FROM public.learning_topics WHERE title='Climate Change Basics';

INSERT INTO public.quiz_questions (topic_id, question, options, correct_index, explanation, order_index)
SELECT id, 'Pre-industrial CO₂ levels were about:', '["280 ppm","420 ppm","100 ppm","800 ppm"]'::jsonb, 0, '~280ppm in 1850, now over 420ppm.', 2 FROM public.learning_topics WHERE title='Climate Change Basics';

INSERT INTO public.quiz_questions (topic_id, question, options, correct_index, explanation, order_index)
SELECT id, 'How much CO₂ does a mature tree absorb per year?', '["~2 kg","~22 kg","~220 kg","~2200 kg"]'::jsonb, 1, 'About 22 kg per year on average.', 1 FROM public.learning_topics WHERE title='Why Trees Matter';

INSERT INTO public.quiz_questions (topic_id, question, options, correct_index, explanation, order_index)
SELECT id, 'Forests host what % of land biodiversity?', '["20%","50%","80%","100%"]'::jsonb, 2, '80% of terrestrial species live in forests.', 2 FROM public.learning_topics WHERE title='Why Trees Matter';

INSERT INTO public.quiz_questions (topic_id, question, options, correct_index, explanation, order_index)
SELECT id, 'What % of Earth''s water is usable freshwater?', '["50%","10%","2%","0.5%"]'::jsonb, 3, 'Only ~0.5% — most freshwater is locked in ice.', 1 FROM public.learning_topics WHERE title='Water: A Precious Resource';

INSERT INTO public.quiz_questions (topic_id, question, options, correct_index, explanation, order_index)
SELECT id, 'Approximate water used by a 5-minute shower:', '["10 L","75 L","300 L","1000 L"]'::jsonb, 1, 'About 75 litres for a typical 5-min shower.', 2 FROM public.learning_topics WHERE title='Water: A Precious Resource';

INSERT INTO public.quiz_questions (topic_id, question, options, correct_index, explanation, order_index)
SELECT id, 'Solar panel prices over the last decade have:', '["Doubled","Stayed flat","Fallen ~90%","Tripled"]'::jsonb, 2, 'Solar PV cost dropped roughly 90% — making it the cheapest electricity in history.', 1 FROM public.learning_topics WHERE title='Renewable Energy';
