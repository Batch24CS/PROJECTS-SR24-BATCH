# P2P File Sharing App — PBL Project Plan

## Project Overview

Build a **browser-based file sharing application** where anyone on the same Wi-Fi network can upload and download files through a web interface. No cloud, no accounts — pure local network file transfer.

---

## Learning Objectives

| Subject | Concepts Covered |
|---------|-----------------|
| **Node.js** | HTTP server, streams, file system I/O, WebSocket server, event-driven architecture, `os` module, `child_process` |
| **HTML/CSS** | Semantic HTML5, CSS Grid & Flexbox, drag-and-drop API, Fetch API, WebSocket client, DOM manipulation |
| **Computer Networking** | HTTP protocol, TCP/IP, multipart/form-data, chunked transfer, WebSocket upgrade handshake, LAN/IP addressing, MIME types, ports |
| **Operating Systems** | File system operations, process memory, system calls via `os` module, concurrent connections, path security |

---

## Project Phases

### Phase 1 — Setup & HTTP basics (Week 1)

**Tasks:**
1. Install Node.js and `npm`
2. Create project folder structure: `server.js`, `public/index.html`, `uploads/`
3. Write a basic HTTP server that serves a static HTML page
4. Understand how `http.createServer()` maps to TCP port binding

**Key questions to answer:**
- What is a port number? Why do we use port 3000?
- What happens during an HTTP GET request? Trace it step by step.
- What is `127.0.0.1` vs `0.0.0.0`? Why does it matter for LAN access?

**Deliverable:** A "Hello World" page visible at `http://localhost:3000`

---

### Phase 2 — File System & OS module (Week 1–2)

**Tasks:**
1. Use `fs.writeFileSync` to save files to the `uploads/` directory
2. Use `fs.readdirSync` + `fs.statSync` to list uploaded files
3. Use the `os` module to read hostname, platform, CPU count, free memory

**Key questions to answer:**
- What is a file system path? What is the difference between absolute and relative paths?
- What is `os.networkInterfaces()`? How does Node.js detect the machine's LAN IP?
- What is a file descriptor at the OS level?

**Deliverable:** API endpoint `/api/info` that returns JSON system info

---

### Phase 3 — Multipart File Upload (Week 2)

**Tasks:**
1. Build the HTML drag-and-drop upload form with `<input type="file">`
2. Use `fetch()` with `FormData` to send the file via HTTP POST
3. On the server, manually parse `multipart/form-data` using Buffer operations

**Key questions to answer:**
- What is `multipart/form-data`? How does the boundary string work?
- What is a `Buffer` in Node.js? How does binary data travel over HTTP?
- What is `Content-Length`? Why do we check it to prevent oversized uploads?
- What is a path traversal attack? How does `path.basename()` protect us?

**Networking deep-dive:**
```
HTTP POST /api/upload
Content-Type: multipart/form-data; boundary=----FormBoundary7MA4YWxk

------FormBoundary7MA4YWxk
Content-Disposition: form-data; name="file"; filename="photo.jpg"
Content-Type: image/jpeg

[binary file data here]
------FormBoundary7MA4YWxk--
```

**Deliverable:** Files upload and appear in the `uploads/` folder

---

### Phase 4 — WebSocket Real-Time Updates (Week 3)

**Tasks:**
1. Install the `ws` npm package
2. Attach a WebSocket server to the same HTTP server (port sharing via upgrade)
3. When a file is uploaded, `broadcast()` the new file list to all connected browsers
4. Connect from the frontend using `new WebSocket('ws://...')`

**Key questions to answer:**
- What is the difference between HTTP (request/response) and WebSocket (full-duplex)?
- What is the HTTP Upgrade handshake that creates a WebSocket connection?
- What is a TCP full-duplex connection?
- Why is WebSocket better than polling every second?

**Networking comparison:**
| Method | Protocol | Connection | Efficiency |
|--------|----------|-----------|------------|
| HTTP Polling | HTTP/TCP | New each time | Low |
| Long Polling | HTTP/TCP | Held open | Medium |
| WebSocket | WS/TCP | Persistent | High |

**Deliverable:** File list updates in real time across all open browser tabs

---

### Phase 5 — File Download via Streams (Week 3–4)

**Tasks:**
1. Build the `GET /download/:filename` route
2. Use `fs.createReadStream()` piped to the HTTP response
3. Set correct `Content-Disposition` and `Content-Type` headers

**Key questions to answer:**
- What is a Node.js stream? Why is streaming better than `fs.readFileSync` for large files?
- What is `Content-Disposition: attachment`? What does it tell the browser?
- What is a MIME type? How does the browser decide how to handle a file?
- What is `pipe()` and how does it connect a readable stream to a writable stream?

**OS concept:** Compare reading a 1 GB file all at once (requires 1 GB in RAM) vs streaming it in 64 KB chunks (only 64 KB in RAM at any time).

**Deliverable:** Files download correctly from the browser

---

### Phase 6 — UI Polish & Advanced Features (Week 4)

**Tasks:**
1. Add upload progress bar (driven by WebSocket `upload_progress` messages)
2. Add file deletion with the `DELETE /api/files/:name` endpoint
3. Add an activity log panel in the UI
4. Style the dashboard with CSS Grid layout

**Extensions (bonus):**
- Show who is currently connected (how many WebSocket clients)
- Add QR code of the LAN URL (so phones can connect easily)
- Add file transfer speed calculation
- Add password protection on the upload route

---

## Folder Structure

```
p2p-fileshare/
├── server.js          ← Node.js HTTP + WebSocket server
├── package.json       ← Dependencies
├── public/
│   └── index.html     ← Frontend (HTML + CSS + JS)
└── uploads/           ← Uploaded files stored here
```

---

## How to Run

```bash
# 1. Install dependencies
npm install

# 2. Start the server
node server.js

# 3. Open in browser
# Local:   http://localhost:3000
# Network: http://<YOUR-LAN-IP>:3000
```

To find your LAN IP manually:
- **Windows:** `ipconfig` in CMD
- **Linux/Mac:** `ifconfig` or `ip addr`

---

## Concept Map

```
Browser (HTML/CSS/JS)
    │
    ├── HTTP POST /api/upload  ──→  Node.js parses multipart body
    │                               └─ fs.writeFile → disk (OS)
    │
    ├── WebSocket ws://...     ←──  Node.js broadcasts events
    │   (real-time updates)
    │
    └── HTTP GET /download/:f  ──→  fs.createReadStream → pipe → response
```

---

## Evaluation Rubric

| Criteria | Marks |
|----------|-------|
| HTTP server serves static files correctly | 10 |
| File upload works (multipart parsing) | 20 |
| File download works (streaming) | 15 |
| WebSocket real-time updates work | 15 |
| OS module data displayed in UI | 10 |
| UI is clean and functional (HTML/CSS) | 15 |
| Security: path sanitization implemented | 5 |
| Report: explains networking concepts | 10 |
| **Total** | **100** |

---

## Report Topics (for written submission)

1. **HTTP Protocol** — Explain GET vs POST. Show the HTTP headers used in your upload request.
2. **TCP/IP** — How does your app use TCP? What is the 3-way handshake?
3. **WebSocket** — Explain how WebSocket differs from HTTP. Draw the connection lifecycle.
4. **OSI Model** — Identify which OSI layers are involved in a file transfer in your app.
5. **OS File System** — What happens at the OS level when `fs.writeFile` is called?
6. **Streams** — Explain what a Node.js stream is and why it's memory-efficient.
7. **Security** — What is a path traversal attack and how did you prevent it?

---

## References

- Node.js `http` docs: https://nodejs.org/api/http.html
- Node.js `fs` docs: https://nodejs.org/api/fs.html
- Node.js `os` docs: https://nodejs.org/api/os.html
- WebSocket RFC 6455: https://datatracker.ietf.org/doc/html/rfc6455
- MDN Fetch API: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
- MDN WebSocket API: https://developer.mozilla.org/en-US/docs/Web/API/WebSocket
