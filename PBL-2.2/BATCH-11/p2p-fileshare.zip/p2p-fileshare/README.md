# P2P FileShare — PBL Project

A browser-based file sharing app that works over your local Wi-Fi network.
No internet required. No cloud. Just Node.js + your LAN.

## Quick Start

```bash
npm install
node server.js
```

Then open `http://localhost:3000` in your browser.
Share `http://<YOUR-LAN-IP>:3000` with anyone on the same Wi-Fi.

## Tech Stack
- **Backend:** Node.js (no framework — raw `http` module + `ws`)
- **Frontend:** Vanilla HTML, CSS, JavaScript
- **Real-time:** WebSocket (`ws` package)
- **Storage:** Local file system (`uploads/` folder)

## Concepts Covered
- HTTP protocol, multipart/form-data, chunked transfer
- WebSocket full-duplex communication
- Node.js streams and file system I/O
- OS module (CPU, memory, network interfaces)
- LAN IP addressing and port binding
- Security: path sanitization

See `PROJECT_PLAN.md` for the full 4-week plan and rubric.
