/**
 * P2P File Sharing Server
 * PBL Project — Node.js + Networking + OS concepts
 *
 * Concepts demonstrated:
 *  - HTTP server (Node.js net stack)
 *  - Multipart/form-data file uploads
 *  - Node.js streams & chunked transfer
 *  - File system I/O (os module)
 *  - WebSocket for real-time progress
 *  - MIME type detection
 *  - LAN IP discovery
 */

const http       = require('http');
const fs         = require('fs');
const path       = require('path');
const os         = require('os');
const { WebSocketServer } = require('ws');

// ─── Config ───────────────────────────────────────────────────────────────────
const PORT        = 3000;
const UPLOAD_DIR  = path.join(__dirname, 'uploads');
const PUBLIC_DIR  = path.join(__dirname, 'public');
const MAX_SIZE_MB = 500; // max file size in MB

// ─── Ensure upload directory exists ───────────────────────────────────────────
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ─── Utility: get local LAN IP ────────────────────────────────────────────────
function getLanIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
    }
  }
  return '127.0.0.1';
}

// ─── Utility: MIME type map ────────────────────────────────────────────────────
const MIME_TYPES = {
  '.html': 'text/html',
  '.css':  'text/css',
  '.js':   'application/javascript',
  '.json': 'application/json',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.gif':  'image/gif',
  '.svg':  'image/svg+xml',
  '.pdf':  'application/pdf',
  '.zip':  'application/zip',
  '.txt':  'text/plain',
};

function getMime(filePath) {
  return MIME_TYPES[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
}

// ─── Utility: parse multipart/form-data manually ──────────────────────────────
// This teaches students how HTTP multipart bodies work at the binary level.
function parseMultipart(buffer, boundary) {
  const files = [];
  const boundaryBuf = Buffer.from('--' + boundary);
  const parts = [];

  let start = 0;
  while (start < buffer.length) {
    const idx = buffer.indexOf(boundaryBuf, start);
    if (idx === -1) break;
    const end = buffer.indexOf(boundaryBuf, idx + boundaryBuf.length);
    if (end === -1) break;
    parts.push(buffer.slice(idx + boundaryBuf.length + 2, end - 2)); // skip \r\n
    start = end;
  }

  for (const part of parts) {
    // Split headers from body at \r\n\r\n
    const headerEnd = part.indexOf('\r\n\r\n');
    if (headerEnd === -1) continue;
    const headerStr = part.slice(0, headerEnd).toString();
    const body = part.slice(headerEnd + 4);

    const nameMatch     = headerStr.match(/name="([^"]+)"/);
    const filenameMatch = headerStr.match(/filename="([^"]+)"/);
    if (!filenameMatch) continue;

    files.push({
      fieldName: nameMatch ? nameMatch[1] : 'file',
      filename:  filenameMatch[1],
      data:      body,
    });
  }
  return files;
}

// ─── Track connected WebSocket clients ────────────────────────────────────────
const wsClients = new Set();

function broadcast(msg) {
  const str = JSON.stringify(msg);
  for (const client of wsClients) {
    if (client.readyState === 1) client.send(str);
  }
}

// ─── List uploaded files ───────────────────────────────────────────────────────
function listFiles() {
  if (!fs.existsSync(UPLOAD_DIR)) return [];
  return fs.readdirSync(UPLOAD_DIR).map(name => {
    const full = path.join(UPLOAD_DIR, name);
    const stat = fs.statSync(full);
    return {
      name,
      size:     stat.size,
      modified: stat.mtime.toISOString(),
      mime:     getMime(name),
    };
  });
}

// ─── HTTP Server ──────────────────────────────────────────────────────────────
const server = http.createServer((req, res) => {

  // CORS headers (lets browser on same LAN connect)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204); res.end(); return;
  }

  const url = new URL(req.url, `http://${req.headers.host}`);

  // ── GET /api/files — list all uploaded files ──
  if (req.method === 'GET' && url.pathname === '/api/files') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(listFiles()));
    return;
  }

  // ── GET /api/info — server system info ──
  if (req.method === 'GET' && url.pathname === '/api/info') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      hostname:    os.hostname(),
      platform:    os.platform(),
      arch:        os.arch(),
      cpus:        os.cpus().length,
      totalMem:    os.totalmem(),
      freeMem:     os.freemem(),
      uptime:      os.uptime(),
      lanIP:       getLanIP(),
      port:        PORT,
    }));
    return;
  }

  // ── POST /api/upload — receive file upload ──
  if (req.method === 'POST' && url.pathname === '/api/upload') {
    const contentType = req.headers['content-type'] || '';
    const boundaryMatch = contentType.match(/boundary=(.+)/);
    if (!boundaryMatch) {
      res.writeHead(400); res.end('Missing boundary'); return;
    }
    const boundary = boundaryMatch[1];

    const chunks = [];
    let received = 0;
    const totalSize = parseInt(req.headers['content-length'] || '0', 10);

    req.on('data', chunk => {
      chunks.push(chunk);
      received += chunk.length;
      // Broadcast upload progress over WebSocket
      if (totalSize > 0) {
        broadcast({ type: 'upload_progress', percent: Math.round((received / totalSize) * 100) });
      }
      // Reject if too large
      if (received > MAX_SIZE_MB * 1024 * 1024) {
        res.writeHead(413); res.end('File too large');
        req.destroy();
      }
    });

    req.on('end', () => {
      const body = Buffer.concat(chunks);
      const files = parseMultipart(body, boundary);

      if (files.length === 0) {
        res.writeHead(400); res.end('No files found'); return;
      }

      const saved = [];
      for (const file of files) {
        // Sanitize filename to prevent path traversal (security concept)
        const safeName = path.basename(file.filename).replace(/[^a-zA-Z0-9._\-]/g, '_');
        const dest = path.join(UPLOAD_DIR, safeName);
        fs.writeFileSync(dest, file.data);
        saved.push({ name: safeName, size: file.data.length });
        console.log(`[UPLOAD] ${safeName} (${file.data.length} bytes) from ${req.socket.remoteAddress}`);
      }

      // Notify all clients a new file arrived
      broadcast({ type: 'new_file', files: listFiles() });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, saved }));
    });

    req.on('error', err => {
      console.error('[UPLOAD ERROR]', err.message);
      res.writeHead(500); res.end('Upload failed');
    });
    return;
  }

  // ── GET /download/:filename — stream file to browser ──
  if (req.method === 'GET' && url.pathname.startsWith('/download/')) {
    const filename = decodeURIComponent(url.pathname.slice('/download/'.length));
    const safeName = path.basename(filename);
    const filePath = path.join(UPLOAD_DIR, safeName);

    if (!fs.existsSync(filePath)) {
      res.writeHead(404); res.end('File not found'); return;
    }

    const stat = fs.statSync(filePath);
    res.writeHead(200, {
      'Content-Type':        getMime(filePath),
      'Content-Disposition': `attachment; filename="${safeName}"`,
      'Content-Length':      stat.size,
    });

    // Stream the file — teaches Node.js streams concept
    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
    console.log(`[DOWNLOAD] ${safeName} → ${req.socket.remoteAddress}`);
    return;
  }

  // ── DELETE /api/files/:filename ──
  if (req.method === 'DELETE' && url.pathname.startsWith('/api/files/')) {
    const filename = decodeURIComponent(url.pathname.slice('/api/files/'.length));
    const safeName = path.basename(filename);
    const filePath = path.join(UPLOAD_DIR, safeName);

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      broadcast({ type: 'new_file', files: listFiles() });
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } else {
      res.writeHead(404); res.end('Not found');
    }
    return;
  }

  // ── Serve static files from /public ──
  let filePath = path.join(PUBLIC_DIR, url.pathname === '/' ? 'index.html' : url.pathname);
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    res.writeHead(200, { 'Content-Type': getMime(filePath) });
    fs.createReadStream(filePath).pipe(res);
    return;
  }

  res.writeHead(404); res.end('Not found');
});

// ─── WebSocket Server (same port via upgrade) ─────────────────────────────────
const wss = new WebSocketServer({ server });

wss.on('connection', (ws, req) => {
  wsClients.add(ws);
  const clientIP = req.socket.remoteAddress;
  console.log(`[WS] Client connected: ${clientIP} (total: ${wsClients.size})`);

  // Send current file list immediately on connect
  ws.send(JSON.stringify({ type: 'new_file', files: listFiles() }));

  ws.on('close', () => {
    wsClients.delete(ws);
    console.log(`[WS] Client disconnected: ${clientIP} (total: ${wsClients.size})`);
  });

  ws.on('error', err => console.error('[WS ERROR]', err.message));
});

// ─── Start ────────────────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  const lanIP = getLanIP();
  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║       P2P File Share Server Running      ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  Local:   http://localhost:${PORT}           ║`);
  console.log(`║  Network: http://${lanIP}:${PORT}      ║`);
  console.log('║                                          ║');
  console.log('║  Share the Network URL with anyone on    ║');
  console.log('║  the same Wi-Fi to transfer files!       ║');
  console.log('╚══════════════════════════════════════════╝\n');
});
