const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const session = require("express-session");
const path = require("path");

const app = express();

// ================= DATABASE =================

mongoose.connect("mongodb://127.0.0.1:27017/cyberquiz")
.then(() => console.log("MongoDB Connected"))
.catch((err) => console.log(err));

// ================= USER MODEL =================

const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String,

    score: {
        type: Number,
        default: 0
    }
});

const User = mongoose.model("User", userSchema);

// ================= MIDDLEWARE =================

app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: "cybersecret",
    resave: false,
    saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, "public")));

// ================= EJS SETTINGS =================

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// ================= ROUTES =================

// Home Page
app.get("/", (req, res) => {
    res.render("home");
});

// ================= REGISTER =================

// Register Page
app.get("/register", (req, res) => {
    res.render("register");
});

// Register User
app.post("/register", async (req, res) => {

    const { username, email, password } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
        username,
        email,
        password: hashedPassword
    });

    await newUser.save();

    res.redirect("/login");
});

// ================= LOGIN =================

// Login Page
app.get("/login", (req, res) => {
    res.render("login");
});

// Login User
app.post("/login", async (req, res) => {

    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if (!user) {
        return res.send("User Not Found");
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
        return res.send("Invalid Password");
    }

    req.session.user = user;

    res.redirect("/quiz");
});

// ================= DASHBOARD =================

// Dashboard Page
app.get("/dashboard", (req, res) => {

    if (!req.session.user) {
        return res.redirect("/login");
    }

    res.render("dashboard", {
    username: req.session.user.username,
    score: req.session.user.score || 0
});
});

// ================= LOGOUT =================

app.get("/logout", (req, res) => {
    req.session.destroy();
    res.redirect("/login");
});

// ================= QUIZ ROUTES =================

// Quiz Page
app.get("/quiz", (req, res) => {

    if (!req.session.user) {
        return res.redirect("/login");
    }

    res.render("quiz");
});

app.post("/quiz", (req, res) => {

    let score = 0;

    // Question 1
    if (req.body.q1 === "b") {
        score++;
    }

    // Question 2
    if (req.body.q2 === "c") {
        score++;
    }

    // Question 3
    if (req.body.q3 === "a") {
        score++;
    }
       req.session.user.score = score;

    res.render("result", {
        score: score
    });

});

// ================= SERVER =================

app.listen(3000, () => {
    console.log("Server running on port 3000");
});