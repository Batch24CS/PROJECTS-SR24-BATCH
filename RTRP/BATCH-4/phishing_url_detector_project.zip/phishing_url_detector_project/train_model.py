import pandas as pd
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Sample dataset
data = {
    "url_length": [20, 75, 15, 90, 40, 120],
    "dot_count": [1, 5, 1, 7, 2, 8],
    "has_at": [0, 1, 0, 1, 0, 1],
    "has_hyphen": [0, 1, 0, 1, 0, 1],
    "https": [1, 0, 1, 0, 1, 0],
    "label": [1, 0, 1, 0, 1, 0]
}

df = pd.DataFrame(data)

X = df.drop("label", axis=1)
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestClassifier()
model.fit(X_train, y_train)

predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)
print(f"Model Accuracy: {accuracy * 100:.2f}%")

with open("model.pkl", "wb") as file:
    pickle.dump(model, file)

print("Model saved as model.pkl")