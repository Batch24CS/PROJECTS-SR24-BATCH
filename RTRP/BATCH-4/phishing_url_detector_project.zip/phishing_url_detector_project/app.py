import streamlit as st
import pickle
import pandas as pd
from urllib.parse import urlparse

# Load trained model
with open("model.pkl", "rb") as file:
    model = pickle.load(file)

st.set_page_config(page_title="Phishing URL Detector", page_icon="🛡️")

st.title("🛡️ Phishing URL Detector")
st.write("Enter a URL to check whether it is Safe or Phishing.")

def extract_features(url):
    return pd.DataFrame([{
        "url_length": len(url),
        "dot_count": url.count('.'),
        "has_at": 1 if '@' in url else 0,
        "has_hyphen": 1 if '-' in url else 0,
        "https": 1 if url.startswith("https") else 0
    }])

url = st.text_input("Enter URL")

if st.button("Analyze"):
    if url:
        features = extract_features(url)
        prediction = model.predict(features)[0]

        if prediction == 1:
            st.success("✅ Legitimate URL")
        else:
            st.error("❌ Phishing URL")
    else:
        st.warning("Please enter a URL.")