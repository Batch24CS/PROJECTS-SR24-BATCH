# Phishing URL Detection using Machine Learning

## Project Overview
This project detects phishing URLs using Machine Learning techniques.
It analyzes URLs based on extracted features and predicts whether
the URL is legitimate or phishing.

## Technologies Used
- Python
- pandas
- scikit-learn
- Streamlit

## Features
- Real-time URL analysis
- Random Forest model
- Simple Streamlit interface

## Run the Project

### Step 1: Install dependencies
pip install -r requirements.txt

### Step 2: Train the model
python train_model.py

### Step 3: Run the Streamlit app
streamlit run app.py