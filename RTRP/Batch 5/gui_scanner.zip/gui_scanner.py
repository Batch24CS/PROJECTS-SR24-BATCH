import socket
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from concurrent.futures import ThreadPoolExecutor, as_completed

COMMON_SERVICES = {
    22: "SSH", 80: "HTTP", 443: "HTTPS",
    3306: "MySQL", 8080: "HTTP Proxy"
}

COMMON_PORTS = [22, 80, 443, 3306, 8080]


def banner_grab(ip, port):
    try:
        with socket.socket() as s:
            s.settimeout(1)
            s.connect((ip, port))

            if port in [80, 8080]:
                s.send(b"HEAD / HTTP/1.0\r\n\r\n")

            banner = s.recv(1024).decode(errors="ignore").strip()
            banner = banner.replace("\n", " ").replace("\r", " ")

            return banner[:50] if banner else "No banner"

    except:
        return "No banner"


def scan_port(ip, port):
    try:
        with socket.socket() as s:
            s.settimeout(0.5)
            if s.connect_ex((ip, port)) == 0:
                service = COMMON_SERVICES.get(port, "Unknown")
                banner = banner_grab(ip, port)
                return (port, service, banner)
    except:
        pass
    return None


class PortScannerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Port Scanner")
        self.root.geometry("900x520")

        self.create_widgets()

    def create_widgets(self):
        frame_top = tk.Frame(self.root)
        frame_top.pack(pady=10)

        tk.Label(frame_top, text="Target").grid(row=0, column=0)
        self.target_entry = tk.Entry(frame_top, width=18)
        self.target_entry.grid(row=0, column=1)
        self.target_entry.insert(0, "127.0.0.1")

        tk.Label(frame_top, text="Mode").grid(row=0, column=2)
        self.mode = ttk.Combobox(
            frame_top,
            values=["Quick", "Common", "Custom", "Full"],
            width=10
        )
        self.mode.grid(row=0, column=3)
        self.mode.current(0)

        tk.Label(frame_top, text="Start").grid(row=0, column=4)
        self.start_entry = tk.Entry(frame_top, width=6)
        self.start_entry.grid(row=0, column=5)
        self.start_entry.insert(0, "1")

        tk.Label(frame_top, text="End").grid(row=0, column=6)
        self.end_entry = tk.Entry(frame_top, width=6)
        self.end_entry.grid(row=0, column=7)
        self.end_entry.insert(0, "1024")

        tk.Button(frame_top, text="Start", command=self.start_scan).grid(row=0, column=8, padx=5)
        tk.Button(frame_top, text="Clear", command=self.clear_results).grid(row=0, column=9, padx=5)
        tk.Button(frame_top, text="Export", command=self.export_results).grid(row=0, column=10, padx=5)

        self.progress = ttk.Progressbar(self.root, length=700)
        self.progress.pack(pady=5)

        self.status = tk.StringVar(value="Ready")
        tk.Label(self.root, textvariable=self.status).pack()

        columns = ("Port", "Service", "Banner")
        self.tree = ttk.Treeview(self.root, columns=columns, show="headings")

        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=250 if col == "Banner" else 120)

        self.tree.pack(expand=True, fill="both")

        self.results = []

    def get_ports(self):
        mode = self.mode.get()

        if mode == "Quick":
            return list(range(1, 1025))

        elif mode == "Common":
            return COMMON_PORTS

        elif mode == "Custom":
            try:
                start = int(self.start_entry.get())
                end = int(self.end_entry.get())
            except:
                messagebox.showerror("Error", "Invalid port input")
                return None

            if start < 1 or end > 65535 or start > end:
                messagebox.showerror("Error", "Invalid port range")
                return None

            return list(range(start, end + 1))

        elif mode == "Full":
            confirm = messagebox.askyesno(
                "Warning",
                "Full scan (1–65535) may take time.\nContinue?"
            )
            if not confirm:
                return None
            return list(range(1, 65536))

    def start_scan(self):
        self.tree.delete(*self.tree.get_children())
        self.results.clear()

        target = self.target_entry.get()

        try:
            ip = socket.gethostbyname(target)
        except:
            messagebox.showerror("Error", "Invalid target")
            return

        ports = self.get_ports()
        if ports is None:
            return

        total = len(ports)
        self.progress["maximum"] = total
        self.progress["value"] = 0

        def run():
            scanned = 0

            with ThreadPoolExecutor(max_workers=200) as executor:
                futures = [executor.submit(scan_port, ip, p) for p in ports]

                for f in as_completed(futures):
                    scanned += 1
                    self.progress["value"] = scanned

                    percent = (scanned / total) * 100
                    self.status.set(f"Scanning {scanned}/{total} ({percent:.1f}%)")

                    result = f.result()
                    if result:
                        self.results.append(result)
                        self.tree.insert("", "end", values=result)

            if not self.results:
                self.tree.insert("", "end", values=("None", "No open ports", "-"))

            self.status.set(f"Scan Complete | Open Ports: {len(self.results)}")

        threading.Thread(target=run, daemon=True).start()

    def clear_results(self):
        self.tree.delete(*self.tree.get_children())
        self.results.clear()
        self.progress["value"] = 0
        self.status.set("Cleared")

    def export_results(self):
        if not self.results:
            messagebox.showinfo("Info", "No results to export")
            return

        file = filedialog.asksaveasfilename(defaultextension=".txt")

        if file:
            with open(file, "w") as f:
                for r in self.results:
                    f.write(f"{r}\n")


root = tk.Tk()
app = PortScannerGUI(root)
root.mainloop()