import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

st.set_page_config(page_title="CLV Predictor")

st.title("Customer Lifetime Value Prediction")

# Mode selection
mode = st.radio("Select Mode", ["Train Model", "Predict"])

# ===========================
# TRAIN MODEL
# ===========================
if mode == "Train Model":

    uploaded_file = st.file_uploader("Upload Training Dataset (WITH CLV)", type=["csv"])

    if uploaded_file is not None:
        data = pd.read_csv(uploaded_file)

        st.subheader("Dataset Preview")
        st.dataframe(data.head())

        if "CustomerLifetimeValue" not in data.columns:
            st.error("Dataset must contain CustomerLifetimeValue column")
            st.stop()

        with st.spinner("Training model..."):

            if "Unnamed: 0" in data.columns:
                data = data.drop("Unnamed: 0", axis=1)
            if "Customer" in data.columns:
                data = data.drop("Customer", axis=1)

            X = data.drop("CustomerLifetimeValue", axis=1)
            y = data["CustomerLifetimeValue"]

            X = pd.get_dummies(X, drop_first=True)

            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )

            model = RandomForestRegressor(n_estimators=100, random_state=42)
            model.fit(X_train, y_train)

            predictions = model.predict(X_test)

            mae = mean_absolute_error(y_test, predictions)
            r2 = r2_score(y_test, predictions)

            joblib.dump(model, "clv_model.pkl")
            joblib.dump(X.columns, "columns.pkl")

        st.success("Model trained and saved")

        st.write("MAE:", round(mae, 2))
        st.write("R2 Score:", round(r2, 2))

        fig, ax = plt.subplots()
        ax.scatter(y_test, predictions)
        ax.set_xlabel("Actual CLV")
        ax.set_ylabel("Predicted CLV")
        st.pyplot(fig)

# ===========================
# PREDICT
# ===========================
elif mode == "Predict":

    uploaded_file = st.file_uploader("Upload New Dataset (WITHOUT CLV)", type=["csv"])

    if uploaded_file is not None:

        try:
            model = joblib.load("clv_model.pkl")
            columns = joblib.load("columns.pkl")
        except:
            st.error("Train model first")
            st.stop()

        data = pd.read_csv(uploaded_file)

        st.subheader("Dataset Preview")
        st.dataframe(data.head())

        with st.spinner("Predicting..."):

            if "Unnamed: 0" in data.columns:
                data = data.drop("Unnamed: 0", axis=1)
            if "Customer" in data.columns:
                data = data.drop("Customer", axis=1)

            data_encoded = pd.get_dummies(data, drop_first=True)
            data_encoded = data_encoded.reindex(columns=columns, fill_value=0)

            predictions = model.predict(data_encoded)
            data["Predicted_CLV"] = predictions

        st.success("Prediction completed")

        st.subheader("Predictions")
        st.dataframe(data)

        st.subheader("Top Profitable Customers")

        top_n = st.slider("Select Top Customers", 1, 20, 5)

        top_customers = data.sort_values(by="Predicted_CLV", ascending=False)
        st.dataframe(top_customers.head(top_n))

        fig, ax = plt.subplots()
        ax.hist(predictions, bins=20)
        ax.set_title("Predicted CLV Distribution")
        st.pyplot(fig)