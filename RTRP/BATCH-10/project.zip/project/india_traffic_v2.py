"""
╔══════════════════════════════════════════════════════════════════════════════╗
║   🇮🇳  BHARAT TRAFFIC AI v3.0 — ALL INDIA TRAFFIC MANAGEMENT GUI           ║
║   Python + Flask  |  Run: python india_traffic_v2.py                       ║
║   Open: http://localhost:5000                                               ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
from flask import Flask, jsonify, render_template_string
import random, threading, time
from dataclasses import dataclass, field
from typing import List, Dict
from collections import deque
from datetime import datetime

app = Flask(__name__)

INDIA_CITIES = {
    "Andhra Pradesh":       ["Visakhapatnam","Vijayawada","Guntur","Tirupati","Nellore","Kurnool","Rajahmundry","Kakinada","Kadapa","Anantapur"],
    "Arunachal Pradesh":    ["Itanagar","Naharlagun","Tawang","Ziro","Pasighat","Bomdila","Roing","Tezu"],
    "Assam":                ["Guwahati","Silchar","Dibrugarh","Jorhat","Nagaon","Tinsukia","Tezpur","Bongaigaon","Dhubri"],
    "Bihar":                ["Patna","Gaya","Bhagalpur","Muzaffarpur","Purnia","Darbhanga","Arrah","Begusarai","Katihar","Munger"],
    "Chhattisgarh":         ["Raipur","Bhilai","Bilaspur","Korba","Durg","Rajnandgaon","Jagdalpur","Ambikapur"],
    "Goa":                  ["Panaji","Margao","Vasco da Gama","Mapusa","Ponda","Bicholim"],
    "Gujarat":              ["Ahmedabad","Surat","Vadodara","Rajkot","Bhavnagar","Jamnagar","Gandhinagar","Junagadh","Anand","Morbi"],
    "Haryana":              ["Faridabad","Gurugram","Panipat","Ambala","Yamunanagar","Rohtak","Hisar","Karnal","Sonipat","Panchkula"],
    "Himachal Pradesh":     ["Shimla","Manali","Dharamshala","Solan","Mandi","Palampur","Baddi","Nahan"],
    "Jharkhand":            ["Ranchi","Jamshedpur","Dhanbad","Bokaro","Deoghar","Phusro","Hazaribagh","Giridih"],
    "Karnataka":            ["Bengaluru","Mysuru","Mangaluru","Hubli","Belagavi","Kalaburagi","Davanagere","Ballari","Vijayapura","Shivamogga"],
    "Kerala":               ["Thiruvananthapuram","Kochi","Kozhikode","Thrissur","Kollam","Palakkad","Alappuzha","Kannur","Kottayam","Malappuram"],
    "Madhya Pradesh":       ["Indore","Bhopal","Jabalpur","Gwalior","Ujjain","Sagar","Dewas","Satna","Ratlam","Rewa"],
    "Maharashtra":          ["Mumbai","Pune","Nagpur","Nashik","Aurangabad","Solapur","Amravati","Kolhapur","Navi Mumbai","Thane"],
    "Manipur":              ["Imphal","Thoubal","Bishnupur","Churachandpur","Ukhrul"],
    "Meghalaya":            ["Shillong","Tura","Jowai","Nongstoin","Williamnagar"],
    "Mizoram":              ["Aizawl","Lunglei","Saiha","Champhai","Serchhip"],
    "Nagaland":             ["Kohima","Dimapur","Mokokchung","Tuensang","Wokha"],
    "Odisha":               ["Bhubaneswar","Cuttack","Rourkela","Berhampur","Sambalpur","Puri","Balasore","Bhadrak","Baripada"],
    "Punjab":               ["Ludhiana","Amritsar","Jalandhar","Patiala","Bathinda","Mohali","Hoshiarpur","Batala","Pathankot"],
    "Rajasthan":            ["Jaipur","Jodhpur","Udaipur","Kota","Bikaner","Ajmer","Bhilwara","Alwar","Bharatpur","Sikar"],
    "Sikkim":               ["Gangtok","Namchi","Mangan","Gyalshing","Rangpo"],
    "Tamil Nadu":           ["Chennai","Coimbatore","Madurai","Tiruchirappalli","Salem","Tirunelveli","Tiruppur","Vellore","Erode","Thoothukudi"],
    "Telangana":            ["Hyderabad","Warangal","Nizamabad","Karimnagar","Khammam","Ramagundam","Mahbubnagar","Nalgonda","Adilabad","Siddipet"],
    "Tripura":              ["Agartala","Udaipur","Dharmanagar","Kailashahar","Belonia"],
    "Uttar Pradesh":        ["Lucknow","Kanpur","Agra","Varanasi","Prayagraj","Meerut","Bareilly","Aligarh","Moradabad","Gorakhpur"],
    "Uttarakhand":          ["Dehradun","Haridwar","Roorkee","Haldwani","Rudrapur","Kashipur","Rishikesh","Kotdwar"],
    "West Bengal":          ["Kolkata","Howrah","Durgapur","Asansol","Siliguri","Bardhaman","Malda","Baharampur","Habra","Kharagpur"],
    "Delhi":                ["New Delhi","Dwarka","Rohini","Saket","Laxmi Nagar","Janakpuri","Pitampura","Connaught Place","Chandni Chowk","Noida Border"],
    "Chandigarh":           ["Chandigarh","Manimajra","Panchkula","Mohali"],
    "Puducherry":           ["Puducherry","Karaikal","Yanam","Mahe"],
    "Jammu & Kashmir":      ["Srinagar","Jammu","Anantnag","Baramulla","Sopore","Kathua","Udhampur"],
    "Ladakh":               ["Leh","Kargil","Diskit","Zanskar"],
    "Andaman & Nicobar":    ["Port Blair","Diglipur","Mayabunder","Car Nicobar"],
    "Lakshadweep":          ["Kavaratti","Agatti","Minicoy","Amini"],
    "Dadra & Nagar Haveli": ["Silvassa","Amli","Khanvel"],
    "Daman & Diu":          ["Daman","Diu","Moti Daman"],
}

PEAK_HOURS = list(range(8,11)) + list(range(17,21))
METRO_CITIES = {"Mumbai","Delhi","New Delhi","Bengaluru","Hyderabad","Chennai","Kolkata","Ahmedabad","Pune","Surat"}

@dataclass
class CityIntersection:
    city: str
    state: str
    signal: str = "red"
    timer: int = 0
    queue: int = 0
    throughput: int = 0
    incident: bool = False
    load: int = 0
    green_duration: int = 30
    optimisations: int = 0
    weather: str = "Clear"
    history: list = field(default_factory=list)
    reroute: str = ""

    def to_dict(self):
        return {
            "city": self.city, "state": self.state,
            "signal": self.signal, "timer": self.timer,
            "queue": self.queue, "throughput": self.throughput,
            "incident": self.incident, "load": self.load,
            "green_duration": self.green_duration,
            "optimisations": self.optimisations,
            "weather": self.weather,
            "history": self.history[-10:],
            "reroute": self.reroute,
            "is_metro": self.city in METRO_CITIES,
        }

WEATHER_CONDITIONS = ["Clear","Cloudy","Rain","Heavy Rain","Fog","Storm","Haze"]

class IndiaTrafficEngine:
    def __init__(self):
        self.intersections: Dict[str, CityIntersection] = {}
        self.alerts: deque = deque(maxlen=100)
        self.tick = 0
        self.total_vehicles = 0
        self.total_optimisations = 0
        self.total_delay_saved = 0
        self._lock = threading.Lock()
        self._build()

    def _build(self):
        for state, cities in INDIA_CITIES.items():
            for city in cities:
                key = f"{city}|{state}"
                sig = random.choice(["red","yellow","green"])
                inter = CityIntersection(
                    city=city, state=state,
                    signal=sig, timer=random.randint(5,35),
                    queue=random.randint(5,40),
                    green_duration=random.randint(20,45),
                    weather=random.choice(WEATHER_CONDITIONS),
                )
                inter.load = min(99, inter.queue*3)
                self.intersections[key] = inter
        self.total_vehicles = len(self.intersections) * random.randint(200,600)

    def step(self):
        with self._lock:
            self.tick += 1
            hour = datetime.now().hour
            is_peak = hour in PEAK_HOURS
            multiplier = 1.8 if is_peak else 1.0

            for key, inter in self.intersections.items():
                # Weather change (rare)
                if random.random() < 0.003:
                    inter.weather = random.choice(WEATHER_CONDITIONS)

                weather_mult = {"Rain":1.3,"Heavy Rain":1.6,"Storm":2.0,"Fog":1.4,"Haze":1.1}.get(inter.weather,1.0)

                # Incidents
                if random.random() < 0.002 and not inter.incident:
                    inter.incident = True
                    self.alerts.appendleft({
                        "time": datetime.now().strftime("%H:%M:%S"),
                        "msg": f"Incident at {inter.city}, {inter.state}",
                        "type": "incident", "severity": "HIGH",
                        "city": inter.city, "state": inter.state
                    })
                elif inter.incident and random.random() < 0.04:
                    inter.incident = False
                    inter.reroute = ""
                    self.alerts.appendleft({
                        "time": datetime.now().strftime("%H:%M:%S"),
                        "msg": f"Cleared — {inter.city}, {inter.state}",
                        "type": "clear", "severity": "INFO",
                        "city": inter.city, "state": inter.state
                    })

                rate = int(random.randint(2,10) * multiplier * weather_mult)
                if inter.incident: rate = int(rate*1.6)
                inter.queue = max(0, inter.queue + rate)

                if inter.signal=="green" and not inter.incident:
                    leaving = random.randint(5,18)
                    inter.throughput = min(leaving, inter.queue)
                    inter.queue = max(0, inter.queue - leaving)
                else:
                    inter.throughput = 0

                inter.timer -= 1
                if inter.timer <= 0:
                    order = ["green","yellow","red"]
                    inter.signal = order[(order.index(inter.signal)+1)%3]
                    durations = {"green": inter.green_duration, "yellow": 5, "red": inter.green_duration+5}
                    inter.timer = durations[inter.signal]

                inter.load = min(99, inter.queue*3)

                # AI optimisation
                if inter.queue>25 and inter.signal=="red":
                    new_g = min(70, inter.green_duration+8)
                    if new_g != inter.green_duration:
                        inter.green_duration = new_g
                        inter.optimisations += 1
                        self.total_optimisations += 1
                        self.total_delay_saved += 10
                        self.alerts.appendleft({
                            "time": datetime.now().strftime("%H:%M:%S"),
                            "msg": f"AI extended green at {inter.city} (+8s)",
                            "type": "ai", "severity": "AI",
                            "city": inter.city, "state": inter.state
                        })
                elif inter.queue<5 and inter.signal=="green":
                    new_g = max(10, inter.green_duration-5)
                    if new_g != inter.green_duration:
                        inter.green_duration = new_g
                        inter.optimisations += 1
                        self.total_optimisations += 1

                if inter.incident:
                    inter.green_duration = 5
                    inter.reroute = f"Use alternate route — {inter.city} blocked"

                inter.history.append(inter.queue)
                if len(inter.history) > 20: inter.history.pop(0)

            self.total_vehicles += random.randint(-50,120)

    def get_snapshot(self):
        with self._lock:
            data = {k: v.to_dict() for k,v in self.intersections.items()}
            alerts = list(self.alerts)[:30]
            entries = list(self.intersections.values())
            stats = {
                "total_vehicles": self.total_vehicles,
                "total_optimisations": self.total_optimisations,
                "total_delay_saved": self.total_delay_saved,
                "tick": self.tick,
                "total_cities": len(self.intersections),
                "total_states": len(INDIA_CITIES),
                "incidents": sum(1 for v in entries if v.incident),
                "avg_load": int(sum(v.load for v in entries)/max(1,len(entries))),
                "congested": sum(1 for v in entries if v.queue>20),
                "green_count": sum(1 for v in entries if v.signal=="green"),
                "red_count": sum(1 for v in entries if v.signal=="red"),
                "yellow_count": sum(1 for v in entries if v.signal=="yellow"),
                "is_peak": datetime.now().hour in PEAK_HOURS,
                "current_hour": datetime.now().hour,
            }
            state_stats = {}
            for inter in entries:
                s = inter.state
                if s not in state_stats:
                    state_stats[s] = {"cities":0,"total_queue":0,"incidents":0,"avg_load":0,"green":0,"red":0,"yellow":0}
                state_stats[s]["cities"] += 1
                state_stats[s]["total_queue"] += inter.queue
                state_stats[s]["incidents"] += 1 if inter.incident else 0
                state_stats[s][inter.signal] += 1
            for s in state_stats:
                n = state_stats[s]["cities"]
                state_stats[s]["avg_load"] = min(99, int(state_stats[s]["total_queue"]*3/n))
            return {"data":data,"alerts":alerts,"stats":stats,"state_stats":state_stats}

engine = IndiaTrafficEngine()

def simulation_loop():
    while True:
        engine.step()
        time.sleep(1.5)

threading.Thread(target=simulation_loop, daemon=True).start()

@app.route("/api/snapshot")
def api_snapshot():
    return jsonify(engine.get_snapshot())

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>🇮🇳 Bharat Traffic AI</title>
<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300;400;500;600;700;800&family=Orbitron:wght@400;500;700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet"/>
<style>
:root {
  --bg:       #030508;
  --bg2:      #060a10;
  --bg3:      #09101a;
  --panel:    #0b1320;
  --card:     #0d1525;
  --border:   #112035;
  --border2:  #1a3050;
  --orange:   #ff6b00;
  --orange2:  #ff9500;
  --cyan:     #00d4ff;
  --cyan2:    #00ffee;
  --green:    #00ff88;
  --yellow:   #ffd000;
  --red:      #ff1a44;
  --purple:   #9b59ff;
  --pink:     #ff2d78;
  --text:     #b8cce0;
  --text2:    #7090b0;
  --white:    #e8f4ff;
  --gold:     #ffc840;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden}
body{background:var(--bg);color:var(--text);font-family:'Exo 2',sans-serif;font-size:13px;display:flex;flex-direction:column}

/* Custom scrollbar */
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:var(--bg)}
::-webkit-scrollbar-thumb{background:#1a3050;border-radius:2px}
::-webkit-scrollbar-thumb:hover{background:#224060}

/* ── HEADER ─────────────────────────────────────────────────────── */
.header{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 24px;height:56px;flex-shrink:0;
  background:linear-gradient(90deg,#06091400,#0c1830 40%,#0c1830 60%,#06091400);
  border-bottom:1px solid var(--border);
  position:relative;z-index:200;
}
.header::before{
  content:'';position:absolute;bottom:0;left:10%;right:10%;height:1px;
  background:linear-gradient(90deg,transparent,var(--orange),transparent);
  opacity:.4;
}
.logo{display:flex;align-items:center;gap:14px}
.logo-emblem{
  width:40px;height:40px;border-radius:10px;
  background:linear-gradient(135deg,#ff6b0022,#00d4ff22);
  border:1px solid #ff6b0044;
  display:flex;align-items:center;justify-content:center;
  font-size:20px;position:relative;
}
.logo-emblem::after{
  content:'';position:absolute;inset:-1px;border-radius:10px;
  background:linear-gradient(135deg,#ff6b0033,transparent 50%,#00d4ff22);
  pointer-events:none;
}
.logo-title{font-family:'Orbitron',monospace;font-size:18px;font-weight:700;
  letter-spacing:.08em;color:var(--white);line-height:1}
.logo-title span{color:var(--orange)}
.logo-sub{font-size:9px;color:var(--text2);letter-spacing:.22em;margin-top:3px}

.header-center{display:flex;gap:6px;align-items:center}
.nav-btn{
  padding:6px 14px;border:1px solid var(--border);border-radius:6px;
  background:transparent;color:var(--text2);cursor:pointer;
  font-family:'Exo 2',sans-serif;font-size:11px;font-weight:600;
  letter-spacing:.08em;transition:all .2s;
}
.nav-btn:hover{border-color:var(--cyan);color:var(--cyan);background:#00d4ff0a}
.nav-btn.active{border-color:var(--orange);color:var(--orange);background:#ff6b000d}

.header-right{display:flex;gap:16px;align-items:center}
.live-badge{
  display:flex;align-items:center;gap:6px;
  padding:5px 12px;border-radius:20px;
  background:#00ff8810;border:1px solid #00ff8830;
  font-size:10px;color:var(--green);font-weight:600;letter-spacing:.1em;
}
.live-dot{width:7px;height:7px;border-radius:50%;background:var(--green);
  box-shadow:0 0 8px var(--green);animation:pulse 1.4s infinite}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(1.5)}}
.clock{font-family:'Share Tech Mono',monospace;font-size:13px;color:var(--text2)}
.peak-badge{padding:4px 10px;border-radius:12px;font-size:9px;font-weight:700;
  letter-spacing:.12em;border:1px solid;display:none}
.peak-badge.active{display:block;background:#ff6b0010;border-color:#ff6b0040;color:var(--orange)}

/* ── KPI STRIP ──────────────────────────────────────────────────── */
.kpi-strip{
  display:grid;grid-template-columns:repeat(8,1fr);
  border-bottom:1px solid var(--border);flex-shrink:0;
  background:linear-gradient(180deg,var(--bg2),var(--bg));
}
.kpi{
  padding:10px 14px;border-right:1px solid var(--border);
  position:relative;overflow:hidden;cursor:default;
  transition:background .2s;
}
.kpi:last-child{border-right:none}
.kpi:hover{background:#0d1828}
.kpi::before{
  content:'';position:absolute;top:0;left:0;right:0;height:2px;
  opacity:0;transition:opacity .3s;
}
.kpi:hover::before{opacity:1}
.kpi-label{font-size:8px;letter-spacing:.18em;color:var(--text2);margin-bottom:3px;font-weight:600}
.kpi-value{font-family:'Orbitron',monospace;font-size:20px;font-weight:700;line-height:1;transition:color .3s}
.kpi-sub{font-size:9px;color:var(--text2);margin-top:2px}
.kpi-spark{height:20px;margin-top:4px;display:flex;align-items:flex-end;gap:1px}
.spark-bar{width:4px;border-radius:1px;min-height:2px;transition:height .4s}

/* ── MAIN LAYOUT ─────────────────────────────────────────────────── */
.main-area{display:flex;flex:1;overflow:hidden}
.sidebar{
  width:260px;flex-shrink:0;border-right:1px solid var(--border);
  display:flex;flex-direction:column;overflow:hidden;
  background:var(--bg2);
}
.content{flex:1;overflow:hidden;display:flex;flex-direction:column}

/* ── SIDEBAR ─────────────────────────────────────────────────────── */
.sidebar-search{
  padding:10px 12px;border-bottom:1px solid var(--border);
}
.search-input{
  width:100%;padding:7px 12px 7px 32px;
  background:var(--card);border:1px solid var(--border);
  border-radius:8px;color:var(--text);
  font-family:'Exo 2',sans-serif;font-size:12px;outline:none;
  transition:border-color .2s;position:relative;
}
.search-input:focus{border-color:var(--cyan)}
.search-wrap{position:relative}
.search-icon{position:absolute;left:10px;top:50%;transform:translateY(-50%);
  font-size:12px;pointer-events:none;color:var(--text2)}
.sidebar-filters{
  display:flex;gap:4px;padding:8px 12px;
  border-bottom:1px solid var(--border);flex-wrap:wrap;
}
.filt{
  padding:3px 8px;border-radius:12px;border:1px solid var(--border);
  background:transparent;color:var(--text2);font-size:9px;cursor:pointer;
  letter-spacing:.08em;font-family:'Exo 2',sans-serif;font-weight:600;
  transition:all .15s;
}
.filt.on{border-color:var(--orange);color:var(--orange);background:#ff6b000d}
.filt:hover:not(.on){border-color:var(--border2);color:var(--text)}

.sidebar-list{flex:1;overflow-y:auto;padding:4px 0}
.state-item{
  padding:10px 14px;border-bottom:1px solid #0a1520;
  cursor:pointer;transition:all .15s;position:relative;
}
.state-item::before{
  content:'';position:absolute;left:0;top:0;bottom:0;width:2px;
  background:var(--orange);opacity:0;transition:opacity .2s;
}
.state-item:hover::before,.state-item.active::before{opacity:1}
.state-item:hover,.state-item.active{background:#0d1828}
.state-item-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:5px}
.state-item-name{font-size:12px;font-weight:700;color:var(--white)}
.state-item-badge{
  font-size:8px;padding:2px 6px;border-radius:8px;font-weight:700;
  letter-spacing:.08em;
}
.state-item-meta{display:flex;justify-content:space-between;align-items:center}
.state-item-cities{font-size:9px;color:var(--text2)}
.state-signals{display:flex;gap:3px}
.s-dot{width:6px;height:6px;border-radius:50%}
.load-mini{height:2px;background:var(--border);border-radius:1px;margin-top:4px;overflow:hidden}
.load-mini-fill{height:100%;border-radius:1px;transition:width .8s}

/* ── CONTENT PANELS ──────────────────────────────────────────────── */
.panel{display:none;flex:1;overflow:hidden;flex-direction:column}
.panel.active{display:flex}

/* Dashboard panel */
.dashboard-grid{
  flex:1;overflow-y:auto;padding:14px;
  display:grid;grid-template-columns:1fr 1fr 1fr;
  grid-template-rows:auto auto 1fr;
  gap:12px;
}

/* City detail panel */
.city-detail-header{
  padding:16px 20px;border-bottom:1px solid var(--border);
  background:var(--bg2);flex-shrink:0;
}
.city-detail-body{flex:1;overflow-y:auto;padding:16px;
  display:grid;grid-template-columns:1fr 1fr;gap:12px}

/* Cities table panel */
.table-toolbar{
  padding:10px 16px;border-bottom:1px solid var(--border);
  display:flex;gap:8px;align-items:center;flex-shrink:0;
  background:var(--bg2);
}
.table-search{
  flex:1;padding:6px 12px;background:var(--card);
  border:1px solid var(--border);border-radius:6px;
  color:var(--text);font-family:'Exo 2',sans-serif;font-size:12px;outline:none;
}
.table-search:focus{border-color:var(--cyan)}
.tbl-filt{
  padding:5px 10px;border-radius:6px;border:1px solid var(--border);
  background:transparent;color:var(--text2);font-size:9px;cursor:pointer;
  font-family:'Exo 2',sans-serif;font-weight:700;letter-spacing:.08em;transition:all .15s;
}
.tbl-filt.on{border-color:var(--orange);color:var(--orange);background:#ff6b000d}
.table-wrap{flex:1;overflow-y:auto}
table.cities{width:100%;border-collapse:collapse}
table.cities th{
  text-align:left;font-size:9px;letter-spacing:.14em;color:var(--text2);
  padding:8px 12px;border-bottom:1px solid var(--border);font-weight:700;
  position:sticky;top:0;background:var(--bg2);z-index:10;
}
table.cities th.sortable{cursor:pointer}
table.cities th.sortable:hover{color:var(--cyan)}
table.cities td{padding:8px 12px;border-bottom:1px solid #07101a;transition:background .1s}
table.cities tr:hover td{background:#0a1520}
table.cities tr.inc-row td{background:#12040a}
table.cities tr.inc-row:hover td{background:#170610}

/* ── CARDS ─────────────────────────────────────────────────────── */
.card{
  background:var(--card);border:1px solid var(--border);
  border-radius:12px;overflow:hidden;position:relative;
}
.card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,var(--border2),transparent);
}
.card-head{
  padding:12px 16px 10px;
  display:flex;justify-content:space-between;align-items:center;
  border-bottom:1px solid #0a1828;
}
.card-title{font-family:'Orbitron',monospace;font-size:11px;font-weight:500;
  letter-spacing:.1em;color:var(--text2)}
.card-body{padding:14px 16px}

/* Signal light widget */
.signal-widget{
  display:flex;flex-direction:column;align-items:center;gap:4px;
  background:#060c15;border-radius:8px;padding:10px 8px;
  border:1px solid #0e1a28;
}
.sig-light{width:18px;height:18px;border-radius:50%;transition:all .4s}
.sig-light.active{filter:brightness(1)}
.sig-light.inactive{filter:brightness(.12)}

/* Progress arc */
.arc-wrap{position:relative;width:80px;height:80px}
.arc-svg{width:80px;height:80px;transform:rotate(-90deg)}
.arc-track{fill:none;stroke:#0d1828;stroke-width:6}
.arc-fill{fill:none;stroke-width:6;stroke-linecap:round;transition:stroke-dashoffset 1s ease}
.arc-center{position:absolute;inset:0;display:flex;flex-direction:column;
  align-items:center;justify-content:center}
.arc-val{font-family:'Orbitron',monospace;font-size:18px;font-weight:700;line-height:1}
.arc-lbl{font-size:8px;color:var(--text2);letter-spacing:.1em;margin-top:2px}

/* Sparkline */
.sparkline-canvas{width:100%;height:40px;display:block}

/* Alert items */
.alert-list{display:flex;flex-direction:column;gap:0}
.a-item{
  padding:9px 14px;border-bottom:1px solid #080e18;
  display:flex;gap:10px;align-items:flex-start;
  animation:slideIn .25s ease;transition:background .15s;
}
.a-item:hover{background:#0a1520}
@keyframes slideIn{from{opacity:0;transform:translateX(-6px)}to{opacity:1;transform:translateX(0)}}
.a-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;margin-top:3px}
.a-content{flex:1;min-width:0}
.a-msg{font-size:11px;line-height:1.4}
.a-time{font-family:'Share Tech Mono',monospace;font-size:9px;color:var(--text2);margin-top:2px}
.a-badge{
  font-size:8px;padding:2px 6px;border-radius:8px;
  font-weight:700;letter-spacing:.1em;flex-shrink:0;margin-top:1px;
  font-family:'Share Tech Mono',monospace;
}

/* Weather icon */
.weather-icon{font-size:20px}

/* City popup */
.city-popup{
  position:fixed;top:0;left:0;right:0;bottom:0;
  background:#000000cc;z-index:500;
  display:flex;align-items:center;justify-content:center;
  backdrop-filter:blur(4px);
  opacity:0;pointer-events:none;transition:opacity .25s;
}
.city-popup.open{opacity:1;pointer-events:all}
.popup-box{
  background:var(--card);border:1px solid var(--border2);
  border-radius:16px;width:520px;max-width:94vw;
  box-shadow:0 30px 80px #00000088;
  animation:popIn .25s ease;
}
@keyframes popIn{from{transform:scale(.94);opacity:0}to{transform:scale(1);opacity:1}}
.popup-head{
  padding:18px 20px;border-bottom:1px solid var(--border);
  display:flex;justify-content:space-between;align-items:flex-start;
}
.popup-close{
  width:28px;height:28px;border-radius:50%;border:1px solid var(--border);
  background:transparent;color:var(--text2);cursor:pointer;font-size:14px;
  display:flex;align-items:center;justify-content:center;transition:all .2s;
}
.popup-close:hover{border-color:var(--red);color:var(--red)}
.popup-body{padding:18px 20px;display:grid;grid-template-columns:1fr 1fr;gap:12px}
.popup-stat{background:var(--bg3);border-radius:8px;padding:12px}
.popup-stat-label{font-size:9px;letter-spacing:.14em;color:var(--text2);margin-bottom:4px}
.popup-stat-val{font-family:'Orbitron',monospace;font-size:20px;font-weight:700}

/* Toast */
.toast{
  position:fixed;bottom:24px;right:24px;z-index:1000;
  background:var(--card);border:1px solid var(--border2);
  border-radius:10px;padding:12px 16px;
  display:flex;gap:10px;align-items:center;
  box-shadow:0 8px 32px #00000060;
  transform:translateY(20px);opacity:0;transition:all .3s;
  max-width:320px;
}
.toast.show{transform:translateY(0);opacity:1}

/* Heatmap grid */
.heatmap{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(70px,1fr));
  gap:3px;
}
.hm-cell{
  border-radius:4px;padding:5px 6px;cursor:pointer;transition:all .2s;
  position:relative;overflow:hidden;
}
.hm-cell:hover{transform:scale(1.05);z-index:2}
.hm-city{font-size:8px;font-weight:700;color:var(--white);white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis}
.hm-load{font-family:'Share Tech Mono',monospace;font-size:9px;margin-top:1px}

/* Incident cards */
.incident-list{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
  gap:10px;padding:14px;overflow-y:auto;
}
.inc-card{
  background:#100508;border:1px solid #ff1a4430;
  border-radius:10px;padding:14px;position:relative;overflow:hidden;
}
.inc-card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,#ff1a44,transparent);
}
.inc-pulse{
  width:10px;height:10px;border-radius:50%;background:var(--red);
  box-shadow:0 0 12px var(--red);animation:pulse 1s infinite;
  display:inline-block;margin-right:6px;
}
.inc-city{font-family:'Orbitron',monospace;font-size:14px;font-weight:700;
  color:var(--red);margin-bottom:2px}
.inc-state{font-size:10px;color:var(--text2)}
.inc-detail{margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:6px}
.inc-stat{background:#0a0205;border-radius:6px;padding:8px}
.inc-stat-l{font-size:8px;color:#ff4466;letter-spacing:.1em}
.inc-stat-v{font-family:'Orbitron',monospace;font-size:16px;color:var(--red);margin-top:2px}
.reroute-badge{
  margin-top:8px;padding:5px 8px;background:#0a0205;border-radius:6px;
  font-size:9px;color:#ff6680;border:1px solid #ff1a4420;
}

/* Analytics */
.analytics-wrap{flex:1;overflow-y:auto;padding:14px;
  display:grid;grid-template-columns:1fr 1fr;gap:12px}
.bar-row{display:grid;grid-template-columns:110px 1fr 50px;
  align-items:center;gap:8px;margin-bottom:6px}
.bar-label{font-size:10px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bar-track{height:6px;background:#0d1828;border-radius:3px;overflow:hidden}
.bar-fill{height:100%;border-radius:3px;transition:width 1s ease}
.bar-val{font-family:'Share Tech Mono',monospace;font-size:10px;text-align:right}

/* Donut chart */
.donut-wrap{display:flex;align-items:center;gap:20px;padding:8px 0}
.donut-svg{flex-shrink:0}
.donut-legend{display:flex;flex-direction:column;gap:8px}
.legend-item{display:flex;align-items:center;gap:8px;font-size:11px}
.legend-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}

/* Smooth number animation */
.animated-num{transition:all .4s ease}

/* Region map */
.region-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.region-card{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:8px;padding:10px;cursor:pointer;transition:all .2s;
}
.region-card:hover{border-color:var(--cyan);background:#0a1520}
.region-name{font-size:10px;font-weight:700;color:var(--white);margin-bottom:4px}

/* Tooltip */
.tooltip{
  position:fixed;background:var(--card);border:1px solid var(--border2);
  border-radius:6px;padding:6px 10px;font-size:10px;
  pointer-events:none;z-index:999;opacity:0;transition:opacity .15s;
  box-shadow:0 4px 16px #00000060;
}
.tooltip.show{opacity:1}

/* Scrolling ticker */
.ticker{
  height:28px;background:#0a1020;border-bottom:1px solid var(--border);
  overflow:hidden;display:flex;align-items:center;flex-shrink:0;
}
.ticker-inner{
  display:flex;gap:40px;white-space:nowrap;
  animation:ticker 60s linear infinite;
  font-size:10px;color:var(--text2);font-family:'Share Tech Mono',monospace;
}
@keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
.tick-item{display:flex;align-items:center;gap:6px}
.tick-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <div class="logo">
    <div class="logo-emblem">🚦</div>
    <div>
      <div class="logo-title">BHARAT <span>TRAFFIC</span> AI</div>
      <div class="logo-sub">NATIONAL INTELLIGENT TRANSPORT SYSTEM v3.0</div>
    </div>
  </div>
  <div class="header-center">
    <button class="nav-btn active" onclick="showPanel('dashboard',this)">📊 DASHBOARD</button>
    <button class="nav-btn" onclick="showPanel('cities',this)">🏙️ CITIES</button>
    <button class="nav-btn" onclick="showPanel('heatmap',this)">🔥 HEATMAP</button>
    <button class="nav-btn" onclick="showPanel('analytics',this)">📈 ANALYTICS</button>
    <button class="nav-btn" onclick="showPanel('incidents',this)">⚠️ INCIDENTS</button>
    <button class="nav-btn" onclick="showPanel('alerts',this)">🔔 ALERTS</button>
  </div>
  <div class="header-right">
    <div class="peak-badge" id="peak-badge">⚡ PEAK HOUR</div>
    <div class="live-badge"><span class="live-dot"></span>LIVE</div>
    <div class="clock" id="clock"></div>
    <div style="font-size:18px">🇮🇳</div>
  </div>
</div>

<!-- TICKER -->
<div class="ticker"><div class="ticker-inner" id="ticker-inner"></div></div>

<!-- KPI STRIP -->
<div class="kpi-strip">
  <div class="kpi" style="--c:var(--cyan)">
    <div class="kpi-label">VEHICLES</div>
    <div class="kpi-value" id="k-v" style="color:var(--cyan)">—</div>
    <div class="kpi-sub">Tracked nationally</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">CITIES</div>
    <div class="kpi-value" id="k-c" style="color:var(--green)">—</div>
    <div class="kpi-sub">All India</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">STATES / UTs</div>
    <div class="kpi-value" id="k-s" style="color:var(--orange)">—</div>
    <div class="kpi-sub">Coverage</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">INCIDENTS</div>
    <div class="kpi-value" id="k-i" style="color:var(--red)">—</div>
    <div class="kpi-sub">Active alerts</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">AI OPTS</div>
    <div class="kpi-value" id="k-o" style="color:var(--purple)">—</div>
    <div class="kpi-sub">Optimisations</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">DELAY SAVED</div>
    <div class="kpi-value" id="k-d" style="color:var(--gold)">—</div>
    <div class="kpi-sub">Seconds total</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">CONGESTED</div>
    <div class="kpi-value" id="k-cong" style="color:var(--yellow)">—</div>
    <div class="kpi-sub">High-load zones</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">AVG LOAD</div>
    <div class="kpi-value" id="k-load" style="color:var(--pink)">—</div>
    <div class="kpi-sub">Network wide</div>
  </div>
</div>

<!-- MAIN -->
<div class="main-area">

  <!-- SIDEBAR -->
  <div class="sidebar">
    <div class="sidebar-search">
      <div class="search-wrap">
        <span class="search-icon">🔍</span>
        <input class="search-input" id="sb-search" placeholder="Search state or city..." oninput="filterSidebar()"/>
      </div>
    </div>
    <div class="sidebar-filters">
      <button class="filt on"  onclick="setSbFilter('all',this)">ALL</button>
      <button class="filt" onclick="setSbFilter('incident',this)">⚠ INC</button>
      <button class="filt" onclick="setSbFilter('high',this)">🔴 HIGH</button>
      <button class="filt" onclick="setSbFilter('clear',this)">🟢 OK</button>
    </div>
    <div class="sidebar-list" id="sidebar-list"></div>
  </div>

  <!-- CONTENT -->
  <div class="content">

    <!-- DASHBOARD -->
    <div class="panel active" id="panel-dashboard">
      <div class="dashboard-grid">

        <!-- Signal Status -->
        <div class="card" style="grid-column:1;grid-row:1">
          <div class="card-head"><span class="card-title">SIGNAL OVERVIEW</span></div>
          <div class="card-body" style="display:flex;gap:16px;align-items:center">
            <div id="donut-wrap" class="donut-wrap"></div>
            <div style="flex:1">
              <div id="sig-stats"></div>
            </div>
          </div>
        </div>

        <!-- Network Health -->
        <div class="card" style="grid-column:2;grid-row:1">
          <div class="card-head"><span class="card-title">NETWORK HEALTH</span></div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
            <div style="display:flex;justify-content:center">
              <div class="arc-wrap" id="eff-arc">
                <svg class="arc-svg" viewBox="0 0 80 80">
                  <circle class="arc-track" cx="40" cy="40" r="32"/>
                  <circle class="arc-fill" cx="40" cy="40" r="32" id="arc-circle"
                    stroke="var(--green)" stroke-dasharray="201" stroke-dashoffset="201"/>
                </svg>
                <div class="arc-center">
                  <div class="arc-val" id="arc-val" style="color:var(--green)">—</div>
                  <div class="arc-lbl">EFFICIENCY</div>
                </div>
              </div>
            </div>
            <div id="health-bars"></div>
          </div>
        </div>

        <!-- AI Engine -->
        <div class="card" style="grid-column:3;grid-row:1">
          <div class="card-head">
            <span class="card-title">AI ENGINE</span>
            <span style="font-size:9px;color:var(--green);font-family:'Share Tech Mono',monospace">● ACTIVE</span>
          </div>
          <div class="card-body" id="ai-engine-panel"></div>
        </div>

        <!-- Top congested -->
        <div class="card" style="grid-column:1/3;grid-row:2">
          <div class="card-head">
            <span class="card-title">TOP CONGESTED CITIES</span>
            <span id="peak-label" style="font-size:9px;color:var(--text2)"></span>
          </div>
          <div class="card-body" id="top-congested"></div>
        </div>

        <!-- Live alerts -->
        <div class="card" style="grid-column:3;grid-row:2/4">
          <div class="card-head">
            <span class="card-title">LIVE ALERTS</span>
            <span id="alert-count" style="font-size:10px;font-family:'Share Tech Mono',monospace;color:var(--orange)">0</span>
          </div>
          <div style="overflow-y:auto;max-height:340px" id="dash-alerts"></div>
        </div>

        <!-- State ranking -->
        <div class="card" style="grid-column:1/3;grid-row:3">
          <div class="card-head"><span class="card-title">STATE LOAD RANKING</span></div>
          <div class="card-body" id="state-rank" style="max-height:200px;overflow-y:auto"></div>
        </div>

      </div>
    </div>

    <!-- CITIES TABLE -->
    <div class="panel" id="panel-cities">
      <div class="table-toolbar">
        <input class="table-search" id="tbl-search" placeholder="🔍 Search city, state..." oninput="renderCitiesTable()"/>
        <button class="tbl-filt on" onclick="setTblFilter('all',this)">ALL</button>
        <button class="tbl-filt" onclick="setTblFilter('red',this)">🔴 RED</button>
        <button class="tbl-filt" onclick="setTblFilter('yellow',this)">🟡 YELLOW</button>
        <button class="tbl-filt" onclick="setTblFilter('green',this)">🟢 GREEN</button>
        <button class="tbl-filt" onclick="setTblFilter('incident',this)">⚠ INC</button>
        <button class="tbl-filt" onclick="setTblFilter('congested',this)">🚗 CONG</button>
        <button class="tbl-filt" onclick="setTblFilter('metro',this)">🏙 METRO</button>
        <span style="font-size:10px;color:var(--text2);margin-left:auto" id="tbl-count"></span>
      </div>
      <div class="table-wrap">
        <table class="cities">
          <thead>
            <tr>
              <th>SIG</th>
              <th class="sortable" onclick="sortTable('city')">CITY ↕</th>
              <th class="sortable" onclick="sortTable('state')">STATE ↕</th>
              <th class="sortable" onclick="sortTable('queue')">QUEUE ↕</th>
              <th>LOAD</th>
              <th class="sortable" onclick="sortTable('timer')">TIMER ↕</th>
              <th>WEATHER</th>
              <th>AI OPTS</th>
              <th>STATUS</th>
            </tr>
          </thead>
          <tbody id="cities-tbody"></tbody>
        </table>
      </div>
    </div>

    <!-- HEATMAP -->
    <div class="panel" id="panel-heatmap">
      <div style="padding:10px 14px;border-bottom:1px solid var(--border);
        display:flex;gap:10px;align-items:center;flex-shrink:0;background:var(--bg2)">
        <span style="font-size:10px;color:var(--text2);letter-spacing:.1em">CITY LOAD HEATMAP — ALL INDIA</span>
        <div style="display:flex;gap:4px;align-items:center;margin-left:auto;font-size:9px;color:var(--text2)">
          <div style="width:60px;height:6px;border-radius:3px;background:linear-gradient(90deg,#00ff88,#ffd000,#ff1a44)"></div>
          <span>LOW → HIGH</span>
        </div>
      </div>
      <div style="padding:10px 14px;overflow-y:auto;flex:1">
        <div id="heatmap-grid" class="heatmap"></div>
      </div>
    </div>

    <!-- ANALYTICS -->
    <div class="panel" id="panel-analytics">
      <div class="analytics-wrap" id="analytics-content"></div>
    </div>

    <!-- INCIDENTS -->
    <div class="panel" id="panel-incidents">
      <div style="padding:10px 16px;border-bottom:1px solid var(--border);
        flex-shrink:0;background:var(--bg2);display:flex;align-items:center;gap:8px">
        <span style="font-size:10px;letter-spacing:.12em;color:var(--text2)">ACTIVE INCIDENTS ACROSS INDIA</span>
        <span id="inc-count" style="font-family:'Share Tech Mono',monospace;font-size:11px;
          background:#ff1a4420;color:var(--red);padding:2px 8px;border-radius:10px;border:1px solid #ff1a4430"></span>
      </div>
      <div class="incident-list" id="incident-list"></div>
    </div>

    <!-- ALERTS LOG -->
    <div class="panel" id="panel-alerts">
      <div style="padding:10px 16px;border-bottom:1px solid var(--border);
        flex-shrink:0;background:var(--bg2);display:flex;gap:6px;align-items:center">
        <span style="font-size:10px;letter-spacing:.12em;color:var(--text2)">ALERTS LOG</span>
        <div style="display:flex;gap:4px;margin-left:auto">
          <button class="tbl-filt on" onclick="setAlertFilter('all',this)">ALL</button>
          <button class="tbl-filt" onclick="setAlertFilter('HIGH',this)">HIGH</button>
          <button class="tbl-filt" onclick="setAlertFilter('AI',this)">AI</button>
          <button class="tbl-filt" onclick="setAlertFilter('INFO',this)">INFO</button>
        </div>
      </div>
      <div style="flex:1;overflow-y:auto" id="alerts-log"></div>
    </div>

  </div>
</div>

<!-- CITY POPUP -->
<div class="city-popup" id="city-popup" onclick="closePopup(event)">
  <div class="popup-box">
    <div class="popup-head">
      <div>
        <div style="font-family:'Orbitron',monospace;font-size:18px;font-weight:700;
          color:var(--white)" id="popup-city">—</div>
        <div style="font-size:11px;color:var(--text2);margin-top:3px" id="popup-state">—</div>
      </div>
      <button class="popup-close" onclick="closePopup()">✕</button>
    </div>
    <div class="popup-body" id="popup-body"></div>
  </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast">
  <span id="toast-icon">ℹ️</span>
  <span id="toast-msg">—</span>
</div>

<!-- TOOLTIP -->
<div class="tooltip" id="tooltip"></div>

<script>
// ── State ────────────────────────────────────────────────────────────────────
let snap = {}, sbFilter='all', tblFilter='all', alertFilter='all';
let sortCol='queue', sortDir=-1, sbSearch='';
let sparkHistory = {};
let firstLoad = true;

// ── Utils ────────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const fmtIN = n => Number(n).toLocaleString('en-IN');
function sigColor(s){ return s==='green'?'#00ff88':s==='yellow'?'#ffd000':'#ff1a44' }
function loadColor(l){ return l>75?'#ff1a44':l>50?'#ffd000':'#00ff88' }
function weatherIcon(w){
  const m={'Clear':'☀️','Cloudy':'⛅','Rain':'🌧️','Heavy Rain':'⛈️','Fog':'🌫️','Storm':'🌩️','Haze':'😶‍🌫️'};
  return m[w]||'🌡️';
}

// ── Clock ────────────────────────────────────────────────────────────────────
setInterval(()=>{
  const now = new Date();
  $('clock').textContent = now.toLocaleTimeString('en-IN');
},1000);

// ── Panel switching ──────────────────────────────────────────────────────────
function showPanel(name, btn){
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
  $('panel-'+name).classList.add('active');
  if(btn) btn.classList.add('active');
  if(name==='heatmap') renderHeatmap();
  if(name==='analytics') renderAnalytics();
}

// ── Toast ────────────────────────────────────────────────────────────────────
function showToast(msg, icon='🔔'){
  $('toast-msg').textContent = msg;
  $('toast-icon').textContent = icon;
  const t = $('toast');
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 3500);
}

// ── Fetch loop ───────────────────────────────────────────────────────────────
async function fetchData(){
  try{
    const r = await fetch('/api/snapshot');
    snap = await r.json();
    updateKPIs();
    renderSidebar();
    renderDashboard();
    renderCitiesTable();
    renderIncidents();
    renderAlertsLog();
    renderTicker();
    const active = document.querySelector('.panel.active');
    if(active && active.id==='panel-heatmap') renderHeatmap();
    if(active && active.id==='panel-analytics') renderAnalytics();
    if(firstLoad){ firstLoad=false; showToast(`Monitoring ${snap.stats.total_cities} cities across India`,'🇮🇳'); }
    // Peak badge
    const pb = $('peak-badge');
    if(snap.stats.is_peak) pb.classList.add('active'); else pb.classList.remove('active');
  }catch(e){ console.error(e); }
}

// ── KPIs ─────────────────────────────────────────────────────────────────────
function updateKPIs(){
  const s = snap.stats;
  $('k-v').textContent    = fmtIN(s.total_vehicles);
  $('k-c').textContent    = s.total_cities;
  $('k-s').textContent    = s.total_states;
  $('k-i').textContent    = s.incidents;
  $('k-o').textContent    = fmtIN(s.total_optimisations);
  $('k-d').textContent    = fmtIN(s.total_delay_saved);
  $('k-cong').textContent = s.congested;
  $('k-load').textContent = s.avg_load+'%';
}

// ── Ticker ───────────────────────────────────────────────────────────────────
function renderTicker(){
  const alerts = (snap.alerts||[]).slice(0,15);
  const entries = Object.values(snap.data||{}).filter(d=>d.incident).slice(0,8);
  let items = [];
  entries.forEach(e=>{
    items.push(`<span class="tick-item"><span class="tick-dot" style="background:#ff1a44"></span>⚠ INCIDENT: ${e.city}, ${e.state}</span>`);
  });
  alerts.slice(0,8).forEach(a=>{
    const c = a.severity==='HIGH'?'#ff1a44':a.type==='ai'?'#00d4ff':'#00ff88';
    items.push(`<span class="tick-item"><span class="tick-dot" style="background:${c}"></span>${a.msg}</span>`);
  });
  // Duplicate for seamless loop
  const inner = items.join('') + items.join('');
  $('ticker-inner').innerHTML = inner;
}

// ── Sidebar ──────────────────────────────────────────────────────────────────
function setSbFilter(f,btn){ sbFilter=f; document.querySelectorAll('.filt').forEach(b=>b.classList.remove('on')); btn.classList.add('on'); renderSidebar(); }
function filterSidebar(){ sbSearch=$('sb-search').value.toLowerCase(); renderSidebar(); }

function renderSidebar(){
  const ss = snap.state_stats||{};
  const data = snap.data||{};
  let states = Object.entries(ss);
  if(sbSearch) states = states.filter(([s])=>s.toLowerCase().includes(sbSearch));
  if(sbFilter==='incident') states = states.filter(([s,i])=>i.incidents>0);
  if(sbFilter==='high') states = states.filter(([s,i])=>i.avg_load>70);
  if(sbFilter==='clear') states = states.filter(([s,i])=>i.incidents===0&&i.avg_load<=50);
  states.sort((a,b)=>b[1].avg_load-a[1].avg_load);

  $('sidebar-list').innerHTML = states.map(([state,info])=>{
    const lc = loadColor(info.avg_load);
    const hasInc = info.incidents>0;
    const badge = hasInc
      ? `<span class="state-item-badge" style="background:#ff1a4415;color:#ff4466;border:1px solid #ff1a4430">⚠ ${info.incidents}</span>`
      : info.avg_load>70
        ? `<span class="state-item-badge" style="background:#ffd00015;color:#ffd000;border:1px solid #ffd00030">HIGH</span>`
        : `<span class="state-item-badge" style="background:#00ff8815;color:#00ff88;border:1px solid #00ff8830">OK</span>`;

    // Get signal dots for this state
    const citiesInState = Object.values(data).filter(d=>d.state===state);
    const dots = citiesInState.slice(0,8).map(c=>
      `<div class="s-dot" style="background:${sigColor(c.signal)};box-shadow:0 0 4px ${sigColor(c.signal)}60"></div>`
    ).join('');

    return `<div class="state-item" onclick="selectState('${state.replace(/'/g,"\\'")}')">
      <div class="state-item-header">
        <span class="state-item-name">${state}</span>
        ${badge}
      </div>
      <div class="state-item-meta">
        <span class="state-item-cities">${info.cities} cities · ${info.avg_load}% load</span>
      </div>
      <div class="state-signals" style="margin-top:4px">${dots}</div>
      <div class="load-mini"><div class="load-mini-fill" style="width:${info.avg_load}%;background:${lc}"></div></div>
    </div>`;
  }).join('');
}

function selectState(state){
  showToast(`${state} — ${snap.state_stats[state]?.cities} cities selected`, '🗺️');
  // Filter cities table
  tblFilter='all';
  $('tbl-search').value=state;
  showPanel('cities', document.querySelectorAll('.nav-btn')[1]);
  renderCitiesTable();
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
function renderDashboard(){
  const s = snap.stats||{};
  const data = Object.values(snap.data||{});

  // Donut
  const total = s.total_cities||1;
  const gPct = ((s.green_count/total)*100)||0;
  const yPct = ((s.yellow_count/total)*100)||0;
  const rPct = ((s.red_count/total)*100)||0;
  const r=36, circ=2*Math.PI*r;
  let offset=0;
  function arc(pct,color){
    const len=circ*pct/100;
    const d=`<circle cx="40" cy="40" r="${r}" fill="none" stroke="${color}" stroke-width="7"
      stroke-dasharray="${len} ${circ-len}" stroke-dashoffset="${-offset}" stroke-linecap="round"/>`;
    offset+=len;return d;
  }
  $('donut-wrap').innerHTML=`
    <svg class="donut-svg" width="90" height="90" viewBox="0 0 80 80" style="transform:rotate(-90deg)">
      <circle cx="40" cy="40" r="${r}" fill="none" stroke="#0d1828" stroke-width="7"/>
      ${arc(gPct,'#00ff88')}${arc(yPct,'#ffd000')}${arc(rPct,'#ff1a44')}
    </svg>
    <div class="donut-legend">
      <div class="legend-item"><div class="legend-dot" style="background:#00ff88"></div>Green: <b style="color:#00ff88;margin-left:4px">${s.green_count||0}</b></div>
      <div class="legend-item"><div class="legend-dot" style="background:#ffd000"></div>Yellow: <b style="color:#ffd000;margin-left:4px">${s.yellow_count||0}</b></div>
      <div class="legend-item"><div class="legend-dot" style="background:#ff1a44"></div>Red: <b style="color:#ff1a44;margin-left:4px">${s.red_count||0}</b></div>
    </div>`;

  $('sig-stats').innerHTML=`
    <div style="margin-bottom:8px">
      <div style="display:flex;justify-content:space-between;font-size:10px;margin-bottom:3px">
        <span style="color:var(--text2)">Green Flow</span>
        <span style="color:#00ff88;font-family:'Share Tech Mono',monospace">${gPct.toFixed(1)}%</span>
      </div>
      <div style="height:4px;background:#0d1828;border-radius:2px;overflow:hidden">
        <div style="width:${gPct}%;height:100%;background:#00ff88;border-radius:2px"></div></div>
    </div>
    <div>
      <div style="font-size:9px;color:var(--text2);letter-spacing:.1em;margin-bottom:2px">NETWORK STATUS</div>
      <div style="font-size:11px;color:${s.avg_load>75?'#ff1a44':s.avg_load>50?'#ffd000':'#00ff88'}">
        ${s.avg_load>75?'⚠ HEAVY CONGESTION':s.avg_load>50?'⚡ MODERATE LOAD':'✓ FLOWING SMOOTHLY'}</div>
    </div>`;

  // Efficiency arc
  const eff = Math.max(0, Math.min(99.9, 100 - s.avg_load));
  const circ2 = 2*Math.PI*32;
  const offset2 = circ2*(1-eff/100);
  const ec = eff>70?'#00ff88':eff>40?'#ffd000':'#ff1a44';
  $('arc-circle').style.strokeDashoffset = offset2;
  $('arc-circle').style.stroke = ec;
  $('arc-val').textContent = eff.toFixed(0)+'%';
  $('arc-val').style.color = ec;

  // Health bars
  $('health-bars').innerHTML = [
    ['Signal Prediction','97','#00d4ff'],
    ['Flow Optimisation',Math.round(eff).toString(),'#00ff88'],
    ['Incident Detection','99','#ff6b00'],
  ].map(([l,v,c])=>`
    <div style="margin-bottom:7px">
      <div style="display:flex;justify-content:space-between;font-size:9px;margin-bottom:3px">
        <span style="color:var(--text2)">${l}</span>
        <span style="color:${c};font-family:'Share Tech Mono',monospace">${v}%</span>
      </div>
      <div style="height:3px;background:#0d1828;border-radius:2px;overflow:hidden">
        <div style="width:${v}%;height:100%;background:${c};border-radius:2px;
          box-shadow:0 0 6px ${c}60"></div></div>
    </div>`).join('');

  // AI engine
  $('ai-engine-panel').innerHTML=`
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
      ${[
        ['TOTAL OPTS',fmtIN(s.total_optimisations),'#9b59ff'],
        ['DELAY SAVED',fmtIN(s.total_delay_saved)+'s','#ffc840'],
        ['CONGESTED',s.congested,'#ffd000'],
        ['INCIDENTS',s.incidents,'#ff1a44'],
      ].map(([l,v,c])=>`
        <div style="background:var(--bg3);border-radius:8px;padding:10px;border:1px solid var(--border)">
          <div style="font-size:8px;letter-spacing:.14em;color:var(--text2);margin-bottom:4px">${l}</div>
          <div style="font-family:'Orbitron',monospace;font-size:18px;font-weight:700;color:${c}">${v}</div>
        </div>`).join('')}
    </div>
    ${s.is_peak?`<div style="padding:8px 10px;background:#ff6b0010;border:1px solid #ff6b0030;
      border-radius:8px;font-size:10px;color:var(--orange)">⚡ PEAK HOURS ACTIVE — Enhanced AI monitoring</div>`
      :`<div style="padding:8px 10px;background:#00ff8808;border:1px solid #00ff8820;
        border-radius:8px;font-size:10px;color:#00ff8888">✓ Off-peak — Normal AI mode</div>`}`;

  // Top congested
  const top8 = [...data].sort((a,b)=>b.queue-a.queue).slice(0,8);
  const maxQ = top8[0]?.queue||1;
  $('top-congested').innerHTML=`<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
    ${top8.map(c=>{
      const lc=loadColor(c.load);
      const w=Math.round(c.queue/maxQ*100);
      return `<div style="cursor:pointer" onclick="openCityPopup('${c.city}|${c.state}')">
        <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
          <span style="font-weight:600">${c.city} <span style="color:var(--text2);font-size:9px">${c.state.slice(0,10)}</span></span>
          <span style="color:${lc};font-family:'Share Tech Mono',monospace">${c.queue}</span>
        </div>
        <div style="height:5px;background:#0d1828;border-radius:3px;overflow:hidden">
          <div style="width:${w}%;height:100%;background:${lc};border-radius:3px;
            box-shadow:0 0 8px ${lc}50;transition:width .8s"></div></div>
      </div>`;}).join('')}
  </div>`;

  // Dashboard alerts
  const alerts = (snap.alerts||[]).slice(0,12);
  $('dash-alerts').innerHTML = renderAlertItems(alerts);
  $('alert-count').textContent = alerts.length;

  // State rank
  const ranks = Object.entries(snap.state_stats||{}).sort((a,b)=>b[1].avg_load-a[1].avg_load).slice(0,10);
  const maxL = ranks[0]?.[1]?.avg_load||1;
  $('state-rank').innerHTML=`<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">
    ${ranks.map(([s,info])=>{
      const lc=loadColor(info.avg_load);
      const w=Math.round(info.avg_load/maxL*100);
      return `<div class="bar-row">
        <div class="bar-label">${s.length>14?s.slice(0,13)+'…':s}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${w}%;background:${lc}"></div></div>
        <div class="bar-val" style="color:${lc}">${info.avg_load}%</div>
      </div>`;}).join('')}
  </div>`;
}

// ── Cities table ──────────────────────────────────────────────────────────────
function setTblFilter(f,btn){ tblFilter=f; document.querySelectorAll('.tbl-filt').forEach(b=>b.classList.remove('on')); btn.classList.add('on'); renderCitiesTable(); }
function sortTable(col){ if(sortCol===col) sortDir*=-1; else{sortCol=col;sortDir=-1;} renderCitiesTable(); }

function renderCitiesTable(){
  let entries = Object.entries(snap.data||{});
  const q = ($('tbl-search').value||'').toLowerCase();
  if(q) entries=entries.filter(([k,d])=>d.city.toLowerCase().includes(q)||d.state.toLowerCase().includes(q));
  if(tblFilter==='red') entries=entries.filter(([,d])=>d.signal==='red');
  if(tblFilter==='yellow') entries=entries.filter(([,d])=>d.signal==='yellow');
  if(tblFilter==='green') entries=entries.filter(([,d])=>d.signal==='green');
  if(tblFilter==='incident') entries=entries.filter(([,d])=>d.incident);
  if(tblFilter==='congested') entries=entries.filter(([,d])=>d.queue>20);
  if(tblFilter==='metro') entries=entries.filter(([,d])=>d.is_metro);
  entries.sort((a,b)=>{
    const va=a[1][sortCol]||0, vb=b[1][sortCol]||0;
    return typeof va==='string'?va.localeCompare(vb)*sortDir:(vb-va)*sortDir;
  });
  $('tbl-count').textContent = entries.length+' cities';
  $('cities-tbody').innerHTML = entries.map(([key,c])=>{
    const lc=loadColor(c.load);
    const sc=sigColor(c.signal);
    const stat=c.incident?`<span style="color:#ff1a44;font-size:9px;font-weight:700">⚠ INCIDENT</span>`
      :c.queue>20?`<span style="color:#ffd000;font-size:9px">CONGESTED</span>`
      :`<span style="color:#00ff8880;font-size:9px">NORMAL</span>`;
    return `<tr class="${c.incident?'inc-row':''}" onclick="openCityPopup('${key}')" style="cursor:pointer">
      <td><span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-family:'Share Tech Mono',monospace;
        padding:2px 7px;border-radius:8px;background:${sc}18;color:${sc};border:1px solid ${sc}40">
        ● ${c.signal.toUpperCase()}</span></td>
      <td style="font-weight:700;color:${c.incident?'#ff4466':'var(--white)'}">
        ${c.incident?'⚠ ':''}${c.city}${c.is_metro?'<span style="font-size:8px;color:#ffc840;margin-left:4px">★</span>':''}</td>
      <td style="color:var(--text2);font-size:11px">${c.state}</td>
      <td style="font-family:'Share Tech Mono',monospace;color:${lc};font-weight:700">${c.queue}</td>
      <td>
        <div style="display:flex;align-items:center;gap:6px">
          <div style="width:50px;height:4px;background:#0d1828;border-radius:2px;overflow:hidden">
            <div style="width:${c.load}%;height:100%;background:${lc};border-radius:2px"></div></div>
          <span style="font-size:10px;color:${lc};font-family:'Share Tech Mono',monospace">${c.load}%</span>
        </div>
      </td>
      <td style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--text2)">${c.timer}s</td>
      <td>${weatherIcon(c.weather)} <span style="font-size:10px;color:var(--text2)">${c.weather}</span></td>
      <td style="font-family:'Share Tech Mono',monospace;font-size:11px;color:#9b59ff">${c.optimisations}</td>
      <td>${stat}</td>
    </tr>`;
  }).join('');
}

// ── Heatmap ───────────────────────────────────────────────────────────────────
function renderHeatmap(){
  const data = Object.entries(snap.data||{});
  $('heatmap-grid').innerHTML = data.map(([key,c])=>{
    const l=c.load;
    const r=Math.round(l>50?(l-50)/50*255:0);
    const g=Math.round(l<50?255:(100-l)/50*255);
    const bg=`rgba(${r},${g},0,0.6)`;
    const bc=`rgba(${r},${g},0,0.3)`;
    return `<div class="hm-cell" style="background:${bg};border:1px solid ${bc}"
      onclick="openCityPopup('${key}')"
      onmouseenter="showTip(event,'${c.city}, ${c.state} — Load: ${c.load}% | Queue: ${c.queue}')"
      onmouseleave="hideTip()">
      <div class="hm-city">${c.city}</div>
      <div class="hm-load" style="color:rgba(255,255,255,0.8)">${c.load}%</div>
    </div>`;
  }).join('');
}

// ── Analytics ─────────────────────────────────────────────────────────────────
function renderAnalytics(){
  const data = Object.values(snap.data||{});
  const ss = snap.state_stats||{};
  const s = snap.stats||{};
  const top12 = [...data].sort((a,b)=>b.queue-a.queue).slice(0,12);
  const maxQ = top12[0]?.queue||1;
  const stateRanks = Object.entries(ss).sort((a,b)=>b[1].avg_load-a[1].avg_load).slice(0,12);
  const maxL = stateRanks[0]?.[1]?.avg_load||1;
  const metro = data.filter(d=>d.is_metro);
  const tier2 = data.filter(d=>!d.is_metro);
  const metroAvg = metro.reduce((a,b)=>a+b.load,0)/Math.max(1,metro.length);
  const tier2Avg = tier2.reduce((a,b)=>a+b.load,0)/Math.max(1,tier2.length);
  const eff = Math.max(0,Math.min(99.9,100-s.avg_load));

  $('analytics-content').innerHTML=`
    <!-- Top congested -->
    <div class="card" style="grid-column:1/-1">
      <div class="card-head"><span class="card-title">TOP 12 CONGESTED CITIES — LIVE</span></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
          ${top12.map(c=>{
            const lc=loadColor(c.load);const w=Math.round(c.queue/maxQ*100);
            return `<div class="bar-row" style="cursor:pointer" onclick="openCityPopup('${c.city}|${c.state}')">
              <div class="bar-label" title="${c.state}">${c.city}</div>
              <div class="bar-track"><div class="bar-fill" style="width:${w}%;background:${lc};box-shadow:0 0 6px ${lc}50"></div></div>
              <div class="bar-val" style="color:${lc}">${c.queue}</div>
            </div>`;}).join('')}
        </div>
      </div>
    </div>

    <!-- State load -->
    <div class="card">
      <div class="card-head"><span class="card-title">STATE LOAD RANKING</span></div>
      <div class="card-body" style="max-height:240px;overflow-y:auto">
        ${stateRanks.map(([s,info])=>{
          const lc=loadColor(info.avg_load);const w=Math.round(info.avg_load/maxL*100);
          return `<div class="bar-row">
            <div class="bar-label">${s.length>14?s.slice(0,13)+'…':s}</div>
            <div class="bar-track"><div class="bar-fill" style="width:${w}%;background:${lc}"></div></div>
            <div class="bar-val" style="color:${lc}">${info.avg_load}%</div>
          </div>`;}).join('')}
      </div>
    </div>

    <!-- City tier -->
    <div class="card">
      <div class="card-head"><span class="card-title">CITY TIER ANALYSIS</span></div>
      <div class="card-body">
        ${[['METRO CITIES',metro.length,metroAvg.toFixed(1)+'%','#ff6b00'],
           ['TIER-2 & OTHERS',tier2.length,tier2Avg.toFixed(1)+'%','#00d4ff']].map(([l,n,v,c])=>`
          <div style="background:var(--bg3);border-radius:10px;padding:14px;margin-bottom:10px;border:1px solid var(--border)">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
              <div>
                <div style="font-size:10px;color:var(--text2);letter-spacing:.1em">${l}</div>
                <div style="font-size:10px;color:${c};margin-top:2px">${n} cities</div>
              </div>
              <div style="font-family:'Orbitron',monospace;font-size:28px;font-weight:700;color:${c}">${v}</div>
            </div>
            <div style="height:5px;background:#0d1828;border-radius:3px;overflow:hidden">
              <div style="width:${parseFloat(v)}%;height:100%;background:${c};border-radius:3px"></div></div>
          </div>`).join('')}
      </div>
    </div>

    <!-- Signal dist pie -->
    <div class="card">
      <div class="card-head"><span class="card-title">SIGNAL DISTRIBUTION</span></div>
      <div class="card-body">
        ${[['🟢 GREEN',s.green_count,'#00ff88'],[' 🟡 YELLOW',s.yellow_count,'#ffd000'],['🔴 RED',s.red_count,'#ff1a44']].map(([l,v,c])=>`
          <div style="margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
              <span style="color:${c}">${l}</span>
              <span style="font-family:'Share Tech Mono',monospace;color:${c}">${v} (${Math.round(v/s.total_cities*100)}%)</span>
            </div>
            <div style="height:8px;background:#0d1828;border-radius:4px;overflow:hidden">
              <div style="width:${Math.round(v/s.total_cities*100)}%;height:100%;background:${c};
                border-radius:4px;box-shadow:0 0 8px ${c}40"></div></div>
          </div>`).join('')}
        <div style="padding:10px;background:var(--bg3);border-radius:8px;margin-top:10px;text-align:center">
          <div style="font-size:9px;color:var(--text2)">NETWORK EFFICIENCY</div>
          <div style="font-family:'Orbitron',monospace;font-size:28px;color:${eff>70?'#00ff88':eff>40?'#ffd000':'#ff1a44'}">${eff.toFixed(1)}%</div>
        </div>
      </div>
    </div>

    <!-- Weather impact -->
    <div class="card">
      <div class="card-head"><span class="card-title">WEATHER IMPACT</span></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">
          ${['Clear','Rain','Heavy Rain','Fog','Storm','Haze'].map(w=>{
            const cities=data.filter(d=>d.weather===w);
            if(!cities.length) return '';
            const avgL=Math.round(cities.reduce((a,b)=>a+b.load,0)/cities.length);
            const lc=loadColor(avgL);
            return `<div style="background:var(--bg3);border-radius:8px;padding:8px;text-align:center;border:1px solid var(--border)">
              <div style="font-size:18px;margin-bottom:3px">${weatherIcon(w)}</div>
              <div style="font-size:9px;color:var(--text2);margin-bottom:3px">${w}</div>
              <div style="font-family:'Orbitron',monospace;font-size:15px;color:${lc}">${avgL}%</div>
              <div style="font-size:8px;color:var(--text2)">${cities.length} cities</div>
            </div>`;}).join('')}
        </div>
      </div>
    </div>
  `;
}

// ── Incidents ─────────────────────────────────────────────────────────────────
function renderIncidents(){
  const incs = Object.entries(snap.data||{}).filter(([,d])=>d.incident);
  $('inc-count').textContent = incs.length + ' active';
  if(!incs.length){
    $('incident-list').innerHTML=`<div style="grid-column:1/-1;padding:40px;text-align:center;color:var(--text2)">
      <div style="font-size:40px;margin-bottom:12px">✅</div>
      <div style="font-family:'Orbitron',monospace;font-size:16px">ALL CLEAR</div>
      <div style="font-size:11px;margin-top:6px">No active incidents across India</div>
    </div>`;
    return;
  }
  $('incident-list').innerHTML = incs.map(([key,c])=>`
    <div class="inc-card" onclick="openCityPopup('${key}')" style="cursor:pointer">
      <div><span class="inc-pulse"></span>
        <span style="font-size:9px;font-family:'Share Tech Mono',monospace;color:#ff4466">ACTIVE INCIDENT</span>
      </div>
      <div class="inc-city" style="margin-top:6px">${c.city}</div>
      <div class="inc-state">${c.state}</div>
      <div class="inc-detail">
        <div class="inc-stat"><div class="inc-stat-l">QUEUE</div><div class="inc-stat-v">${c.queue}</div></div>
        <div class="inc-stat"><div class="inc-stat-l">LOAD</div><div class="inc-stat-v">${c.load}%</div></div>
        <div class="inc-stat"><div class="inc-stat-l">SIGNAL</div>
          <div style="font-family:'Orbitron',monospace;font-size:13px;color:${sigColor(c.signal)};margin-top:2px">
            ${c.signal.toUpperCase()}</div></div>
        <div class="inc-stat"><div class="inc-stat-l">WEATHER</div>
          <div style="font-size:16px;margin-top:2px">${weatherIcon(c.weather)}</div></div>
      </div>
      ${c.reroute?`<div class="reroute-badge">🔀 ${c.reroute}</div>`:''}
    </div>`).join('');
}

// ── Alerts log ────────────────────────────────────────────────────────────────
function setAlertFilter(f,btn){ alertFilter=f; document.querySelectorAll('#panel-alerts .tbl-filt').forEach(b=>b.classList.remove('on')); btn.classList.add('on'); renderAlertsLog(); }

function renderAlertItems(alerts){
  return alerts.map(a=>{
    const c=a.severity==='HIGH'?'#ff1a44':a.type==='ai'?'#00d4ff':a.type==='clear'?'#00ff88':'#7090b0';
    const bg=a.severity==='HIGH'?'#12040a':'';
    return `<div class="a-item" style="background:${bg}">
      <div class="a-dot" style="background:${c};box-shadow:0 0 6px ${c}80"></div>
      <div class="a-content">
        <div class="a-msg" style="color:${c}">${a.msg}</div>
        <div class="a-time">${a.time} · ${a.state||''}</div>
      </div>
      <span class="a-badge" style="background:${c}18;color:${c};border:1px solid ${c}30">${a.severity}</span>
    </div>`;}).join('');
}

function renderAlertsLog(){
  let alerts = snap.alerts||[];
  if(alertFilter!=='all') alerts=alerts.filter(a=>a.severity===alertFilter||(alertFilter==='AI'&&a.type==='ai'));
  $('alerts-log').innerHTML = renderAlertItems(alerts);
}

// ── City popup ────────────────────────────────────────────────────────────────
function openCityPopup(key){
  const c = snap.data?.[key]; if(!c) return;
  $('popup-city').textContent=c.city+(c.is_metro?' ★':'');
  $('popup-state').textContent=c.state+' · '+weatherIcon(c.weather)+' '+c.weather;
  const lc=loadColor(c.load);const sc=sigColor(c.signal);
  $('popup-body').innerHTML=`
    <div class="popup-stat">
      <div class="popup-stat-label">SIGNAL</div>
      <div class="popup-stat-val" style="color:${sc}">${c.signal.toUpperCase()}</div>
    </div>
    <div class="popup-stat">
      <div class="popup-stat-label">TIMER</div>
      <div class="popup-stat-val" style="color:var(--cyan)">${c.timer}s</div>
    </div>
    <div class="popup-stat">
      <div class="popup-stat-label">QUEUE</div>
      <div class="popup-stat-val" style="color:${lc}">${c.queue} veh</div>
    </div>
    <div class="popup-stat">
      <div class="popup-stat-label">LOAD</div>
      <div class="popup-stat-val" style="color:${lc}">${c.load}%</div>
    </div>
    <div class="popup-stat">
      <div class="popup-stat-label">GREEN DURATION</div>
      <div class="popup-stat-val" style="color:#00ff88">${c.green_duration}s</div>
    </div>
    <div class="popup-stat">
      <div class="popup-stat-label">AI OPTIMISATIONS</div>
      <div class="popup-stat-val" style="color:#9b59ff">${c.optimisations}</div>
    </div>
    <div class="popup-stat" style="grid-column:1/-1">
      <div class="popup-stat-label">STATUS</div>
      <div style="font-size:13px;color:${c.incident?'#ff1a44':c.queue>20?'#ffd000':'#00ff88'};margin-top:4px;font-weight:700">
        ${c.incident?'⚠ INCIDENT ACTIVE':c.queue>20?'⚡ CONGESTED':'✓ NORMAL FLOW'}
      </div>
      ${c.reroute?`<div style="margin-top:8px;padding:8px;background:#0a0205;border-radius:6px;
        font-size:10px;color:#ff6680;border:1px solid #ff1a4420">🔀 ${c.reroute}</div>`:''}
    </div>
    <div style="grid-column:1/-1;background:var(--bg3);border-radius:8px;padding:12px;border:1px solid var(--border)">
      <div style="font-size:9px;color:var(--text2);letter-spacing:.12em;margin-bottom:8px">QUEUE HISTORY (LAST 10)</div>
      <div style="display:flex;align-items:flex-end;gap:3px;height:40px">
        ${(c.history||[]).map(v=>{
          const h=Math.max(4,Math.round(v/50*40));const lc2=loadColor(Math.min(99,v*3));
          return `<div style="flex:1;height:${h}px;background:${lc2};border-radius:2px;opacity:.8;min-width:4px"></div>`;
        }).join('')}
      </div>
    </div>`;
  $('city-popup').classList.add('open');
}

function closePopup(e){
  if(!e||e.target===$('city-popup')) $('city-popup').classList.remove('open');
}
document.addEventListener('keydown',e=>{ if(e.key==='Escape') $('city-popup').classList.remove('open'); });

// ── Tooltip ───────────────────────────────────────────────────────────────────
function showTip(e,msg){
  const t=$('tooltip');
  t.textContent=msg;t.classList.add('show');
  t.style.left=(e.clientX+12)+'px';t.style.top=(e.clientY-28)+'px';
}
function hideTip(){ $('tooltip').classList.remove('show'); }

// ── Init ──────────────────────────────────────────────────────────────────────
fetchData();
setInterval(fetchData, 2000);
</script>
</body>
</html>"""

if __name__ == "__main__":
    print("\n" + "═"*62)
    print("  🇮🇳  BHARAT TRAFFIC AI v3.0")
    print("  GUI  →  http://localhost:5000")
    print("  Ctrl+C to stop")
    print("═"*62 + "\n")
    app.run(debug=False, port=5000, threaded=True)
    # Change this:
app.run(debug=False, port=5000, threaded=True)

# To this (quiet mode):
import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)
app.run(debug=False, port=5000, threaded=True)
