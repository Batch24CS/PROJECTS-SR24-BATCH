package com.example.studentsubmission.repository;

import com.example.studentsubmission.entity.Subject;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubjectRepository extends JpaRepository<Subject, Long> {
}
