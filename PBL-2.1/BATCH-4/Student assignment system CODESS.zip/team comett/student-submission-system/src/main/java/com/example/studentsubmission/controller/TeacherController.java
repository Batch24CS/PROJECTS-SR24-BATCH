package com.example.studentsubmission.controller;

import com.example.studentsubmission.entity.Submission;
import com.example.studentsubmission.entity.User;
import com.example.studentsubmission.repository.SubjectRepository;
import com.example.studentsubmission.repository.SubmissionRepository;
import com.example.studentsubmission.service.AnalyticsService;
import com.example.studentsubmission.service.ExcelService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.InputStreamResource;
import java.io.ByteArrayInputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.HashMap;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    private final SubmissionRepository submissionRepository;
    private final SubjectRepository subjectRepository;
    private final ExcelService excelService;
    private final AnalyticsService analyticsService;
    private final com.example.studentsubmission.repository.AnnouncementRepository announcementRepository;
    private final com.example.studentsubmission.repository.AssignmentRepository assignmentRepository;

    public TeacherController(SubmissionRepository submissionRepository, SubjectRepository subjectRepository,
            ExcelService excelService, AnalyticsService analyticsService,
            com.example.studentsubmission.repository.AnnouncementRepository announcementRepository,
            com.example.studentsubmission.repository.AssignmentRepository assignmentRepository) {
        this.submissionRepository = submissionRepository;
        this.subjectRepository = subjectRepository;
        this.excelService = excelService;
        this.analyticsService = analyticsService;
        this.announcementRepository = announcementRepository;
        this.assignmentRepository = assignmentRepository;
    }

    @PostMapping("/announce")
    public String postAnnouncement(@RequestParam String message) {
        if (message != null && !message.trim().isEmpty()) {
            announcementRepository.save(new com.example.studentsubmission.entity.Announcement(message));
        }
        return "redirect:/teacher/dashboard";
    }

    @GetMapping("/delete-announcement/{id}")
    public String deleteAnnouncement(@PathVariable Long id) {
        announcementRepository.deleteById(id);
        return "redirect:/teacher/dashboard";
    }

    @PostMapping("/create-assignment")
    public String createAssignment(@RequestParam String title, @RequestParam String description,
            @RequestParam String dueDate, @RequestParam Long subjectId) {
        com.example.studentsubmission.entity.Subject subject = subjectRepository.findById(subjectId).orElse(null);
        if (subject != null) {
            com.example.studentsubmission.entity.Assignment assignment = new com.example.studentsubmission.entity.Assignment(
                    title, description, java.time.LocalDate.parse(dueDate), subject);
            assignmentRepository.save(assignment);
        }
        return "redirect:/teacher/dashboard";
    }

    @GetMapping("/delete-assignment/{id}")
    public String deleteAssignment(@PathVariable Long id) {
        assignmentRepository.deleteById(id);
        return "redirect:/teacher/dashboard";
    }

    @GetMapping("/analytics")
    @ResponseBody
    public ResponseEntity<String> analytics() {
        try {
            List<Submission> submissions = submissionRepository.findAll();

            List<Integer> marks = submissions.stream()
                    .filter(s -> s.getMarks() != null)
                    .map(Submission::getMarks)
                    .collect(java.util.stream.Collectors.toList());

            double mean = 0, median = 0, sd = 0;
            java.util.List<Integer> buckets = new java.util.ArrayList<>();
            for (int i = 0; i < 10; i++)
                buckets.add(0);

            if (!marks.isEmpty()) {
                final double computedMean = marks.stream().mapToDouble(Integer::doubleValue).average().orElse(0.0);
                mean = computedMean;
                java.util.List<Integer> sorted = new java.util.ArrayList<>(marks);
                java.util.Collections.sort(sorted);
                int n = sorted.size();
                if (n % 2 == 1)
                    median = sorted.get(n / 2);
                else
                    median = (sorted.get(n / 2 - 1) + sorted.get(n / 2)) / 2.0;
                double variance = marks.stream().mapToDouble(m -> Math.pow(m - computedMean, 2)).sum() / n;
                sd = Math.sqrt(variance);

                // buckets
                for (Integer m : marks) {
                    int idx = Math.min(9, Math.max(0, m / 10));
                    buckets.set(idx, buckets.get(idx) + 1);
                }
            }

            Map<String, Object> resp = new HashMap<>();
            resp.put("marks", marks);
            resp.put("mean", mean);
            resp.put("median", median);
            resp.put("sd", sd);
            resp.put("buckets", buckets);

            String json = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(resp);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; charset=UTF-8")
                    .body(json);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500)
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; charset=UTF-8")
                    .body("{\"error\":\"internal\"}");
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"TEACHER".equals(user.getRole())) {
            return "redirect:/login";
        }
        List<Submission> allSubmissions = submissionRepository.findAll();
        model.addAttribute("submissions", allSubmissions);
        model.addAttribute("subjects", subjectRepository.findAll());

        // DS: Get Top 3 Performers
        model.addAttribute("topPerformers", analyticsService.getTopPerformers(allSubmissions, 3));
        model.addAttribute("announcements", announcementRepository.findAllByOrderByCreatedAtDesc());
        model.addAttribute("assignments", assignmentRepository.findAllByOrderByDueDateAsc());

        return "teacher_dashboard";
    }

    @PostMapping("/grade/{id}")
    public String gradeSubmission(@PathVariable Long id, @RequestParam Integer marks,
            @RequestParam(required = false) String feedback) {
        Submission submission = submissionRepository.findById(id).orElseThrow();
        submission.setMarks(marks);
        submission.setFeedback(feedback);
        submissionRepository.save(submission);
        return "redirect:/teacher/dashboard";
    }

    @GetMapping("/download")
    public ResponseEntity<InputStreamResource> downloadExcel() {
        List<Submission> submissions = submissionRepository.findAll();
        ByteArrayInputStream in = excelService.submissionsToExcel(submissions);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=submissions.xlsx");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(new InputStreamResource(in));
    }

    @GetMapping("/files/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
        try {
            Path file = Paths.get("uploads").resolve(filename).normalize();
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                // Try to detect content type
                String contentType = null;
                try {
                    contentType = java.nio.file.Files.probeContentType(file);
                } catch (Exception ex) {
                    // ignore and fallback
                }
                if (contentType == null) {
                    contentType = "application/octet-stream";
                }

                // Use inline disposition so the browser can render PDFs/images in iframe
                return ResponseEntity.ok()
                        .contentType(org.springframework.http.MediaType.parseMediaType(contentType))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "inline; filename=\"" + resource.getFilename() + "\"")
                        .body(resource);
            } else {
                throw new RuntimeException("Could not read file: " + filename);
            }
        } catch (Exception e) {
            throw new RuntimeException("Could not read file: " + filename, e);
        }
    }

    @ExceptionHandler(Exception.class)
    public String handleException(Exception e) {
        try {
            java.io.PrintWriter pw = new java.io.PrintWriter("error_log.txt");
            e.printStackTrace(pw);
            pw.close();
        } catch (Exception ex) {
        }
        return "error";
    }
}
