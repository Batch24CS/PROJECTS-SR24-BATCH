package com.example.studentsubmission.service;

import com.example.studentsubmission.entity.Submission;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ExcelService {

    public ByteArrayInputStream submissionsToExcel(List<Submission> submissions) {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Submissions");

            // Header
            String[] columns = { "ID", "Student Name", "Team Members", "Subject", "Assignment", "PPT", "PBL", "Marks" };
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < columns.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
            }

            // Data
            int rowIdx = 1;
            for (Submission submission : submissions) {
                Row row = sheet.createRow(rowIdx++);

                row.createCell(0).setCellValue(submission.getId());
                row.createCell(1).setCellValue(submission.getStudentName());
                row.createCell(2).setCellValue(submission.getTeamMembers());
                row.createCell(3).setCellValue(submission.getSubject().getName());
                row.createCell(4).setCellValue(submission.getAssignmentPath());
                row.createCell(5).setCellValue(submission.getPptPath());
                row.createCell(6).setCellValue(submission.getPblPath());
                if (submission.getMarks() != null) {
                    row.createCell(7).setCellValue(submission.getMarks());
                } else {
                    row.createCell(7).setCellValue("N/A");
                }
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
        }
    }
}
