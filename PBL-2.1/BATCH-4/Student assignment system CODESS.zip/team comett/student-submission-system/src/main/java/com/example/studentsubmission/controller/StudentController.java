package com.example.studentsubmission.controller;

import com.example.studentsubmission.entity.Subject;
import com.example.studentsubmission.entity.Submission;
import com.example.studentsubmission.entity.User;
import com.example.studentsubmission.repository.SubjectRepository;
import com.example.studentsubmission.repository.SubmissionRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Controller
@RequestMapping("/student")
public class StudentController {

    private final SubmissionRepository submissionRepository;
    private final SubjectRepository subjectRepository;
    private final com.example.studentsubmission.repository.AnnouncementRepository announcementRepository;
    private final com.example.studentsubmission.repository.AssignmentRepository assignmentRepository;
    private final String UPLOAD_DIR = "uploads/";

    public StudentController(SubmissionRepository submissionRepository, SubjectRepository subjectRepository,
            com.example.studentsubmission.repository.AnnouncementRepository announcementRepository,
            com.example.studentsubmission.repository.AssignmentRepository assignmentRepository) {
        this.submissionRepository = submissionRepository;
        this.subjectRepository = subjectRepository;
        this.announcementRepository = announcementRepository;
        this.assignmentRepository = assignmentRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"STUDENT".equals(user.getRole())) {
            return "redirect:/login";
        }
        model.addAttribute("subjects", subjectRepository.findAll());
        model.addAttribute("announcements", announcementRepository.findAllByOrderByCreatedAtDesc());
        model.addAttribute("assignments", assignmentRepository.findAllByOrderByDueDateAsc());
        return "student_dashboard";
    }

    @PostMapping("/upload")
    public String uploadSubmission(@RequestParam(value = "subjectId", required = false) Long subjectId,
            @RequestParam(value = "assignmentId", required = false) Long assignmentId,
            @RequestParam("studentNameInput") String studentNameInput,
            @RequestParam(value = "assignmentFile", required = false) MultipartFile assignmentFile,
            @RequestParam(value = "pptFile", required = false) MultipartFile pptFile,
            @RequestParam(value = "pblFile", required = false) MultipartFile pblFile,
            HttpSession session) throws IOException {

        User user = (User) session.getAttribute("user");
        if (user == null)
            return "redirect:/login";

        Submission submission = new Submission();
        submission.setStudentName(user.getUsername());
        submission.setTeamMembers(studentNameInput);

        // Handle Assignment or Subject
        if (assignmentId != null) {
            com.example.studentsubmission.entity.Assignment assignment = assignmentRepository.findById(assignmentId)
                    .orElse(null);
            if (assignment != null) {
                submission.setAssignment(assignment);
                submission.setSubject(assignment.getSubject());
            }
        } else if (subjectId != null) {
            Subject subject = subjectRepository.findById(subjectId).orElse(null);
            if (subject != null) {
                submission.setSubject(subject);
            }
        }

        // Save files
        Path uploadPath = Paths.get(UPLOAD_DIR);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        if (assignmentFile != null && !assignmentFile.isEmpty()) {
            String assignmentName = UUID.randomUUID() + "_" + assignmentFile.getOriginalFilename();
            Files.copy(assignmentFile.getInputStream(), uploadPath.resolve(assignmentName));
            submission.setAssignmentPath(assignmentName);
        }

        if (pptFile != null && !pptFile.isEmpty()) {
            String pptName = UUID.randomUUID() + "_" + pptFile.getOriginalFilename();
            Files.copy(pptFile.getInputStream(), uploadPath.resolve(pptName));
            submission.setPptPath(pptName);
        }

        if (pblFile != null && !pblFile.isEmpty()) {
            String pblName = UUID.randomUUID() + "_" + pblFile.getOriginalFilename();
            Files.copy(pblFile.getInputStream(), uploadPath.resolve(pblName));
            submission.setPblPath(pblName);
        }

        submissionRepository.save(submission);

        return "redirect:/student/dashboard?success";
    }
}
