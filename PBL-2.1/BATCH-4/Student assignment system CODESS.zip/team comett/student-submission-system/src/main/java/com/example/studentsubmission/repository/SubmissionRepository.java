package com.example.studentsubmission.repository;

import com.example.studentsubmission.entity.Submission;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    List<Submission> findBySubjectId(Long subjectId);
}
