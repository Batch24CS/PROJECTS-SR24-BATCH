package com.example.studentsubmission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSubmissionApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentSubmissionApplication.class, args);
	}

}
