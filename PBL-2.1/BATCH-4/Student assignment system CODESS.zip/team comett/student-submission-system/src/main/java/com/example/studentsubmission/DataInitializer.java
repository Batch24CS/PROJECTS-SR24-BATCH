package com.example.studentsubmission;

import com.example.studentsubmission.entity.Subject;
import com.example.studentsubmission.entity.User;
import com.example.studentsubmission.repository.SubjectRepository;
import com.example.studentsubmission.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final SubjectRepository subjectRepository;

    public DataInitializer(UserRepository userRepository, SubjectRepository subjectRepository) {
        this.userRepository = userRepository;
        this.subjectRepository = subjectRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            // Teacher
            userRepository.save(new User("admin", "admin123", "TEACHER"));

            // Students 201-270
            for (int i = 201; i <= 270; i++) {
                userRepository.save(new User(String.valueOf(i), "sphn123", "STUDENT"));
            }
        }

        if (subjectRepository.count() == 0) {
            subjectRepository.save(new Subject("Data Structures"));
            subjectRepository.save(new Subject("R Programming"));
            subjectRepository.save(new Subject("Java"));
            subjectRepository.save(new Subject("COA"));
            subjectRepository.save(new Subject("COSM"));
        }
    }
}
