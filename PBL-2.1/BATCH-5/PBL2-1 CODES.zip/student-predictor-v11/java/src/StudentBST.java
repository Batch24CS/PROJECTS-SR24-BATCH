
public class StudentBST {
    private static class Node {
        String key;
        Student student;
        Node left, right;
        Node(String k, Student s) { key = k; student = s; }
    }
    private Node root;
    public void insert(String key, Student s) { root = insertRec(root, key, s); }
    private Node insertRec(Node node, String key, Student s) {
        if (node == null) return new Node(key, s);
        if (key.compareTo(node.key) < 0) node.left = insertRec(node.left, key, s);
        else if (key.compareTo(node.key) > 0) node.right = insertRec(node.right, key, s);
        else node.student = s;
        return node;
    }
    public Student search(String key) {
        Node cur = root;
        while (cur != null) {
            int cmp = key.compareTo(cur.key);
            if (cmp == 0) return cur.student;
            cur = cmp < 0 ? cur.left : cur.right;
        }
        return null;
    }
}
