import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Main {
    static final String CSV_PATH = new File("java/students.csv").getAbsolutePath();
    static final String R_DASH = new File("r/analyze_dashboard_highres.R").getAbsolutePath();
    static final String R_STU = new File("r/analyze_student_highres.R").getAbsolutePath();
    static final String OUT_PIE = new File("outputs/dashboard_pie.png").getAbsolutePath();
    static final String OUT_BAR = new File("outputs/dashboard_bar.png").getAbsolutePath();
    static final String OUT_STU = new File("outputs/student_plot.png").getAbsolutePath();

    ArrayList<Student> list = new ArrayList<>();
    HashMap<String,Student> map = new HashMap<>();
    StudentBST bst = new StudentBST();

    JFrame frame;
    DefaultTableModel model;
    JTable table;
    JTextArea logArea;
    JPanel slidePanel;
    JPanel profilePanel;
    boolean slideVisible=false;
    javax.swing.Timer slideTimer;
    int slideX;
    JLabel pieLabel, barLabel;
    JLabel profName, profId, profFinal;
    JLabel profPieLabel;

    // Gradient colors (Blue -> Purple)
    Color gradientStart = new Color(30,120,220);
    Color gradientEnd = new Color(120,40,180);
    Color card = new Color(250,250,255);
    Color accent = new Color(30,120,220);

    public static void main(String[] args){ SwingUtilities.invokeLater(() -> new Main().initUI()); }

    void initUI(){
        loadCSV();
        frame = new JFrame("Student Performance Dashboard - PRO (v11)");
        frame.setSize(1300,820);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Top toolbar
        JPanel top = new JPanel();
        top.setBackground(Color.WHITE);
        top.setLayout(new BoxLayout(top, BoxLayout.X_AXIS));
        JButton refreshBtn = new JButton("Refresh");
        JButton addBtn = new JButton("Add Student");
        JTextField searchField = new JTextField(); searchField.setMaximumSize(new Dimension(320,28));
        JButton searchBtn = new JButton("Search");
        top.add(Box.createRigidArea(new Dimension(10,0)));
        top.add(refreshBtn); top.add(Box.createRigidArea(new Dimension(8,0)));
        top.add(addBtn); top.add(Box.createRigidArea(new Dimension(12,0)));
        top.add(new JLabel("Search by ID: ")); top.add(searchField); top.add(Box.createRigidArea(new Dimension(6,0))); top.add(searchBtn);

        // Left dashboard with gradient
        JPanel left = new JPanel(new BorderLayout()){
            protected void paintComponent(Graphics g){
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                GradientPaint gp = new GradientPaint(0,0, gradientStart, w, h, gradientEnd);
                g2.setPaint(gp);
                g2.fillRect(0,0,w,h);
            }
        };
        left.setPreferredSize(new Dimension(600,760));

        // Cards area
        JPanel cards = new JPanel(new GridLayout(2,2,12,12));
        cards.setOpaque(false);
        cards.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        cards.add(makeCard("Total Students", String.valueOf(list.size())));
        cards.add(makeCard("Average Score", String.valueOf(calculateAverage())));
        cards.add(makeCard("Highest Scorer", findHighest()));
        cards.add(makeCard("Lowest Scorer", findLowest()));
        left.add(cards, BorderLayout.NORTH);

        // Charts area (pie + bar)
        JPanel charts = new JPanel(new GridLayout(2,1,8,8));
        charts.setOpaque(false);
        charts.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        pieLabel = new JLabel(); pieLabel.setHorizontalAlignment(SwingConstants.CENTER);
        barLabel = new JLabel(); barLabel.setHorizontalAlignment(SwingConstants.CENTER);
        pieLabel.setPreferredSize(new Dimension(560,320));
        barLabel.setPreferredSize(new Dimension(560,320));
        charts.add(new JScrollPane(pieLabel));
        charts.add(new JScrollPane(barLabel));
        left.add(charts, BorderLayout.CENTER);

        // Right area: table + profile on the far right
        model = new DefaultTableModel(new String[]{"ID","Name","DS","JAVA","COSM","COA","DE","Final"},0);
        table = new JTable(model);
        refreshTable();
        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setPreferredSize(new Dimension(630,520));

        // Profile panel on the right (initially hidden until a student clicked)
        profilePanel = new JPanel(new BorderLayout());
        profilePanel.setPreferredSize(new Dimension(320,760));
        profilePanel.setBackground(new Color(245,245,250));
        buildProfilePanel();

        // Container for right area: top table and profile at right
        JSplitPane rightSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScroll, profilePanel);
        rightSplit.setDividerLocation(630);

        // Slide panel for add/edit
        slidePanel = new JPanel();
        slidePanel.setPreferredSize(new Dimension(360,760));
        slidePanel.setBackground(card);
        buildSlidePanelContents();
        slidePanel.setVisible(false);

        // Log area
        logArea = new JTextArea(6,20); logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);

        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, rightSplit);
        mainSplit.setDividerLocation(600);

        frame.add(top, BorderLayout.NORTH);
        frame.add(mainSplit, BorderLayout.CENTER);
        frame.add(logScroll, BorderLayout.SOUTH);
        frame.add(slidePanel, BorderLayout.EAST);

        // Actions
        refreshBtn.addActionListener(e -> { loadCSV(); refreshTable(); runDashboardR(); reloadCharts(); updateCards(cards); });
        addBtn.addActionListener(e -> toggleSlide());
        searchBtn.addActionListener(e -> { String q = searchField.getText().trim(); if(!q.isEmpty()) searchById(q); });
        table.addMouseListener(new java.awt.event.MouseAdapter(){ public void mouseClicked(java.awt.event.MouseEvent e){ if(e.getClickCount()==2){ int r = table.getSelectedRow(); if(r>=0){ String id = model.getValueAt(r,0).toString(); Student s = map.get(id); showStudentProfile(s); } } } });

        // Slide timer
        slideX = frame.getWidth();
        slideTimer = new javax.swing.Timer(6, new ActionListener(){ public void actionPerformed(ActionEvent ev){ animateSlideSmooth(); } });

        // Initial charts (high-res R)
        runDashboardR();
        SwingUtilities.invokeLater(() -> { reloadCharts(); });

        frame.setLocationRelativeTo(null); frame.setVisible(true);
    }

    JPanel makeCard(String title, String value){
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(6,6,6,6),
                BorderFactory.createLineBorder(new Color(255,255,255,120))));
        JLabel t = new JLabel(title); t.setFont(new Font("SansSerif", Font.PLAIN, 14)); t.setForeground(Color.WHITE);
        JLabel v = new JLabel(value); v.setFont(new Font("SansSerif", Font.BOLD, 22)); v.setForeground(Color.WHITE);
        t.setHorizontalAlignment(SwingConstants.CENTER); v.setHorizontalAlignment(SwingConstants.CENTER);
        p.add(t, BorderLayout.NORTH); p.add(v, BorderLayout.CENTER);
        p.setBackground(new Color(255,255,255,80));
        return p;
    }

    double calculateAverage(){ double sum=0; int cnt=0; for(Student s:list){ if(s.finalScore!=null){ sum+=s.finalScore; cnt++; } } return cnt==0?0:Math.round((sum/cnt)*100.0)/100.0; }

    String findHighest(){ double mx=-1; Student top=null; for(Student s:list){ if(s.finalScore!=null && s.finalScore>mx){ mx=s.finalScore; top=s; } } if(top==null) return "-"; return top.name + " (" + (int)Math.round(top.finalScore) + "%)"; }
    String findLowest(){ double mn=999; Student bot=null; for(Student s:list){ if(s.finalScore!=null && s.finalScore<mn){ mn=s.finalScore; bot=s; } } if(bot==null) return "-"; return bot.name + " (" + (int)Math.round(bot.finalScore) + "%)"; }

    void updateCards(JPanel cards){
        cards.removeAll();
        cards.add(makeCard("Total Students", String.valueOf(list.size())));
        cards.add(makeCard("Average Score", String.valueOf(calculateAverage())));
        cards.add(makeCard("Highest Scorer", findHighest()));
        cards.add(makeCard("Lowest Scorer", findLowest()));
        cards.revalidate(); cards.repaint();
    }

    void reloadCharts(){
        try{
            BufferedImage pieImg = ImageIO.read(new File(OUT_PIE));
            BufferedImage barImg = ImageIO.read(new File(OUT_BAR));
            if(pieImg!=null){
                Image s = pieImg.getScaledInstance(pieLabel.getWidth(), pieLabel.getHeight(), Image.SCALE_SMOOTH);
                pieLabel.setIcon(new ImageIcon(s));
            }
            if(barImg!=null){
                Image s2 = barImg.getScaledInstance(barLabel.getWidth(), barLabel.getHeight(), Image.SCALE_SMOOTH);
                barLabel.setIcon(new ImageIcon(s2));
            }
        }catch(Exception e){
            logArea.append("\nCannot load charts: " + e.getMessage());
        }
    }

    void buildProfilePanel(){
        profilePanel.removeAll();
        JPanel top = new JPanel(new GridLayout(3,1));
        top.setOpaque(false);
        profName = new JLabel("Name: -"); profId = new JLabel("ID: -"); profFinal = new JLabel("Final: -");
        profName.setFont(new Font("SansSerif", Font.BOLD, 16));
        profId.setFont(new Font("SansSerif", Font.PLAIN, 14));
        profFinal.setFont(new Font("SansSerif", Font.PLAIN, 14));
        top.add(profName); top.add(profId); top.add(profFinal);
        profPieLabel = new JLabel(); profPieLabel.setHorizontalAlignment(SwingConstants.CENTER);
        profPieLabel.setPreferredSize(new Dimension(300,300));
        profilePanel.add(top, BorderLayout.NORTH);
        profilePanel.add(profPieLabel, BorderLayout.CENTER);
        profilePanel.revalidate(); profilePanel.repaint();
    }

    void showStudentProfile(Student s){
        if(s==null) return;
        profName.setText("Name: " + s.name);
        profId.setText("ID: " + s.id);
        profFinal.setText("Final: " + (s.finalScore==null? "-" : (int)Math.round(s.finalScore) + "%"));
        // generate high-res student chart using R then load it
        try {
            Process p = new ProcessBuilder("Rscript", R_STU, s.id, CSV_PATH, OUT_STU).redirectErrorStream(true).start();
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line; while((line=in.readLine())!=null) logArea.append("\n[R] " + line);
            p.waitFor();
            BufferedImage stuImg = ImageIO.read(new File(OUT_STU));
            if(stuImg!=null){
                Image sImg = stuImg.getScaledInstance(profPieLabel.getWidth(), profPieLabel.getHeight(), Image.SCALE_SMOOTH);
                profPieLabel.setIcon(new ImageIcon(sImg));
            }
        } catch(Exception e){ logArea.append("\nError generating student plot: " + e.getMessage()); }
    }

    void buildSlidePanelContents(){
        slidePanel.removeAll();
        slidePanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6); c.fill = GridBagConstraints.HORIZONTAL;
        JLabel h = new JLabel("Add / Edit Student"); h.setFont(new Font("SansSerif", Font.BOLD,16)); c.gridx=0; c.gridy=0; c.gridwidth=2; slidePanel.add(h,c);
        c.gridwidth=1;
        c.gridy++; slidePanel.add(new JLabel("ID:"),c); JTextField idF = new JTextField(14); c.gridx=1; slidePanel.add(idF,c);
        c.gridx=0; c.gridy++; slidePanel.add(new JLabel("Name:"),c); JTextField nameF = new JTextField(14); c.gridx=1; slidePanel.add(nameF,c);
        JTextField[] m = new JTextField[5];
        String[] subNames = new String[]{"DS","JAVA","COSM","COA","DE"};
        for(int i=0;i<5;i++){ c.gridx=0; c.gridy++; slidePanel.add(new JLabel(subNames[i]+":"),c); m[i]=new JTextField(8); c.gridx=1; slidePanel.add(m[i],c); }
        c.gridx=0; c.gridy++; JButton save = new JButton("Save"); slidePanel.add(save,c); JButton del = new JButton("Delete"); c.gridx=1; slidePanel.add(del,c);

        save.addActionListener(e -> {
            try {
                String id = idF.getText().trim(); String name = nameF.getText().trim();
                if(id.isEmpty() || name.isEmpty()){ logArea.append("\nID or name empty"); return; }
                double[] marks = new double[5]; for(int i=0;i<5;i++) marks[i]=Double.parseDouble(m[i].getText().trim());
                double finalScore = Math.round((marks[0]+marks[1]+marks[2]+marks[3]+marks[4])/5.0);
                Student s = new Student(id,name,marks,finalScore);
                saveOrUpdateStudentCSV(s);
                logArea.append("\nSaved: " + id);
                loadCSV(); refreshTable(); runDashboardR(); SwingUtilities.invokeLater(() -> { reloadCharts(); updateCards((JPanel) ((JSplitPane)frame.getContentPane().getComponent(1)).getLeftComponent()); });
            } catch(Exception ex){ logArea.append("\nError saving: " + ex.getMessage()); }
        });

        del.addActionListener(e -> {
            try { String id = idF.getText().trim(); if(id.isEmpty()){ logArea.append("\nEnter ID to delete"); return; } deleteStudentFromCSV(id); logArea.append("\nDeleted: " + id); loadCSV(); refreshTable(); runDashboardR(); SwingUtilities.invokeLater(() -> { reloadCharts(); updateCards((JPanel) ((JSplitPane)frame.getContentPane().getComponent(1)).getLeftComponent()); }); }
            catch(Exception ex){ logArea.append("\nError deleting: " + ex.getMessage()); }
        });

        slidePanel.revalidate(); slidePanel.repaint();
    }

    void toggleSlide(){
        slideVisible = !slideVisible;
        slidePanel.setVisible(true);
        slideX = frame.getWidth();
        slideTimer.start();
    }

    void animateSlideSmooth(){
        int target = slideVisible ? frame.getWidth() - slidePanel.getWidth() : frame.getWidth();
        int delta = target - slideX;
        int step = (int)Math.ceil(Math.abs(delta) * 0.2) + 6;
        if(slideVisible){
            slideX += (int)Math.signum(delta) * step;
            if(Math.abs(slideX - target) <= 4){ slideX = target; slideTimer.stop(); }
        } else {
            slideX += (int)Math.signum(delta) * step;
            if(Math.abs(slideX - target) <= 4){ slideX = target; slideTimer.stop(); slidePanel.setVisible(false); }
        }
        slidePanel.setLocation(slideX, slidePanel.getY());
        slidePanel.repaint();
    }

    void showStudent(Student s){
        logArea.append("\nShowing: " + s.id);
        JOptionPane.showMessageDialog(frame, "ID: " + s.id + "\nName: " + s.name + "\nMarks: " + Arrays.toString(s.marks) + "\nFinal: " + s.finalScore);
    }

    void saveOrUpdateStudentCSV(Student s) throws Exception {
        Path p = Paths.get(CSV_PATH);
        java.util.List<String> lines = java.nio.file.Files.readAllLines(p);
        boolean updated=false;
        for(int i=1;i<lines.size();i++){
            String[] a = lines.get(i).split(","); if(a[0].equals(s.id)){ lines.set(i, s.toCSV()); updated=true; break; }
        }
        if(!updated) lines.add(s.toCSV());
        java.nio.file.Files.write(p, lines);
    }

    void deleteStudentFromCSV(String id) throws Exception{
        Path p = Paths.get(CSV_PATH); java.util.List<String> lines = java.nio.file.Files.readAllLines(p); java.util.List<String> out = new java.util.ArrayList<>(); out.add(lines.get(0));
        for(int i=1;i<lines.size();i++){ String[] a = lines.get(i).split(","); if(!a[0].equals(id)) out.add(lines.get(i)); }
        java.nio.file.Files.write(p, out);
    }

    void searchById(String q){ Student s = map.get(q); if(s==null) logArea.append("\nNot found: " + q); else showStudentProfile(s); }

    void refreshTable(){ model.setRowCount(0); for(Student s:list) model.addRow(new Object[]{s.id,s.name,(int)s.marks[0],(int)s.marks[1],(int)s.marks[2],(int)s.marks[3],(int)s.marks[4],s.finalScore==null?"":(int)Math.round(s.finalScore)}); }

    void loadCSV(){ list.clear(); map.clear(); try{ BufferedReader br = java.nio.file.Files.newBufferedReader(Paths.get(CSV_PATH)); String header = br.readLine(); String line; while((line=br.readLine())!=null){ if(line.trim().isEmpty()) continue; String[] a = line.split(","); String id=a[0]; String name=a[1]; double[] m=new double[5]; for(int i=0;i<5;i++) m[i]=Double.parseDouble(a[2+i]); Double f = a.length>=8 && !a[7].isEmpty()? Double.parseDouble(a[7]):null; Student s = new Student(id,name,m,f); list.add(s); map.put(id,s); bst.insert(id,s); } br.close(); }catch(Exception e){ e.printStackTrace(); } }

    void runDashboardR(){
        try{ Process p = new ProcessBuilder("Rscript", R_DASH, CSV_PATH, OUT_PIE, OUT_BAR).redirectErrorStream(true).start();
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream())); String line; while((line=in.readLine())!=null) logArea.append("\n[R] " + line); p.waitFor(); } catch(Exception e){ logArea.append("\nError running dashboard R: " + e.getMessage()); }
    }
}
