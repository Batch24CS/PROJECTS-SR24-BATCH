
public class Student {
    public String id;
    public String name;
    public double[] marks;
    public Double finalScore;

    public Student(String id, String name, double[] marks, Double finalScore) {
        this.id = id;
        this.name = name;
        this.marks = marks;
        this.finalScore = finalScore;
    }

    public String toCSV() {
        StringBuilder sb = new StringBuilder();
        sb.append(id).append(",").append(name);
        for (double m : marks) sb.append(",").append((int)m);
        sb.append(",");
        sb.append(finalScore == null ? "" : (int)Math.round(finalScore));
        return sb.toString();
    }
}
