@echo off
cd java\src
javac *.java
cd ..\..
Rscript r\analyze_dashboard_highres.R java\students.csv outputs\dashboard_pie.png outputs\dashboard_bar.png
java -cp java/src Main
pause
