
args <- commandArgs(trailingOnly=TRUE)
csv <- args[1]; outpie <- args[2]; outbar <- args[3]
df <- read.csv(csv, stringsAsFactors=FALSE)
subjects <- c('DS','JAVA','COSM','COA','DE')
avg <- sapply(subjects, function(s) mean(as.numeric(df[[s]]), na.rm=TRUE))
png(outpie, width=1600, height=1000, res=150)
par(mai=c(1,1,1,1))
pie(avg, labels=paste(subjects, round(avg,1)), main='Average marks by subject', col=rainbow(length(avg)))
dev.off()
df$final_score <- as.numeric(df$final_score)
top <- df[order(-df$final_score),][1:min(5,nrow(df)),]
png(outbar, width=1600, height=1000, res=150)
par(mai=c(1,1,1,1))
barplot(top$final_score, names.arg=top$name, main='Top 5 students by final score', ylab='Final Score', las=2, col=rainbow(nrow(top)))
dev.off()
cat('Dashboard charts generated\n')
