
args <- commandArgs(trailingOnly=TRUE)
id <- args[1]; csv <- args[2]; out <- args[3]
df <- read.csv(csv, stringsAsFactors=FALSE)
row <- df[df$student_id==id,]
png(out, width=1200, height=900, res=150)
par(mai=c(1,1,1,1))
barplot(as.numeric(row[3:7]), names.arg=c('DS','JAVA','COSM','COA','DE'), main=paste('Marks for', row$name), ylab='Marks', col=rainbow(5))
dev.off()
cat('Student plot generated for', id, '\n')
